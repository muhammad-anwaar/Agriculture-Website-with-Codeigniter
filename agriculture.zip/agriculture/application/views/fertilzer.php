<?php include('header.php'); ?>
<?php include('left_section.php'); ?>


<div class="art-layout-cell art-content clearfix">
<article class="art-post art-article">

<?php foreach($fert as $r): ?>
<div style=" margin:20px 2px 5px 2px; width:100%;">

<img style="width:380px; margin-left:200px;" src="<?php echo base_url()."upload/".$r->product_imag; ?>" />
<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=<?php echo $r->cp_id; ?>" style="width:30%; color:#fff;">
<p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:16px; background:#2E9206; width:380px; margin-left:100px; padding:8px">
<?php echo $r->product_name; ?>

</p>
</a>

<?php endforeach ?>
</article>

<div style="margin-left:15px;"><INPUT TYPE="button" VALUE="&laquo;Back" onClick="history.go(-1);" style="font-size:14px"></div>

</div>
<?php include('footer.php'); ?>

