<?php 
echo "check it";
?>