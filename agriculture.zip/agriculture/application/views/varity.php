<?php 
if($row)
{
	$c=explode(",",$row);
	 $crop=$c[0];
	 $city=$c[1];
	 
	 if($crop=='Cotton')
	 {
		 if($city=='multan')
		 { ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="bt">BT</option>
<option value="786">786</option>
<option value="788">788</option>
<option value="790">790</option>
</select>
			 
		<?php	 }
		else if($city=='dgkhan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="791">791</option>
<option value="792">792</option>
<option value="788">788</option>
<option value="795">795</option>
</select>
		<?php 
		}
		else if($city=='rajanpur')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
        
<option value="791">791</option>
<option value="793">793</option>
<option value="784">784</option>
<option value="770">770</option>
</select>
		<?php 
		}else if($city=='bhawalpur')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
     
<option value="792">792</option>
<option value="786">786</option>
<option value="799">799</option>
<option value="800">800</option>
</select>
		<?php 
		}
		else if($city=='lahore')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
    
         
<option value="790">790</option>
<option value="799">799</option>
<option value="801">801</option>
<option value="802">802</option>
</select>
		<?php 
		}
		else if($city=='gujranwala')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
      
         
<option value="792">792</option>
<option value="800">800</option>
<option value="802">802</option>
<option value="803">803</option>
</select>
		<?php 
		}
		else if($city=='sialkot')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="792">792</option>
<option value="800">800</option>
</select>
		<?php 
		}
		else if($city=='rawalpindi')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
        
<option value="800">800</option>
<option value="803">803</option>
<option value="804">804</option>
</select>
		<?php 
		}
		else if($city=='karachi')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
        
<option value="801">801</option>
<option value="803">803</option>
<option value="799">799</option>
<option value="805">805</option>
</select>
		<?php 
		}
		else if($city=='shukkar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
      
<option value="801">801</option>
<option value="792">792</option>
<option value="804">804</option>
<option value="786">786</option>
</select>
		<?php 
		}
		else if($city=='jamshuru')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
        
<option value="801">801</option>
<option value="786">786</option>
<option value="805">805</option>
<option value="808">808</option>
</select>
		<?php 
		}
		else if($city=='haidrabad')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
       
<option value="786">786</option>
<option value="799">799</option>
<option value="805">805</option>
<option value="808">808</option>
</select>
		<?php 
		}
		else if($city=='khusdar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
       
<option value="786">786</option>
<option value="799">799</option>
</select>
		<?php 
		}
		else if($city=='quetta')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
        
<option value="786">786</option>
<option value="792">792</option>
<option value="805">805</option>
<option value="803">803</option>
</select>
		<?php 
		}
		else if($city=='makraan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="788">788</option>
<option value="799">799</option>
<option value="800">800</option>
<option value="808">808</option>
</select>
		<?php 
		}
		else if($city=='peshawar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
       
<option value="800">800</option>
<option value="bt">BT</option>
<option value="799">799</option>
</select>
		<?php 
		}
		else if($city=='dikhan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
        
<option value="804">804</option>
<option value="bt">BT</option>
<option value="786">786</option>
</select>
		<?php 
		}
		else if($city=='bannu')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
        
<option value="808">808</option>
<option value="bt">BT</option>
<option value="788">788</option>
</select>
		<?php 
		}
		 }
		 else if($crop=='Rice')
		 {
			 
			 
		 if($city=='multan')
		 { ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">Basmati</option>
<option value="super_786">Super 86</option>
<option value="88">88</option>
</select>
			 
		<?php	 }
		else if($city=='dgkhan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="88">88</option>
<option value="basmati">basmati</option>
<option value="super_lite">Super Lite</option>
</select>
		<?php 
		}
		else if($city=='rajanpur')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="786">786</option>
<option value="785">785</option>
<option value="basmati">basmati</option>
</select>
		<?php 
		}else if($city=='bhawalpur')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_lite">Super Lite</option>
<option value="786">786</option>
<option value="basmati_85">Basmati 85</option>
</select>
		<?php 
		}
		else if($city=='lahore')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="86">86</option>
<option value="basmati">basmati</option>
</select>
		<?php 
		}
		else if($city=='gujranwala')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="super_lite">super_lite</option>
<option value="super_86">super-86</option>
</select>
		<?php 
		}
		else if($city=='sialkot')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="super_lite">super_lite</option>
<option value="super_86">super-86</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='rawalpindi')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="super_86">super-86</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='karachi')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='shukkar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="super_lite">super_lite</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='jamshuru')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="basmati">basmati</option>
<option value="super_lite">super_lite</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='haidrabad')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         

<option value="basmati">basmati</option>
<option value="super_86">super-86</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='khusdar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='quetta')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="86">86</option>
</select>
		<?php 
		}
		else if($city=='makraan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="786">786</option>
<option value="basmati">basmati</option>

</select>
		<?php 
		}
		else if($city=='peshawar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_86">super-86</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='dikhan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="basmati_lite">basmati Lite</option>
</select>
		<?php 
		}
		else if($city=='bannu')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="super_kernal">Super Kernal</option>
<option value="basmati">basmati</option>
<option value="super_lite">super_lite</option>
</select>
		<?php 
		}
		 
			 
			 }
			 else if($crop=='Wheat')
			 {
				 
			 
			 
		 if($city=='multan')
		 { ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="aas">AAS</option>
<option value="esd2008">ESD-2008</option>
<option value="2011ck">2011-CK</option>
</select>
			 
		<?php	 }
		else if($city=='dgkhan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="1"> inqlab</option>
<option value="esd2008">ESD-2008</option>
<option value="1">pasbhan</option>
</select>
		<?php 
		}
		else if($city=='rajanpur')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="watan">watan</option>
<option value="shamaak">shamaak</option>
<option value="td1">TD-1</option>
</select>
		<?php 
		}else if($city=='bhawalpur')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="1">Pashban</option>
<option value="2011ck">2011-CK</option>
<option value="bhakar">Bhakar</option>
</select>
		<?php 
		}
		else if($city=='lahore')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="td1">TD-1</option>
<option value="1">Pashban</option>
<option value="shamaak">shamaak</option>
</select>
		<?php 
		}
		else if($city=='gujranwala')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="esd2008">ESD-2008</option>
<option value="1"> inqlab</option>
<option value="watan">watan</option>
</select>
		<?php 
		}
		else if($city=='sialkot')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="2011ck">2011 CK</option>
<option value="watan">watan</option>
<option value="esd2008">ESD-2008</option>
</select>
		<?php 
		}
		else if($city=='rawalpindi')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
<option value="2011ck">2011 CK</option>
<option value="aas">AAS</option>


</select>
		<?php 
		}
		else if($city=='karachi')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="td1">TD-1</option>
<option value="watan">watan</option>
<option value="bhakaar">Bhakaar</option>
</select>
		<?php 
		}
		else if($city=='shukkar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="esd2008">ESD 2008</option>
<option value="2011ck">2011-Ck</option>
<option value="esd2008">ESD 2005</option>
</select>
		<?php 
		}
		else if($city=='jamshuru')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="td1">TD-1</option>
<option value="watan">Watan</option>
<option value="bhakaar">Bhakaar</option>
</select>
		<?php 
		}
		else if($city=='haidrabad')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         

<option value="td1">TD-1</option>
<option value="esd2008">ESD 2008</option>
<option value="bhakaar">Bhakaar</option>
</select>
		<?php 
		}
		else if($city=='khusdar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="td1">TD-1</option>
<option value="bhakar">Bhakar</option>
<option value="esd2008">ESD-2008</option>
</select>
		<?php 
		}
		else if($city=='quetta')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="bhakar">Bhakar</option>
<option value="aas">AAS</option>
<option value="esd2008">ESD-2008</option>
</select>
		<?php 
		}
		else if($city=='makraan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="aas">AAS</option>
<option value="td1">TD-1</option>
<option value="esd2008">ESD-2008</option>
</select>
		<?php 
		}
		else if($city=='peshawar')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="td1">TD-1</option>
<option value="watan">Watan</option>
<option value="esd2008">ESD-2008</option>
</select>
		<?php 
		}
		else if($city=='dikhan')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="td1">TD-1</option>
<option value="2011ck">2011-ck</option>
<option value="bhakar">Bhakar</option>
</select>
		<?php 
		}
		else if($city=='bannu')
		{ ?>
         <select name="varity" id="varity" style="width:226px; border-radius:4px; height:36px;">
         
<option value="2011ck">2011-ck</option>

<option value="esd2008">ESD-2008</option>
</select>
		<?php 
		}
		 
			 
			 
				 
				 }
	}
 ?>
 <script type="text/javascript">
 	 var crop = $('#crop').val();
	var varity=$('#varity').val();
	$("#shw").load("record",{"crop":crop,"varity":varity});
	
 $("#varity").change(function(e) {
   
	 var crop = $('#crop').val();
	var varity=$('#varity').val();	
		
	$("#shw").load("record",{"crop":crop,"varity":varity});
});
 </script>