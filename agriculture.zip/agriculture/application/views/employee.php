<?php include('header.php'); ?>
<?php include('left_emp.php'); ?>

<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Employee Dashboard</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">



<h2 align="left" style="color:#0CF"> Welcome <?php echo $this->session->userdata('emp_name'); ?> </h2>
<!--<p style="float:right; margin-right:20px;">   <a href="<?php echo base_url(); ?>index.php/employee/logout"><img src="../../images/logout.png" /></a></p>-->
<table align="center"  cellpadding="2" cellspacing="2">
<tr ><td ></td></tr>
<tr></tr>
<tr><td><?php if(!empty($msg)){
	
	echo $msg;
	} ?></td></tr>
<tr><td><h2 style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px">Select Your Desired Operations From Side Bar.</h2></td></tr>
<!--<tr><td><a href="<?php echo base_url(); ?>index.php/dealer/create"><img src="http://Localhost/agriculture/images/add_dealer.png" style="width: 200px;"/></a></td></tr>
<tr><td><a href="<?php echo base_url(); ?>index.php/dealer/show?var1=<?php echo $this->session->userdata('city'); ?>"><img src="http://Localhost/agriculture/images/manage_dealer.png" style="width:200px; height:50px;" /></a></td></tr>
<tr><td><a href="<?php echo base_url(); ?>index.php/product/order?c1=<?php echo $this->session->userdata('city'); ?>"><img src="http://Localhost/agriculture/images/manage_order.png" style="width:200px; height:50px;" />

</a></td></tr>
<tr><td><a href="<?php echo base_url(); ?>index.php/product/daily_rpt?cs=<?php echo $this->session->userdata('city'); ?>"><img src="http://Localhost/agriculture/images/daily_report.png" style="width:200px; height:50px;" />

</a></td></tr>
<tr><td><a href="<?php echo base_url(); ?>index.php/employee/manage_report?rpt=<?php echo $this->session->userdata('emp_id'); ?>"><h2>Manage Report</h2>

</a></td></tr>-->
<tr></tr>
</table>
</div>


</div>
</article>
</div>

<?php include('footer.php'); ?>