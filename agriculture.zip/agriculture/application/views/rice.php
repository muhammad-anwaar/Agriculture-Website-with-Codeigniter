 <?php include('header.php'); ?>
 <?php include('left_section.php'); ?>
  <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Rice</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <p>Rice is the seed of the monocot plants Oryza sativa (Asian rice) or Oryza glaberrima (African rice). As a cereal grain, it is the most widely consumed staple food for a large part of the world's human population, especially in Asia. It is the grain with the third-highest worldwide production, after sugarcane and maize, according to data of FAOSTAT 2012. 

</p>
        
        <p>Since a large portion of maize crops are grown for purposes other than human consumption, rice is the most important grain with regard to human nutrition and caloric intake, providing more than one fifth of the calories consumed worldwide by humans.[2]
Chinese legends attribute the domestication of rice to Shennong, the legendary Emperor of China and inventor of Chinese agriculture.[3] Genetic evidence has shown that rice originates from a single domestication 8,200–13,500 years ago[4] in the Pearl River valley region of China.[5] Previously, archaeological evidence had suggested that rice was domesticated in the Yangtze River valley region in China.[4] From East Asia, rice was spread to Southeast and South Asia.[5] Rice was introduced to Europe through Western Asia, and to the Americas through European colonization.
 
</p>
        
        <p>There are many varieties of rice and culinary preferences tend to vary regionally. In some areas such as the Far East or Spain, there is a preference for softer and stickier varieties.
Rice is normally grown as an annual plant, although in tropical areas it can survive as a perennial and can produce a ratoon crop for up to 30 years.[6] The rice plant can grow to 1–1.8 m (3.3–5.9 ft) tall, occasionally more depending on the variety and soil fertility. It has long, slender leaves 50–100 cm (20–39 in) long and 2–2.5 cm (0.79–0.98 in) broad. The small wind-pollinated flowers are produced in a branched arching to pendulous inflorescence 30–50 cm (12–20 in) long. The edible seed is a grain (caryopsis) 5–12 mm (0.20–0.47 in) long and 2–3 mm (0.079–0.118 in) thick.
</p>
<p>
Rice cultivation is well-suited to countries and regions with low labor costs and high rainfall, as it is labor-intensive to cultivate and requires ample water. However, rice can be grown practically anywhere, even on a steep hill or mountain area with the use of water-controlling terrace systems. Although its parent species are native to Asia and certain parts of Africa, centuries of trade and exportation have made it commonplace in many cultures worldwide.
</p>
        
        <p>The traditional method for cultivating rice is flooding the fields while, or after, setting the young seedlings. This simple method requires sound planning and servicing of the water damming and channeling, but reduces the growth of less robust weed and pest plants that have no submerged growth state, and deters vermin. While flooding is not mandatory for the cultivation of rice, all other methods of irrigation require higher effort in weed and pest control during growth periods and a different approach for fertilizing the soil.
The name wild rice is usually used for species of the genera Zizania and Porteresia, both wild and domesticated, although the term may also be used for primitive or uncultivated varieties of Oryza.


</p>
<p>
Rice production in Pakistan holds an extremely important position in agriculture and the national economy. Pakistan is the world's fourth largest producer of rice, after China, India and Indonesia. Each year, it produces an average of 6 million tonnes and together with the rest of the South Asia, the country is responsible for supplying 30% of the world's paddy rice output. Most of these crops are grown in the fertile Sindh and Punjab region with millions of farmers relying on rice cultivation as their major source of employment. Among the most famous varieties grown in Pakistan include the Basmati, known for its flavour and quality.
</p>

    </div>
    </div>
</div>
</div>
</article></div>
                   
         
            <?php include('footer.php'); ?>