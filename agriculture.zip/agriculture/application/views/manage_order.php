<?php include('header.php'); ?>
<?php include('left_emp.php'); ?>

<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Manage Orders</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">


<table align="center"  cellpadding="2" cellspacing="2" width="850px;" border="1" style=" border-radius:8px; margin:50px 0px 0px -3px;">
<tr style="background:#0F9;">
<th style="font-size:16px;">Product</th>
<th style="font-size:16px;">Qunatity</th>
<th style="font-size:16px;">Order Date</th>
<th style="font-size:16px;">Address</th>
<th style="font-size:16px;">Dealer Name</th>
<th style="font-size:16px;">Action</th>
</tr>
<?php  foreach($row as $r):  ?>
<tr>
<form action="<?php echo base_url(); ?>index.php/product/manage_order" method="post" name="gform" enctype="multipart/form-data">
<td><input type="text" name="order_product"   value="<?php echo $r->order_product; ?> " style="border:hidden; background:none;"/></td>
<td><input type="text" name="order_quantity" value="<?php echo $r->order_quantity; ?> " style="border:hidden; background:none;"/></td>
<td style="width:112px;"><input type="text" name="order_date"   value="<?php echo $r->order_date; ?> " style="border:hidden; background:none;"/></td>
<td><input type="text" name="order_address" value="<?php echo $r->order_address.','; ?> " style="border:hidden; background:none;"/>
<input type="text" name="order_city"   value="<?php echo $r->order_city.','; ?> " style="border:hidden; background:none;"/>
<input type="text" name="order_state"   value="<?php echo $r->order_state.','; ?> " style="border:hidden; background:none;"/>
<input type="text" name="order_country"   value="<?php echo $r->order_country.','; ?> " style="border:hidden; background:none;"/>
</td>
<td style="width:112px;"><input type="text" name="order" value="<?php echo $r->order_type; ?> " style="border:hidden; background:none;"/>
<input type="hidden" name="order_type" value="Employee" />
<input type="hidden" name="order_id" value="<?php echo $r->order_id; ?>" />
</td>
<td>
<?php if($r->order_status==1){ ?>
<input type="button" disabled  name="submit" value="Already Proceed" style="background: #F00; border-radius:4px;" />
<?php } else { ?>
<input type="submit" name="submit" value="Proceed" style="background:#CCC; border-radius:4px;" />
<?php } ?>
</td>
</tr>
</form>
<?php endforeach; ?>
</table>
</div>
<div><INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);"></div>
 </div>
</article>
</div>
<?php include('footer.php'); ?>