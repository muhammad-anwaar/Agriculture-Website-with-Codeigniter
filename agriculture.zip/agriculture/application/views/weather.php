<?php include('header.php'); ?>
 <?php include('left_section.php'); ?>          
  <div class="weather" align="center">
  <a href="http://www.accuweather.com/en/pk/islamabad/258278/current-weather/258278" class="aw-widget-legal">
<!--
By accessing and/or using this code snippet, you agree to AccuWeather�s terms and conditions (in English) which can be found at http://www.accuweather.com/en/free-weather-widgets/terms and AccuWeather�s Privacy Statement (in English) which can be found at http://www.accuweather.com/en/privacy.
-->
</a><div id="awtd1411914507802" class="aw-widget-36hour"  data-locationkey="" data-unit="c" data-language="en-us" data-useip="true" data-uid="awtd1411914507802" data-editlocation="true"></div><script type="text/javascript" src="http://oap.accuweather.com/launch.js"></script>
  </div>                  
                  
      <?php include('footer.php'); ?>          
      </div>
