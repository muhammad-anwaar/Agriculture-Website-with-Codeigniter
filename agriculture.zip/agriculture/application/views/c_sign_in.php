<?php include('header.php'); ?>
<?php include('left_section.php'); ?>


 <div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Customer Login</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">

<center>  <h2>Enter Your Login and Password</h2></center>
  
  <form style="margin: 20px 0px 0px 240px; width:300px;"  id="admin_login"action="<?php echo base_url()?>index.php/customer/login" method="post">

      <label style="font-size:14px; font-family:Georgia, 'Times New Roman', Times, serif;">Login<span style="color:red">*</span> </label>
      <?php if(!empty($error_msg)){?>
						<p><?php echo $error_msg?></p>
                        
						<?php }?>
      <div class="cleaner_h40"><p>
      <input type="text" name="username" size="30" required="required" autofocus="autofocus" title="Must Required"/>
      </p>
      <p>
      <label style="font-size:14px; font-family:Georgia, 'Times New Roman', Times, serif;">Password<span style="color:red">*</span><br />
      <input type="password" name="password" size="30" required="required" autofocus="autofocus" title="Must Required" />
      </label>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
      <button style="width:90px; margin-top:10px;" type="submit" value="submit">Login</button></form>
      
      <a href="<?php echo base_url(); ?>index.php/customer/create">Sign UP</a>&nbsp;&nbsp;<a href="<?php echo base_url(); ?>index.php/customer/reset_password">Forget Password</a>
     </div>
  
 

  <div class="fepro">
  </div>
  </div>

	
</div>
</article>
</div>
 <?php include('footer.php'); ?>