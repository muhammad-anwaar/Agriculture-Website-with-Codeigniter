<?php include('header.php'); ?>
<?php include('left_section.php'); ?>

<center><h2>Edit Information</h2></center>
<form action="<?php echo base_url(); ?>index.php/dealer/info_update" method="post" enctype="multipart/form-data" style="margin:5px 0px 0px -10px;" >
<table align="center" width="600px" cellpadding="2" cellspacing="2">
<tr></tr>
<?php foreach($row as $r): ?>

<tr><td><label>User Name</label></td><td><input type="text" name="delear_name" required autofocus value="<?php echo $r->dealer_name; ?>"/></td></tr>
<tr><td><label>Email</label></td><td><input type="text" name="email" required autofocus value="<?php echo $r->email; ?>"/></td></tr>
<tr><td><label>Password</label></td><td><input type="text" name="password" required autofocus value="<?php echo $r->password; ?>"/></td></tr>
<tr><td><label>First Name</label></td><td><input type="text" name="first_name" required autofocus value="<?php echo $r->first_name; ?>"/></td></tr>
<tr><td><label>Last Name</label></td><td><input type="text" name="last_name" required autofocus value="<?php echo $r->last_name; ?>"/></td></tr>
<tr><td><label>Address</label></td><td><input type="text" name="address" required autofocus value="<?php echo $r->address; ?>"/></td></tr>
<tr><td><label>City</label></td><td><input type="text" name="city" required autofocus value="<?php echo $r->city; ?>"/></td></tr>
<tr><td><label>Country</label></td><td><input type="text" required autofocus name="country" value="<?php echo $r->country; ?>"/></td></tr>
<tr><td><label>Date Of Birth</label></td><td><input type="text" required autofocus name="dob" value="<?php echo $r->dob; ?>"/></td></tr>
<tr><td><label>Date Of Joining</label></td><td><input type="text" required autofocus name="dj" value="<?php echo $r->dj; ?>"/></td></tr>
<tr><td><label>Gender</label></td><td><input type="text" required autofocus name="gender" value="<?php echo $r->gender; ?>"/></td></tr>
<tr><td><label>Phone Number</label></td><td><input type="text" required autofocus name="phone" value="<?php echo $r->phone; ?>"/></td></tr>
<tr><td><label>Dealer Area</label></td><td><input type="text" required autofocus name="dealer_area" value="<?php echo $r->dealer_area; ?>"/></td></tr>
<tr><td></td><td><input type="hidden" name="dealer_id" value="<?php echo $r->dealer_id; ?>" /></td></tr>
<?php endforeach; ?>
<tr></tr>
<tr><td></td><td><input type="submit" name="submit" value="submit" /></td></tr>
</table>
</form>
</div>
<?php include('footer.php'); ?>