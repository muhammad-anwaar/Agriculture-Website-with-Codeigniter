
<footer class="art-footer clearfix">
<p>Copyright © 2014, All Rights Reserved.<br>
<br></p>
</footer>
    <p class="art-page-footer">
        <span id="art-footnote-links"></span>
    </p>


</body></html>