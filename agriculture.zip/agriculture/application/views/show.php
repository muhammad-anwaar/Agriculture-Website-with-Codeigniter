<?php 
if(!empty($rows)){
	
	if($ro=='bt'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">


   <option value="whitefly">whitefly</option>   
  <option value="pink bollwarm">pink bollwarm</option> 
   <option value="thrips">thrips</option> 
   <option value="mites">mites</option>   
  <option value="aphid">aphid</option> 
   <option value="whitefly nymph">whitefly nymph</option> 
   
   </select>
   <?php } else if($ro=='786'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

<option value="jassid">jassid</option>   
  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
  <option value="mites">mites</option>
   </select>
   <?php }  else if($ro=='788'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
<option value="jassid">jassid</option>   
  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
  <option value="mites">mites</option>
  <option value="aphid">aphid</option>

   
   
   </select>
   <?php }  else if($ro=='790'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
<option value="jassid">jassid</option>   
  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
  <option value="mites">mites</option>
  <option value="aphid">aphid</option>
 
   
   
   </select>
   <?php }  else if($ro=='791'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
<option value="jassid">jassid</option>   
  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
  <option value="aphid">aphid</option>
 
   
   
   </select>
   <?php } else if($ro=='792'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
<option value="jassid">jassid</option>   
  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   
   
   </select>
   <?php } else if($ro=='792'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
<option value="jassid">jassid</option>   
  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   
 
   
   
   </select>
   <?php } else if($ro=='795'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   
  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   
   
   
   </select>
   <?php }  else if($ro=='795'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   
   
   </select>
   <?php } else if($ro=='793'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
   
   
   </select>
   <?php } else if($ro=='784'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="adult">adult</option>
   
   
   </select>
   <?php } else if($ro=='770'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="adult">adult</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="spotted bollworm">spotted bollworm</option>
   
   
   </select>
   <?php } else if($ro=='770'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="adult">adult</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   
   </select>
   <?php } else if($ro=='799'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="adult">adult</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   
   </select>
   <?php } else if($ro=='800'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="adult">adult</option>
 
   
   
   </select>
   <?php }  else if($ro=='801'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">

  <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
 <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   </select>
   <?php } else if($ro=='802'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="aphid">aphid</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="whitefly nymph">whitefly nymph</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   </select>
   <?php } else if($ro=='803'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="american bollworm">american bollworm</option>   
  <option value="pink bollwarm">pink bollwarm</option>
   <option value="mites">mites</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="whitefly nymph">whitefly nymph</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   </select>
   <?php }
   else if($ro=='804'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="whitefly">whitefly</option> 
   <option value="thrips">thrips</option> 
   <option value="mites">mites</option>   
  <option value="pink bollwarm">army worm</option>
  <option value="whitefly nymph">whitefly nymph</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   </select>
   <?php }
   else if($ro=='805'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="jassid">jassid</option> 
   <option value="thrips">thrips</option> 
   <option value="mites">mites</option>   
  <option value="adult">adult</option>
  <option value="whitefly nymph">whitefly nymph</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   </select>
   <?php }
      else if($ro=='808'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="jassid">jassid</option> 
   <option value="thrips">thrips</option> 
   <option value="mites">mites</option>   
  <option value="adult">adult</option>
  <option value="spotted bollworm">spotted bollworm</option>
  <option value="heliothis">heliothis</option>
   
   
   </select>
   <?php }
   else if($ro=='super_kernal'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
   else if($ro=='basmati'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
   else if($ro=='super_786'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
   else if($ro=='88'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
  <option value="round leaf">round leaf</option>
 
   </select>
   <?php }
   else if($ro=='super_lite'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
   else if($ro=='786'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
   else if($ro=='785'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
   else if($ro=='basmati_85'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
    else if($ro=='super_kernal'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
    else if($ro=='86'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
  
   </select>
   <?php }
    else if($ro=='super_86'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
  <option value="round leaf">round leaf</option>
  <option value="leaf rollers">leaf rollers</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
    else if($ro=='basmati_lite'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="broad leaf weeds">broad leaf weeds</option> 
   <option value="sedges">sedges</option> 
   <option value="Anuual gracces">Anuual gracces</option>   
  <option value="annual weeds">annual weeds</option>
   
   <option value="stem borers">stem borers</option>
   </select>
   <?php }
    else if($ro=='aas'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
 <option value="All broad leaf weeds">All broad leaf weeds</option> 
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="Broad leaf weeds">Broad leaf weeds</option>
  <option value="Grasses">Grasses</option>
   </select>
   <?php }
    else if($ro=='esd2008'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="Broad leaf weeds">Broad leaf weeds</option>
  <option value="Grasses">Grasses</option>
   </select>
   <?php }
   else if($ro=='2011ck'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="All broad leaf weeds">All broad leaf weeds</option> 
  <option value="Grasses">Grasses</option>
   </select>
   <?php }
   
   else if($ro=='1'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="All broad leaf weeds">All broad leaf weeds</option> 
  <option value="Grasses">Grasses</option>
   </select>
   <?php }
    else if($ro=='bhakar'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="All broad leaf weeds">All broad leaf weeds</option> 
   </select>
   <?php }
   else if($ro=='pasbhan'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="All broad leaf weeds">All broad leaf weeds</option> 
  <option value="Grasses">Grasses</option>
   </select>
   <?php }
     else if($ro=='watan'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="All broad leaf weeds">All broad leaf weeds</option> 
   </select>
   <?php }
   else if($ro=='shamaak'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
    <option value="All broad leaf weeds">All broad leaf weeds</option> 
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="All broad leaf weeds">All broad leaf weeds</option> 
   </select>
   <?php }
    else if($ro=='td1'){
	 ?>
    <select name="dise[]" id="dise" class="dis" multiple="multiple" style="width:226px; height:35; border-radius:4px;">
    <option value="All broad leaf weeds">All broad leaf weeds</option> 
   <option value="dumbi sitti">dumbi sitti</option> 
   <option value="jangli jai">jangli jai</option>   
  <option value="All broad leaf weeds">All broad leaf weeds</option> 
   </select>
   <?php }
    ?>
   
   <?php } ?>