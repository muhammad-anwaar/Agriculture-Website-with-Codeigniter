<?php include('header.php'); ?>
<?php include('left_section.php'); ?>
  <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Fertilizer Recommender</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <h2>Enter The Following Information</h2>
        <form name="dform" id="dform" action="<?php echo base_url(); ?>index.php/s_recomender/recomends" method="post" style="margin-left:-2px;" onSubmit="return valid();" >
        <table align="center" width="750" cellpadding="2" cellspacing="2" style=" margin-top:20px;">
        <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Nitrogen</label> </td>
        <td style="">
        <select name="nitrogen" id="nitro" required="required" style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select Nitrogen</option>
        <option value="100">100 ppm</option>
        <option value="200">200 ppm</option>
        <option value="300">300 ppm</option>
        <option value="400">400 ppm</option>
        <option value="500">500 ppm</option>
        <option value="600">600 ppm</option>
        <option value="700">700 ppm</option>
        <option value="800">800 ppm</option>
        <option value="900">900 ppm</option>
        <option value="1000">1000 ppm</option>
         </select>
        </td>
        </tr>
        
                <tr align="center" style="margin-top:10px;">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Phosphorus</label> </td>
        <td style="">
        <select name="p" id="p" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select P</option>
        <option value="1">1 ppm</option>
        <option value="2">2 ppm</option>
        <option value="3">3 ppm</option>
        <option value="4">4 ppm</option>
        <option value="5">5 ppm</option>
        <option value="6">6 ppm</option>
        <option value="7">7 ppm</option>
        <option value="8">8 ppm</option>
        <option value="9">9 ppm</option>
        <option value="10">10 ppm</option>
        <option value="11">11 ppm</option>
        <option value="12">12 ppm</option>
        <option value="13">13 ppm</option>
        <option value="14">14 ppm</option>
        <option value="15">15 ppm</option>
         <option value="16">16 ppm</option>
        <option value="17">17 ppm</option>
        <option value="18">18 ppm</option>
        <option value="19">19 ppm</option>
        <option value="20">20 ppm</option>
        <option value="21">21 ppm</option>
         <option value="22">22 ppm</option>
        <option value="23">23 ppm</option>
        <option value="24">24 ppm</option>
        <option value="25">25 ppm</option>
        <option value="26">26 ppm</option>
        <option value="27">27 ppm</option>
         </select>
        </td>
        </tr>
        
        <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Potassium</label> </td>
        <td style="">
        <select name="k" id="k" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select K</option>
        <option value="100">100 ppm</option>
        <option value="110">110 ppm</option>
        <option value="120">120 ppm</option>
        <option value="130">130 ppm</option>
        <option value="140">140 ppm</option>
        <option value="150">150 ppm</option>
        <option value="160">160 ppm</option>
        <option value="170">170 ppm</option>
        <option value="180">180 ppm</option>
        <option value="190">190 ppm</option>
        <option value="200">200 ppm</option>
        
         </select>
        </td>
        </tr>
        
         <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Magnesium</label> </td>
        <td style="">
        <select name="mg" id="mg" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select MG</option>
       <option value="100">100 ppm</option>
        <option value="110">110 ppm</option>
        <option value="120">120 ppm</option>
        <option value="130">130 ppm</option>
        <option value="140">140 ppm</option>
        <option value="150">150 ppm</option>
        <option value="160">160 ppm</option>
        <option value="170">170 ppm</option>
        <option value="180">180 ppm</option>
        <option value="190">190 ppm</option>
        <option value="200">200 ppm</option>
        
         </select>
        </td>
        </tr>


         <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Sulphur</label> </td>
        <td style="">
        <select name="s" id="s" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select S</option>
        <option value="1">1 ppm</option>
        <option value="2">2 ppm</option>
        <option value="3">3 ppm</option>
        <option value="4">4 ppm</option>
        <option value="5">5 ppm</option>
        <option value="6">6 ppm</option>
        <option value="7">7 ppm</option>
         <option value="8">8 ppm</option>
        <option value="9">9 ppm</option>
        <option value="10">10 ppm</option>
       
        
         </select>
        </td>
        </tr>
        
         <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Iron</label> </td>
        <td style="">
        <select name="fe" id="fe" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select Fe</option>
         <option value="0.1">0.1 ppm</option>
        <option value="0.2">0.2 ppm</option>
         <option value="0.3">0.3 ppm</option>
        <option value="0.4">0.4 ppm</option>
         <option value="0.5">0.5 ppm</option>
        <option value="0.6">0.6 ppm</option>
         <option value="0.7">0.7 ppm</option>
        <option value="0.8">0.8 ppm</option>
         <option value="0.9">0.9 ppm</option>
        <option value="1.0">1.0 ppm</option>
        <option value="1.1">1.1 ppm</option>
        <option value="1.2">1.2 ppm</option>
        <option value="1.3">1.3 ppm</option>
        <option value="1.4">1.4 ppm</option>
        <option value="1.5">1.5 ppm</option>
        <option value="1.6">1.6 ppm</option>
        <option value="1.7">1.7 ppm</option>
         <option value="1.8">1.8 ppm</option>
        <option value="1.9">1.9 ppm</option>
        <option value="2.0">2.0 ppm</option>
       
       
        
         </select>
        </td>
        </tr>
        
          <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Manganese</label> </td>
        <td style="">
        <select name="mn" id="mn" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select MN</option>
        <option value="1">1 ppm</option>
        <option value="2">2 ppm</option>
        <option value="3">3 ppm</option>
        <option value="4">4 ppm</option>
        <option value="5">5 ppm</option>
        <option value="6">6 ppm</option>
        <option value="7">7 ppm</option>
         <option value="8">8 ppm</option>
        <option value="9">9 ppm</option>
        <option value="10">10 ppm</option>
       
        
         </select>
        </td>
        </tr>
        </tr>
        
          <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Calcium</label> </td>
        <td style="">
        <select name="ca" id="ca" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select CA</option>
        <option value="100">100 ppm</option>
        <option value="200">200 ppm</option>
        <option value="300">300 ppm</option>
        <option value="400">400 ppm</option>
        <option value="500">500 ppm</option>
        <option value="600">600 ppm</option>
        <option value="700">700 ppm</option>
         <option value="800">800 ppm</option>
        <option value="900">900 ppm</option>
        <option value="1000">1000 ppm</option>
       <option value="1100">1100 ppm</option>
        <option value="1200">1200 ppm</option>
        <option value="1300">1300 ppm</option>
        <option value="1400">1400 ppm</option>
        <option value="1500">1500 ppm</option>
        <option value="1600">1600 ppm</option>
        <option value="1700">1700 ppm</option>
         <option value="1800">1800 ppm</option>
        <option value="1900">1900 ppm</option>
        <option value="2000">2000 ppm</option>
        
         </select>
        </td>
        </tr>
        
           <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Zinc</label> </td>
        <td style="">
        <select name="zn" id="zn" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select ZN</option>
        <option value="0.01">0.01 ppm</option>
        <option value="0.02">0.02 ppm</option>
        <option value="0.03">0.03 ppm</option>
        <option value="0.04">0.04 ppm</option>
        <option value="0.05">0.05 ppm</option>
        <option value="0.06">0.06 ppm</option>
        <option value="0.07">0.07 ppm</option>
         <option value="0.08">0.08 ppm</option>
        <option value="0.09">0.09 ppm</option>
        <option value="0.10">0.10 ppm</option>
<!--       <option value="0.11">0.11 ppm</option>
       <option value="0.12">0.12 ppm</option>
       <option value="0.13">0.13 ppm</option>
       <option value="0.14">0.14 ppm</option>
       <option value="0.15">0.15 ppm</option>
        -->
         </select>
        </td>
        </tr>
         <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Potential Hydrogen</label> </td>
        <td style="">
        <select name="ph" id="ph" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select PH</option>
        <option value="1">1 ppm</option>
        <option value="2">2 ppm</option>
        <option value="3">3 ppm</option>
        <option value="4">4 ppm</option>
        <option value="5">5 ppm</option>
        <option value="6">6 ppm</option>
        <option value="7">7 ppm</option>
         <option value="8">8 ppm</option>
        <option value="9">9 ppm</option>
        <option value="10">10 ppm</option>
        <option value="11">11 ppm</option>
        <option value="12">12 ppm</option>
        <option value="13">13 ppm</option>
        <option value="14">14 ppm</option>
         </select>
        </td>
        </tr>
        <tr align="center">
        <td align="right"><label style="font-size:18px; margin-left:175px;">Crop</label> </td>
        <td style="">
        <select name="crop" id="crop" required autofocus style="margin-left:0px; border-radius:6px; width:240px; font-size:16px;" >
        <option>Select Crop</option>
        <option value="cotton">cotton</option>
        <option value="rice">rice</option>
        <option value="wheat">wheat</option>
        
         </select>
        </td>
        </tr>
        <tr align="center">
        <td align="right" </td>
        <td style="">  
       <input type="button" name="insert" id="rec" value="Recommendation">
        </td>
        </tr>
        <tr><td colspan="2"></td></tr>
        </table>
        </form>
        <div id="show"></div>
    </div>
    </div>
</div>
</div>
</article></div>
        
            <?php include('footer.php'); ?>
            
           <script type="text/javascript">
		   $('#rec').click(function(e) {
			   
				var y=document.forms.dform.nitrogen.value;
				if(y=='Select Nitrogen')
				{
					alert('Please Select Nitogen');
					return false;
					}
	
			var y1=document.forms.dform.k.value;
			
				if(y1=='Select K')
				{
					alert('Please Select k');
					return false;
					}
						
				var y2=document.forms.dform.mg.value;
				if(y2=='Select MG')
				{
					alert('Please Select mg');
					return false;
					}
					
						var y3=document.forms.dform.s.value;
				if(y3=='Select S')
				{
					alert('Please Select S');
					return false;
					}
						var y4=document.forms.dform.mn.value;
				if(y4=='Select MN')
				{
					alert('Please Select MN');
					return false;
					}
				var y5=document.forms.dform.zn.value;
				if(y5=='Select ZN')
				{
					alert('Please Select ZN');
					return false;
					}
					
					var y5=document.forms.dform.crop.value;
				if(y5=='Select Crop')
				{
					alert('Please Select CROP');
					return false;
					}	
							
				
				
			/*Validation end*/
            var nitrogen=$("#nitro").val();
			var p=$("#p").val();
			var k=$("#k").val();
			var mg=$("#mg").val();
			var fe=$("#fe").val();
			var mn=$("#mn").val();
			var zn=$("#zn").val();
			var s=$("#s").val();
			var ca=$("#ca").val();
			var ph=$("#ph").val();
			var crop=$("#crop").val();		
			$("#show").load("recomends",{"nitrogen":nitrogen,"k":k,"mg":mg,"mn":mn,"zn":zn,"s":s,"p":p,"fe":fe,"ca":ca,"ph":ph,"crop":crop});
        });
		   </script> 
			
            