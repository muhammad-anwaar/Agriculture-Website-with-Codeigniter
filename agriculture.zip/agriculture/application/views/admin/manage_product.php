
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Manage Product</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
       <center><p><?php if(!empty($msg)){
			echo $msg;
			
			} ?></p></center>
        <table align="center" border="1" width="750px" cellpadding="2" cellspacing="2" style=" margin:30px 0px 20px 150px;border-radius:6px; border-collapse:separate;">
        
        <tr></tr>
        <tr>
        <th>Product Name</th>
        <th>Common Name</th>
        <th>Formulation</th>
        <th>Pests</th>
        <th>Dosage</th>
        <th>Edit</th>
        <th>Delete</th>
        </tr>
        <?php foreach($row as $r): ?>
        <tr>
        <td><?php echo $r->product_name; ?></td>
        <td><?php echo $r->common_name ?></td>
        <td><?php echo $r->formulation; ?></td>
        <td><?php echo $r->pests; ?></td>
        <td><?php echo $r->dosage; ?></td>
        <td><a href="<?php echo base_url(); ?>index.php/product_management/upd?var1=<?php echo $r->cp_id; ?>"><img src="<?php echo base_url(); ?>images/edit.jpg" /></a></td>
        <td><a href="<?php echo base_url(); ?>index.php/product_management/delete?var1=<?php echo $r->cp_id; ?>"><img src="<?php echo base_url(); ?>images/delete.jpg" /></a></td>
        </tr>
        <?php endforeach ?>
        </table>
        
        <div style="float:left; width:100%; height:25px; background: #0F0;">
<span style="font-size:14px;"><?php echo $links; ?></span>
</div>
        <p></p>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            