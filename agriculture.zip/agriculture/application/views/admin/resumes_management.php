
 <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Reume Management</h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
    <p>Upload Image and html design  of template.</p>
    <p>
	<?php if(!empty($msg)){ ?>
	<?php  echo $msg; ?>
    <?php } ?>
    </p>
        <p align="left"><?php echo form_open_multipart('upload/create');?>

<input type="file" name="userfile" size="20" />
<label for="style">Name</label><input name="style_no" placeholder="like style 4" value=""/>
<textarea name="template" id="template"></textarea>

<input type="submit" value="upload" name="bt_sbmt" /></p>
        <p><br />
        </p>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
 