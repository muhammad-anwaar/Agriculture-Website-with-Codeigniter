<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Product Management</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
       <!-- <h2>The Product Info here.</h2>-->
        
        
       <p><a href="<?php echo base_url(); ?>index.php/product_management/add_product">Add Products</a></p>
        
        
        <p><a href="<?php echo base_url(); ?>index.php/product_management/manage_product">Manage Products</a></p>
        
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            