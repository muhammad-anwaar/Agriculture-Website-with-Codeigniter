<div class="art-layout-cell art-sidebar1 clearfix"><div class="art-vmenublock clearfix">
        <div class="art-vmenublockheader">
            <h3 class="t"><!--VMenu--></h3>
        </div>
        <div class="art-vmenublockcontent">
<ul class="art-vmenu">
<li><!--<a href="<?php echo base_url() ?>/index.php/admin/index" class="active">Home</a>--><ul class="active"><li></li>
<li><a href="<?php echo base_url() ?>/index.php/admin/home" class="active"><p style="font-size:20px;">Home</p></a>
<li><a href="<?php echo base_url() ?>/index.php/product_management/index"><p style="font-size:18px;">Product Manage</p></a></li>
<li><a href="<?php echo base_url() ?>/index.php/employee/emp_manage"><p style="font-size:18px;">Employee</p></a></li>
<li><a href="<?php echo base_url() ?>/index.php/customer/cust_in"><p style="font-size:18px;">Customer</p></a></li>
<li><a href="<?php echo base_url() ?>/index.php/employee/admin_rpt"><p style="font-size:18px;">Daily Reports</p></a></li>
<li><a href="<?php echo base_url() ?>index.php/admin/get_order"><p style="font-size:18px;">Order Manage</p></a></li>
<li><a href="<?php echo base_url() ?>index.php/recomender/mng_rec"><p style="font-size:18px;">Recomender</p></a></li>
<li><a href="<?php echo base_url() ?>/index.php/about_us/check_feed"><p style="font-size:18px;">Feed Back</p></a></li>
</ul></li><li><a href="<?php echo base_url() ?>/index.php/admin/logout"><p style="font-size:18px;">Log Out</p></a></li></ul>
                
        </div>
</div></div>