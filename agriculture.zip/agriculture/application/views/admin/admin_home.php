
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Home</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        WELCOME  <?php echo $this->session->userdata('admin_name'); ?> !!
        
        <!--<h2>The Total Users Are Folowing With Details.</h2>-->
       <p></p>
      
       <table cellpadding="2" cellspacing="2" border="1" width="250" style="margin-left:40px;">
       <tr>
       <td style="font-size:18px;">Total Customers</td>
     <?php   $i=0;
			 foreach($datas as $r)
			 {
				 $i++;
				 }
				 ?>
                 <td><?php echo $i; ?></td>
				 
       
       </tr>
        <tr>
       <td style="font-size:18px;">Total Dealers</td>
     <?php   $i=0;
			 foreach($datas1 as $r1)
			 {
				 $i++;
				 }
				 ?>
                 <td><?php echo $i; ?></td>
				 
       
       </tr>
        <tr>
       <td style="font-size:18px;">Total Employees</td>
     <?php   $i=0;
			 foreach($datas2 as $r2)
			 {
				 $i++;
				 }
				 ?>
                 <td><?php echo $i; ?></td>
				 
       
       </tr>
        <tr>
       <td style="font-size:18px;">Total Products</td>
     <?php   $i=0;
			 foreach($datas3 as $r3)
			 {
				 $i++;
				 }
				 ?>
                 <td><?php echo $i; ?></td>
				 
       
       </tr>
        <tr>
       <td style="font-size:18px;">Total Reports</td>
     <?php   $i=0;
			 foreach($datas4 as $r4)
			 {
				 $i++;
				 }
				 ?>
                 <td><?php echo $i; ?></td>
				 
       
       </tr>
       </table>
       <table cellpadding="2" cellspacing="2" border="1" width="250" style=" float: right;
    margin-right: 66px;
    margin-top: -134px;">
       <tr>
			<th colspan="2" style="font-size:24px">Reporting</th>	 
       
       </tr>
        <tr>
       <td style="font-size:18px;">Total Orders</td>
     <?php   $i=0;
			 foreach($datas5 as $r1)
			 {
				 $i++;
				 }
				 ?>
                 <td><?php echo $i; ?></td>
				 
       
       </tr>
        <tr>
       <td style="font-size:18px;">Complete</td>
     <?php   $i=0;
			 foreach($datas6 as $r2)
			 {
				 $i++;
				 }
				 ?>
                 <td><?php echo $i; ?></td>
				 
       
       </tr>
        <tr>
       <td style="font-size:18px;">Under Process</td>
     <?php   $i=0;
			 foreach($datas7 as $r3)
			 {
				 $i++;
				 }
				 
				 $j=0;
			 foreach($datas8 as $r3)
			 {
				 $j++;
				 }
				 ?>
                 <td><?php echo $i+$j; ?></td>
				 
       
       </tr>
        
       </table>
     
        
        <div align="center" style="margin-left:10px;"><h1 style="font-size: 40px;
    margin-left: 356px;
    position: absolute;">Latest Products</h1></div>
        <p></p>
        <table align="center" style=" margin-left: 36px;
    margin-top: 90px;" width="950" cellpadding="2" cellspacing="2" border="1">
        <tr>
        <th>SR No</th>
        <th>Product Name</th>
        <th>Common Name</th>
        <th>Date</th>
        <th>Crop</th>
        </tr>
        <?php
		$i=0;
		 foreach($row as $re): 
		 $i++;
		 ?>
        <tr>
        <td align="center"><?php echo $i; ?></td>
        <td align="center"><?php echo $re->product_name; ?></td>
        <td align="center"><?php echo $re->common_name; ?></td>
        <td align="center"><?php echo $re->insert_date; ?></td>
        <td align="center"><?php echo $re->crop; ?></td>
        </tr>
        <?php endforeach; ?>
        </table>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            
            