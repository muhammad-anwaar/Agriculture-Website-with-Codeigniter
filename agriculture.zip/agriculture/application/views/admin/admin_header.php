<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.0.0.58475 -->
    <meta charset="utf-8">
    <title>Home</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style_admin.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.responsive_admin.css" media="all">

    <script src="<?php echo base_url();?>uss/js/jquery.js"></script>
    <script src="<?php echo base_url();?>uss/js/script.js"></script>
    
<script type="text/javascript" src="<?php echo base_url();?>uss/js/jquery-1.2.6.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>uss/js/jquery-1.7.2.min.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>uss/js/ui.datepicker.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>/uss/js/jquery.validate.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>uss/js/jquery.maskedinput-1.2.2.js" ></script>
<script language="JavaScript" type="text/javascript" src="<?php echo base_url();?>uss/js/suggest.js"></script>
<meta name="description" content="Description">
<meta name="keywords" content="Keywords">

<script type="text/javascript">
 $(document).ready(function($) {
$('#gform').validate();
$('#date').mask('9999-19-39');
$('#date1').mask('9999-19-39');
});
;
	
</script>
   



<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 10px;padding-left: 10px;  }
.ie7 .post .layout-cell {border:none !important; padding:0 !important; }
.ie6 .post .layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>
<div id="art-main">

    <div class="art-sheet clearfix">
    
<header class="art-header clearfix">


    <div class="art-shapes">
<h1 class="art-headline" data-left="50.78%">
  <!--  <a href="#">Agriculture.com</a>-->
</h1>
<!--<h2 class="art-slogan" data-left="46.78%">Admin Panel</h2>-->


            </div>



                    
</header>
<div class="art-layout-wrapper clearfix">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">