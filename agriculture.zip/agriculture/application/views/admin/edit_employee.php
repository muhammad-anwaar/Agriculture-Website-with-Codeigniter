<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Product Management</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <form action="<?php echo base_url(); ?>index.php/employee/emp_update" method="post" name="gform" id="gform"
         enctype="multipart/form-data" style="margin:10px 0px 25px 70px" >
        <table align="center" border="0px" width="500" cellpadding="2" cellspacing="2" style="margin:5px 150px 0px 250px;" />
        <?php foreach($row as $r): ?>
        <tr>
        <td>employee Name</td><td><input type="text" name="emp_name" id="emp_name" value="<?php echo $r->emp_name; ?>" required                                  autofocus /></td>
        </tr>
        <tr>
        <td>email</td><td><input type="text" name="email" id="email" value="<?php echo $r->email; ?>" required autofocus /></td>
        </tr>
        <tr>
        <td>Password</td><td><input type="password" name="password" id="password" value="<?php echo $r->password ?>" required autofocus/></td>
        </tr>
        <tr>
        <td>address</td><td><input type="text" name="address" id="address" value="<?php echo $r->address; ?>" required autofocus /></td>
        </tr>
        <tr>
        <td>City</td><td><input type="text" name="city" id="city" value="<?php echo $r->city; ?>" required autofocus /></td>
        </tr>
        <tr>
        <td>State</td><td><input type="text" name="state" id="state" value="<?php echo $r->state; ?>" required autofocus /></td>
        </tr>
        <tr>
        <td>Country</td><td><input type="text" name="country" id="country" value="<?php echo $r->country; ?>" required autofocus /></td>
        </tr>
        <tr>
        <td>Date Of Birth</td><td><input type="text" name="db" id="date" value="<?php echo $r->db; ?>" required autofocus /></td>
        </tr>
        <tr>
        <td>Employee Area</td><td><input type="text" name="emp_area" id="emp_area" value="<?php echo $r->emp_area; ?>" required autofocus />
        <input type="hidden" name="emp_id" id="emp_id" value="<?php echo $r->emp_id; ?>" />
        </td>
        </tr>
        <tr><td></td><td> <input type="submit" value="Update" name="upd" /></td></tr>
        <?php endforeach ?>
        </table>
  </form>
        <p></p>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            