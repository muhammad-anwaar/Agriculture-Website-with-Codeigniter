
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">FeedBack</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        

        <table align="center" border="1" width="750px" cellpadding="2" cellspacing="2" style=" margin:30px 0px 20px 150px;border-radius:6px; border-collapse:separate;">
        
        <tr></tr>
        <tr>
        <th> Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
        <th>Action</th>
        </tr>
        <?php foreach($row as $r): ?>
        <tr>
        <td><?php echo $r->c_name; ?></td>
        <td><?php echo $r->c_email; ?></td>
        <td><?php echo $r->c_subject;?></td>
        <td><?php echo $r->c_message; ?></td>
        <td><a href="<?php echo base_url(); ?>index.php/about_us/del_fed?var1=<?php echo $r->c_id; ?>"><img src="http://Localhost/agriculture/images/delete.jpg"  /></a></td>
        </tr>
        <?php endforeach ?>
        </table>
        
        <div >
</div>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            
            