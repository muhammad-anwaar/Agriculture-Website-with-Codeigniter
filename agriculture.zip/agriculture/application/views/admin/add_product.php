<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Product Management</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <h2>The Product Info here.</h2>
        <p><?php echo $this->session->userdata('message'); ?></p>
        <form action="<?php echo base_url(); ?>index.php/product_management/product_insert" method="post" name="gform" id="gform"
         enctype="multipart/form-data" style="margin:10px 0px 25px 70px" >
        <table align="center" border="0px" width="500" cellpadding="2" cellspacing="2" style="margin:0px 150px 0px 250px;" />
        <tr></tr>
        <tr><td><label style="margin:0px 0px 0px 0px;">Product Name</label></td><td><input type="text" name="product_name" id="product_name"
         value="" required="required" autofocus="autofocus" title="Product Name Required" /></td></tr>
        <tr><td><label>Common Name</label></td><td><input type="text" name="common_name" id="common_name" value="" required="required" autofocus="autofocus" title="Common Name Required" /></td></tr>
        <tr><td><label>Formulation</label></td><td><input type="text" name="formulation" id="formulation" value="" required="required" autofocus="autofocus" title="Formulation Name Required" /></td></tr>
        <tr><td><label>Crop Name</label></td><td><input type="text" name="crop" id="crop" value="" required="required" autofocus="autofocus" title="Crop Name Required" /></td></tr>
        <tr><td><label>Pests Name</label></td><td><input type="text" name="pests" id="pests" value="" required="required" autofocus="autofocus" title="Pests Name Required" /></td></tr>
        <tr><td><label>Dosage</label></td><td><input type="text" name="dosage" id="dosage" value="" required="required" autofocus="autofocus" title="Dosage Name Required" /></td></tr>
        <tr><td><label>Product Image</label></td><td><input type="file" name="product_imag" id="product_imag" value="" required="required" autofocus="autofocus" title="Product Image Required" /></td></tr>
        <tr><td></td><td><input type="submit" name="insert" id="insert" value="Submit" /></td></tr>
         <tr></tr>
        </table>
        </form>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            