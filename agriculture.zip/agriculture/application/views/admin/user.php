
<table align="center" cellpadding="2" cellspacing="2">
    <form id="gform" method="post" action="<?php echo base_url(); ?>index.php/customer/add_cust" enctype="multipart/form-data" >
		<tr>
		<td>	<label for="user_name">User Name:<span style="color:red">*</label></td>
		<td>	<input type="text" id="user_name" name="user_name"
            pattern="[a-zA-Z0-9_-]{4,12}" autofocus required title="must be alphanumeric with length 4-12" value="<?php echo set_value('user_name'); ?>" /></td>
		</tr>        
		<tr>
		<td>	<label for="email">Your Email:<span style="color:red">*</label></td>
		<td>	<input type="text" id="email" name="email" value="<?php echo set_value('email'); ?>" required pattern="[^ @]*@[^ @]*" />
		</td>
        </tr>
		<tr>
		<td>	<label for="password">Password:<span style="color:red">*</label></td>
		<td>	<input type="password" id="password" name="password" type="password" pattern=".{5,}" title="Minmimum 5 letters or numbers." required autofocus value="<?php echo set_value('password'); ?>" onchange="form.con_password.pattern = this.value;" />
		</td></tr>
		<tr>
		<td>	<label for="con_password">Confirm Password:<span style="color:red">*</label></td>
		<td>	<input type="password" id="con_password" name="con_password" value="<?php echo set_value('con_password'); ?>" type="password" pattern=".{5,}" title=" Must match With Password." required required />
		</td></tr>
        <tr>
		<td>	<label for="first_name">First Name:<span style="color:red">*</label></td>
		<td>	<input type="text" id="first_name" name="first_name" value="<?php echo set_value('first_name'); ?>" required autofocus />
		</td></tr>      
        <tr>
		<td>	<label for="last_name">Last Name:<span style="color:red">*</label></td>
		<td>	<input type="text" id="last_name" name="last_name" value="<?php echo set_value('last_name'); ?>" required autofocus />
		</td>
        </tr>    
        <tr>
		<td>	<label for="address">Address:<span style="color:red">*</label></td>
		<td>	<input type="text" id="address" name="address" value="<?php echo set_value('address'); ?>" required autofocus />
		</td></tr>    
        <tr>
        
		<td>	<label for="city">City:<span style="color:red">*</label></td>
		<td>	<input type="text" id="city" name="city" value="<?php echo set_value('city'); ?>" required autofocus /></td>
		</tr>    
        <tr>
        
		<td>	<label for="state">State:<span style="color:red">*</label></td>
		<td>	<input type="text" id="state" name="state" value="<?php echo set_value('state'); ?>" required autofocus/>
		</td></tr>    
        <tr>
		<td>	<label for="country">Country:<span style="color:red">*</label></td>
		<td>	<input type="text" id="country" name="country" value="<?php echo set_value('country'); ?>" required autofocus />
		</td></tr>  
        <tr>
		<td>	<label for="phone">Phone Number:<span style="color:red">*</label></td>
		<td>	<input type="text" id="phone" name="phone" value="<?php echo set_value('phone'); ?>" required pattern="(\+?\d[- .]*){7,15}" title="international, national or local phone number"/>
		</td></tr>      
        <tr>
		<td>	<label for="dj">Date Of Joining:<span style="color:red">*</label></td>
		<td>	<input type="text" id="date" class="required" name="dj" value="<?php echo set_value('dj'); ?>"  />
		</td></tr>    
        <tr>
		<td>	<label for="dob">Date Of Bitrh:<span style="color:red">*</label></td>
		<td>	<input type="text" id="date1" class="required" name="dob" value="<?php echo set_value('dob'); ?>"  />
		</td></tr>    
        <tr>
		<td>	<label for="gender">Gender:<span style="color:red">*</label></td>
		<td>	<input type="radio" name="gender" id="gender" value="Male"  />Male
                <input type="radio" name="gender" id="gender" value="Female" />Female
		</td>          
		<tr>
		<td colspan="2" align="center">	<input type="submit" class="greenButton" value="Submit" />
		</td>
        
        </tr>

</table>
	<?php echo form_close(); ?>