
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Home</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        
    
        
        <div >

<div  style="font-size: 18px;
    margin-bottom: 24px;
    margin-left: 294px;
    margin-top: 20px;">Daily Reports</div>
<table align="center" width="700" cellpadding="2" cellspacing="2" border="1">
<tr>
<th>SR NO</th>
<th>Title</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php
$i=0;
 foreach($row as $r):
 $i++;
  ?>
<tr>
<td align="center"><?php echo $i; ?></td>
<td align="center"><?php echo $r->report_title; ?></td>
<td align="center"><?php echo $r->c_date; ?></td>
<td align="center"><a href="<?php echo base_url(); ?>index.php/employee/download1?rpt=<?php echo $r->report_id; ?>">View</a>/
<a href="<?php echo base_url(); ?>index.php/employee/del_rpt?rpt=<?php echo $r->report_id; ?>">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            
            