
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Product Management</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <form action="<?php echo base_url(); ?>index.php/product_management/product_update" method="post" name="gform" id="gform"
         enctype="multipart/form-data" style="margin:10px 0px 25px 70px" >
        <table align="center" border="0px" width="500" cellpadding="2" cellspacing="2" style="margin:5px 150px 0px 250px;" />
        <?php foreach($row as $r): ?>
        <tr>
        <td>Product Name</td><td><input type="text" name="product_name" id="product_name" value="<?php echo $r->product_name; ?>" /></td>
        </tr>
        <tr>
        <td>Common Name</td><td><input type="text" name="common_name" id="common_name" value="<?php echo $r->common_name; ?>" /></td>
        </tr>
        <tr>
        <td>Formulation</td><td><input type="text" name="formulation" id="formulation" value="<?php echo $r->formulation ?>"/></td>
        </tr>
        <tr>
        <td>Crop Name</td><td><input type="text" name="crop" id="crop" value="<?php echo $r->crop; ?>" /></td>
        </tr>
        <tr>
        <td>Pests</td><td><input type="text" name="pests" id="pests" value="<?php echo $r->pests; ?>" /></td>
        </tr>
        <tr>
        <td>Dosage</td><td><input type="text" name="dosage" id="dosage" value="<?php echo $r->dosage; ?>" /></td>
        </tr>
        <tr>
        <td>Product Image</td><td><img src="<?php echo base_url()."upload/".$r->product_imag; ?>" /></td>
        </tr>
        <tr><td><input type="hidden" name="id" id="id" value="<?php echo $r->cp_id; ?>" /></td><td><input type="file" name="product_imag" id="product_imag" value="" /></td></tr>
        <tr><td align="center" colspan="2"> <input type="submit" value="Update" name="upd" /></td></tr>
        <?php endforeach ?>
        </table>
  </form>
        <p></p>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            