<div id="shw">
<?php foreach($result as $row): ?>

<div  style="margin-bottom:10px;margin-top:10px;" align="center"><h1 style="font-size:18px; font-style:italic;"><?php echo $row->report_title; ?></h1></div>
		<table align="center" cellpadding="2" cellspacing="2">
		<tr>
		<td style="font-size:14px;">Farmer Name:</td>
		<td><?php echo $row->farmer_name; ?></td>
		</tr>
		<tr>
		<td style="font-size:14px;">Dealer Reference Name:</td>
		<td><?php echo $row->dealer_rf_name; ?></td>
		</tr>
		<tr>
		<td style="font-size:14px;">Date:</td>
		<td><?php echo $row->c_date; ?></td>
		</tr>
		<tr>
		<td style="font-size:14px;">Visited Area:</td>
		<td><?php echo $row->visited_area; ?></td>
		</tr>
		<tr>
		<td style="font-size:14px;">City:</td>
		<td><?php echo $row->city; ?></td>
		</tr>
		<tr>
		<td style="font-size:14px;">Description:</td>
		<td><?php echo $row->description; ?></td>
		</tr>
		</table>
        
        <?php endforeach; ?>
        </div>
        
        <div align="center" style="margin-top:10px;"><img 
src="http://Localhost/agriculture/images/pdf.jpg" style="width:193px; height:30px;" onClick=" return downloads();" /></div>

<script type="text/javascript">
function downloads()
{
							var DocumentContainer = document.getElementById('shw');
		                var WindowObject = window.open('', "PrintWindow",              "width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
	              	 WindowObject.document.writeln(DocumentContainer.innerHTML);
		             WindowObject.document.close();
		             WindowObject.focus();
		             WindowObject.print();
		             WindowObject.close();
	}
	
	</script>