<footer class="art-footer clearfix">
<p>Copyright © 2014. All Rights Reserved.</p>
</footer>

    </div>
</div>


</body></html>