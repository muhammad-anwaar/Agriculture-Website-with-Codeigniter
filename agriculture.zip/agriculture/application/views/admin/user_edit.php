<table align="center" cellpadding="2" cellspacing="2">
<?php //echo form_open("create_resume/registration"); ?>
    <form id="gform" method="post" action="<?php echo base_url(); ?>index.php/customer/edit_rec" enctype="multipart/form-data" style="margin:10px 0px 25px 70px" >
		<tr><?php foreach($row as $r): ?>
		<td>	<label for="user_name">Customer Name:</label></td>
		<td>	<input type="text" id="user_name" name="user_name"
            value="<?php echo $r->customer_name; ?>" /></td>
		</tr>        
		<tr>
		<td>	<label for="email">Your Email:</label></td>
		<td>	<input type="text" id="email" name="email" value="<?php echo $r->email; ?>" required pattern="[^ @]*@[^ @]*" />
		</td>
        </tr>
		<tr>
		<td>	<label for="password">Password:</label></td>
		<td>	<input type="password" id="password" name="password" type="password"  required autofocus value="<?php echo $r->password; ?>"  />
		</td></tr>
        <tr>
		<td>	<label for="first_name">First Name:</label></td>
		<td>	<input type="text" id="first_name" name="first_name" value="<?php echo $r->first_name; ?>" required autofocus />
		</td></tr>      
        <tr>
		<td>	<label for="last_name">Last Name:</label></td>
		<td>	<input type="text" id="last_name" name="last_name" value="<?php echo $r->last_name; ?>" required autofocus />
		</td>
        </tr>    
        <tr>
		<td>	<label for="address">Address:</label></td>
		<td>	<input type="text" id="address" name="address" value="<?php echo $r->address; ?>" required autofocus />
		</td></tr>    
        <tr>
        
		<td>	<label for="city">City:</label></td>
		<td>	<input type="text" id="city" name="city" value="<?php echo $r->city; ?>" required autofocus /></td>
		</tr>        
        <tr>
		<td>	<label for="country">Country:</label></td>
		<td>	<input type="text" id="country" name="country" value="<?php echo $r->country; ?>" required autofocus />
		</td></tr>  
        <tr>
		<td>	<label for="phone">Phone Number:</label></td>
		<td>	<input type="text" id="phone" name="phone" value="<?php echo $r->phone; ?>" required pattern="(\+?\d[- .]*){7,15}" title="international, national or local phone number"/>
		</td></tr>      
        <tr>
		<td>	<label for="dj">Date Of Joining:</label></td>
		<td>	<input type="text" id="date" class="required" name="dj" value="<?php echo $r->dj; ?>"  />
		</td></tr>    
        <tr>
		<td>	<label for="dob">Date Of Bitrh:</label></td>
		<td>	<input type="text" id="date1" class="required" name="dob" value="<?php echo $r->dob; ?>"  />
                 <input type="hidden" name="customer_id" id="customer_id" value="<?php echo $r->customer_id  ?>" />
		</td></tr>
        <?php if($r->gender=='Male') {?>   
        <tr>
		<td>	<label for="gender">Gender:</label></td>
		<td>	<input type="radio" id="gender" name="gender" checked="checked" value="<?php echo $r->gender; ?>" required autofocus />Male.
        <input type="radio" id="gender" name="gender" value="Female" required autofocus />Female.
        
		</td>
        </tr>
        <?php } ?>
        <?php if($r->gender=='Female') {?>   
        <tr>
		<td>	<label for="gender">Gender:</label></td>
		<td>	<input type="radio" id="gender" name="gender" value="Male" required autofocus />Male.
        <input type="radio" id="gender" name="gender" checked="checked" value="<?php echo $r->gender; ?>" required autofocus />Female.
        
		</td>
        </tr>
        <?php } ?>
        <?php endforeach ?>          
		<tr>
            
		<td colspan="2" align="center">	<input type="submit" class="greenButton" value="Update" />
		</td>
        
        </tr>

</table>
	<?php echo form_close(); ?>