
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Manage Order</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
 
        <table align="center" border="1" width="750px" cellpadding="2" cellspacing="2" style=" margin:30px 0px 20px 150px;border-radius:6px; border-collapse:separate;">
        
        <tr></tr>
        <tr>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Date</th>
        <th>Type</th>
        <th>ID</th>
        <th>Name</th>
        <th>City</th>
        <th>Action</th>
        </tr>
        <?php foreach($row as $r): ?>
        <tr>
        <td><?php echo $r->order_product; ?></td>
        <td><?php echo $r->order_quantity; ?></td>
        <td><?php echo $r->order_date; ?></td>
        <td><?php echo $r->order_type; ?></td>
        <td><?php 
		if($r->customer_id!=0){
		echo $r->customer_id;
		}
		else 
		{ echo $r->dealer_id; }
		?></td>
        <td><?php echo $r->c_d_name; ?></td>
        <td><?php echo $r->order_city; ?></td>
        <td><a href="<?php echo base_url(); ?>index.php/admin/mng_order?var1=<?php echo $r->order_id; ?>">Proceed</a></td>
        </tr>
        <?php endforeach ?>
        </table>
        
        <div >

</div>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            
            