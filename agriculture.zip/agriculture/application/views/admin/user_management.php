
 <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Manage users</h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
                                
    <div class="art-content-layout-row">
    
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <p><ul>
        <li><a href="<?php echo base_url() ?>/index.php/management/new_user">Add New User</a></li>
        <li><a href="<?php echo base_url() ?>/index.php/management/del_user">Delete User</a></li>
        
        </ul></p>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            