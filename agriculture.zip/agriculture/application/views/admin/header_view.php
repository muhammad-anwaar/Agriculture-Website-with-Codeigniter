<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.0.0.58475 -->
    <meta charset="utf-8">
    <title>Home</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style_admin.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.responsive_admin.css" media="all">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/default.css" />

    <script src="<?php echo base_url(); ?>javascript/jquery.js"></script>
    <script src="<?php echo base_url(); ?>javascript/script.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>javascript/zebra_datepicker.js"></script>
    <script >
    $(document).ready(function() {

    // assuming the controls you want to attach the plugin to 
    // have the "datepicker" class set
    $('#date').Zebra_DatePicker();

 });
    $(document).ready(function() {

    // assuming the controls you want to attach the plugin to 
    // have the "datepicker" class set
    $('#date1').Zebra_DatePicker();

 });
    </script>
 
   



<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 10px;padding-left: 10px;  }
.ie7 .post .layout-cell {border:none !important; padding:0 !important; }
.ie6 .post .layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>
<div id="art-main">

    <div class="art-sheet clearfix">
    
<header class="art-header clearfix">
<nav class="art-nav clearfix">
    <ul class="art-hmenu">
    <li><a href="<?php echo base_url() ?>/index.php/admin/home" class="active">Home</a><ul class="active">
    <li><a href="<?php echo base_url() ?>/index.php/product_management/index">Product Management</a></li>
    <li><a href="<?php echo base_url() ?>/index.php/employee/emp_manage">Employee Management</a></li>
    <li><a href="<?php echo base_url() ?>/index.php/customer/cust_in">Customer Management</a></li>
   <li><a href="<?php echo base_url() ?>/index.php/employee/admin_rpt">Daily Reports</a></li>
   <li><a href="<?php echo base_url() ?>index.php/recomender/mng_rec">Manage Recomender</a></li>
   <li><a href="<?php echo base_url() ?>index.php/admin/get_order">Order Manage</a></li>
    <li><a href="<?php echo base_url() ?>/index.php/about_us/check_feed">Feed Back</a></li></ul></li></ul> 
    </nav>

    <div class="art-shapes">
<h1 class="art-headline" data-left="43.78%">
 <!--   <a href="#">Online Resume Builder</a>-->
 Admin Panel
</h1>
<h1 class="art-slogan" data-left="46.78%"></h1>


            </div>



                    
</header>
<div class="art-layout-wrapper clearfix">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">