
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Manage Recomender</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >

        <p>
        <a href="<?php echo base_url(); ?>index.php/admin/add_crop">Add Crop</a>
        </p>
        <p>
        <a href="<?php echo base_url(); ?>index.php/admin/add_varity">Add Varity</a>
        </p>
        <p>
        <a href="<?php echo base_url() ?>index.php/recomender/mng_rec">Add Product & Other Info</a>
        </p>
        <div >

</div>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            
            