
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Home</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        WELCOME  <?php echo $this->session->userdata('admin_name'); ?> !!
        
        <h2>The Total Users Are Folowing With Details.</h2>
       <p></p>
       <center>
       <table align="center" width="700" cellpadding="2" cellspacing="2" border="1">
        <th>Person Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th colspan="2">Message</th>
        
        <tr>
        <?php foreach($row1 as $r): ?>
         <td><?php echo $r->c_name; ?></td>
         <td><?php echo $r->email; ?></td>
         <td><?php echo $r->subject; ?></td>
         <td colspan="2"><?php echo $r->message; ?> </td>
         
        </tr>
        <?php endforeach ?>
       </table>
       <p><?php echo $links; ?></p> 
       </center>
        
        
        <p></p>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            
            