


<center>
<h2 class="style6">ADMIN LOGIN</h2>
</center>
<p>&nbsp;</p>
<center>  <h4>Enter Your Login and Password</h4></center>
  
  <form  id="admin_login"action="<?php echo base_url()?>index.php/admin/admin_login" method="post">

      <label>Login<span style="color:red">* </label>
      <?php if(!empty($error_msg)){?>
						<p><?php echo $error_msg?></p>
                        
						<?php }?>
      <div class="cleaner_h40"><p>
      <input type="text" name="login" size="30" required="required" autofocus="autofocus" title="Must Required"/>
      </p>
      <p>
      <label>Password<span style="color:red">*<br />
      <input type="password" name="password" size="30" required="required" autofocus="autofocus" title="Must Required" />
      </label>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
      <button type="submit" value="submit">LOG IN</button>
   
     </div>
  
  </form>
  
 

  <div class="fepro">
  </div>
  </div>
