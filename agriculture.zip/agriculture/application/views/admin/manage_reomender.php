<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader">Pestiside Recomender</h2>
                                                            
                                    </div>
    <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <h2>The Recomender Info here.</h2>
        <p><?php
		if(!empty($msg)){
			
			echo $msg;
			}
		 ?></p>
        <form action="<?php echo base_url(); ?>index.php/product_management/product_insert1" method="post" name="gform" id="gform"
         enctype="multipart/form-data" style="margin:10px 0px 25px 70px" >
        <table align="center" border="0px" width="500" cellpadding="2" cellspacing="2" style="margin:0px 150px 0px 250px;" />
        <tr></tr>
<tr><td><label style="margin:0px 0px 0px 0px;">Product Name</label></td><td><input type="text" name="product_name" id="product_name"
         value="" required="required" autofocus="autofocus" title="Product Name Required" /></td></tr>
        <tr><td><label>Common Name</label></td><td><input type="text" name="common_name" id="common_name" value=""  /></td></tr>
        <tr><td><label>Formulation</label></td><td><input type="text" name="formulation" id="formulation" value="" /></td></tr>
        <tr><td><label>Crop Name</label></td><td><input type="text" name="crop" id="crop" value="" /></td></tr>
        <tr><td><label>Varity Name</label></td><td><input type="text" name="v_name" id="v_name" value=""  /></td></tr>
        <tr><td><label>Pests Name</label></td><td><input type="text" name="pests" id="pests" value=""  /></td></tr>
        <tr><td><label>Dosage</label></td><td><input type="text" name="dosage" id="dosage" value=""  /></td></tr>
        <tr><td><label>Product Image</label></td><td><input type="file" name="product_imag" id="product_imag" value=""   /></td></tr>
        <tr><td><label>Diseage Image</label></td><td><input type="file" name="dis_img" id="dis_img" value=""   /></td></tr>
        <tr><td></td><td><input type="submit" name="insert" id="insert" value="Submit" /></td></tr>
         <tr></tr>
        </table>
        </form>
    </div>
    </div>
</div>
</div>
</article></div>
                    </div>
                </div>
            </div>
            