 <?php include('header.php'); ?>
 <?php include('left_section.php'); ?>
  <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Products</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
      <p style="margin-top:20px; margin-left:20px;">
        <a href="<?php echo base_url(); ?>index.php/product/fertilizer"><img src="http://Localhost/agriculture/images/fertilizer.png">
        </a>
        &nbsp;&nbsp;&nbsp;
        <a href="<?php echo base_url(); ?>index.php/product/index1">
        <img src="http://Localhost/agriculture/images/pestiside.png"></a>
        </p>
        
        
        
   
    </div>
    </div>
</div>
</article>
</div>

                   
                
           
            <?php include('footer.php'); ?>
             </div>