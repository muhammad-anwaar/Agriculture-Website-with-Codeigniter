<div id="content">
<div class="signup_wrap">
<div class="signin_form">
	<?php echo form_open("create_resume/login"); ?>
	    <label for="username">User Name:</label>
    	<input type="text" id="username" name="username" value="" />
	    <label for="pass">Password:</label>
		<input type="password" id="pass" name="pass" value="" />
        <input type="submit" class="" value="Sign in" />
    <?php echo form_close(); ?>
</div><!--<div class="signin_form">-->
</div><!--<div class="signup_wrap">-->
<h1 style="color:#960">Thanks! Please enter user name and password to proceed.</h1>
</div><!--<div id="content">-->