<?php include('header.php'); ?>
<?php include('left_emp.php'); ?>
<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon"> Manage Reports</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">



<div align="center" style="margin-top:20px;"><h1 style="font-size:16px; font-style:italic">Daily Reports</h1></div>
<table  border="1" style="margin: 52px 45px;
    width: 750px;" cellpadding="2" cellspacing="2" align="center">
    <tr background="http://Localhost/agriculture/images/bg-body.png">
<td align="center" style="font-size:18px;">SR NO</td>
<td align="center" style="font-size:18px;">Title</td>
<td align="center" style="font-size:18px;">Date</td>
<td align="center" style="font-size:18px;">Action</td>
</tr>
<?php
$i=0;
 foreach($rpt as $row):
$i++;
  ?>
<tr>
<td align="center" style="font-size:12px;"><?php echo $i; ?></td>
<td align="center" style="font-size:12px;"><?php echo $row->report_title; ?></td>
<td align="center" style="font-size:12px;"><?php echo $row->c_date; ?></td>
<td align="center" style="width:155px;"><a href="<?php echo base_url(); ?>index.php/employee/download?rpt=<?php echo $row->report_id; ?>"><img 
src="http://Localhost/agriculture/images/pdf.jpg" style="width:193px; height:30px;" /></a></td>
</tr>
<?php endforeach; ?>
</table>
<div style="margin-left:20px;"><a href="<?php echo base_url(); ?>index.php/employee/mng"><INPUT TYPE="button" VALUE="Back"></a></div>






</div>
</article>
</div>






<?php include('footer.php'); ?>