<?php include('header.php'); ?>
<?php include('left_section.php'); ?>

<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Reset Password</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">




<center>  <h2>Enter Your Email</h2></center>
  
  <form style="margin: 20px 0px 0px 240px; width:300px;"  id="admin_login"action="<?php echo base_url()?>index.php/customer/current_pass_val2" method="post" onSubmit="return valid();">

<table align="center" width="600">
<?php
 foreach($res_gal1 as $row){ ?>
<tr>
<td> <label>Email<span style="color:red">* </label></td>
<td><input type="text" name="email" size="30" value="<?php echo $row->email; ?>" required autofocus title="Must Required"/></td>
</tr>
<?php } ?>
<tr>
<td> <label for="password">Password:</label></td>
<td><input type="password" id="password" name="password" type="password" pattern=".{5,}" title="Minmimum 5 letters or numbers." required autofocus value="" onchange="form.con_password.pattern = this.value;" /></td>
</tr>
<tr>
<td> <label for="con_password">Confirm Password:</label></td>
<td><input type="password" id="con_password" name="con_password" value="" type="password" pattern=".{5,}" title=" Must match With Password." required required /></td>
</tr>
<tr>
<td colspan="2" align="center"><button style="margin-top:10px;" type="submit" value="submit">Submit</button></td>
</tr>
</table>
     
      <div class="cleaner_h40"><p>

      
     </form>
     </div>
  
  <a style="margin-left:40px;" href="<?php echo base_url(); ?>index.php/employee/index"><button>Back</button></a>

  <div class="fepro">
  </div>
  </div>
  
  </div>
</article>
</div>

<?php include('footer.php'); ?>
