<?php include('header.php'); ?>
<?php include('left_cust.php'); ?>
<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon"> Your Orders</span></h2>
                                            <div style="float:right; font-size:18px;"><?php echo $this->session->userdata('dealer_name'); ?></div>                
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">




</p>
 <table align="center" border="1" cellpadding="2" cellpadding="2" width="680px" style=" margin:30px 0px 0px 0px;border-radius:6px;">
 
 <tr></tr>
<tr bgcolor="#33FF33">
<th>Product Name</th>
<th>Quantity</th>
<th>Order Date</th>
<th>Address</th>
<th>Order Status</th>
</tr> 
<?php foreach($row as $r): ?>
 <tr>
 <td><b><?php echo $r->order_product; ?></b></td>
 <td><?php echo $r->order_quantity ?></td>
 <td><?php echo $r->order_date; ?></td>
 <td><?php echo $r->order_address.','.$r->order_city.','.$r->order_state.','.$r->order_country; ?></td>
 <?php  if($r->order_status==0)
 { ?>
 <td><?php echo "OrderUnder Process"; ?></td>
 <?php } ?>
 
  <?php  if($r->order_status==1)
 { ?>
 <td><?php echo "Order Forwed"; ?></td>
 <?php } ?>
 
  <?php  if($r->order_status==3)
 { ?>
 <td><?php echo "Order Compeleted"; ?></td>
 <?php } ?>
 
 </tr>
 <?php endforeach ?>
 </table>
  
</div>

</div>
</article>
</div>
<?php include('footer.php'); ?>