<div class="content">
	<h2>Welcome , <?php echo $this->session->userdata('user_name'); ?>!</h2>


<?php echo form_open_multipart('upload/do_upload');?>

<input type="file" name="userfile" size="20" />

<br /><br />

<input type="submit" value="upload" name="bt_sbmt" />

</form>
   
   
   </div>

     <p style="background-color:#0C6">This section represents the area that only logged in members can access.</p>
	

</div><!--<div class="content">-->