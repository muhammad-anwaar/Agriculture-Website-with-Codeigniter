<?php //include('header.php'); ?>
<?php //include('left_section.php'); ?>
<!--  <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Soil Recommender</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >-->
        <!--<h2>Enter The Following Information</h2>-->
        <div id="soil">
        <div align="center" style="font-size:24px; font-style:italic;">Rehan Agro Chemicals(pvt)Limited</div>
        
        <?php foreach($result as $row):
		$c_name=$row->crop;
		if($c_name=='cotton'){
		 ?>
          <table align="center" width="700" cellpadding="2" cellspacing="2">
        <tr><td><label style="font-size:16px;">Crop Name</label></td><td ><label style="font-size:14px"><?php echo $c_name; ?></label></td></tr>
        <tr><td><label style="font-size:16px;">Date</label></td><td><label style="font-size:14px"><?php echo date('Y-M-d'); ?></label></td></tr>
        </table>
        <table align="center" width="700" cellpadding="2" cellspacing="2" border="1" style="margin-top:25px; border-radius:5px;">
        
        
        <tr style="background: #999;">
        <th >Elements</th>
        <th >Test Results</th>
        <th >Interpretations</th>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">N</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->n; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->n>=100 && $row->n<=499)
		{  echo "Low"; } else if(($row->n>=500 && $row->n<=799))
		{ echo "Adequate";}
		else if(($row->n>=800 && $row->n<=1000))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">K</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->k; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->k>=100 && $row->k<=150)
		{  echo "Low"; } else if(($row->k>=151 && $row->k<=170))
		{ echo "Adequate";}
		else if(($row->k>=171 && $row->k<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Mg</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mg; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mg>=100 && $row->mg<=150)
		{  echo "Low"; }
		 else if(($row->mg>=151 && $row->mg<=170))
		{ echo "Adequate";}
		else if(($row->mg>=171 && $row->mg<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">S</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->s; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->s>=1 && $row->s<=4)
		{  echo "Low"; }
		 else if(($row->s>=5 && $row->s<=7))
		{ echo "Adequate";}
		else if(($row->s>=8 && $row->s<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Mn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mn>=1 && $row->mn<=4)
		{  echo "Low"; }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ echo "Adequate";}
		else if(($row->mn>=8 && $row->mn<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Zn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->zn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->zn>=0.01 && $row->zn<=0.04)
		{  echo "Low"; }
		 else if(($row->zn>=0.05 && $row->zn<=0.07))
		{ echo "Adequate";}
		else if(($row->zn>=0.08 && $row->zn<=0.10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Ca</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $ca; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($ca>=1 && $ca<=800)
		{  echo "Low"; }
		 else if(($ca>=900 && $ca<=1100))
		{ echo "Adequate";}
		else if(($ca>=1200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">P</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $p; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($p>=1 && $p<=10)
		{  echo "Low"; }
		 else if(($p>=11 && $p<=12))
		{ echo "Adequate";}
		else if(($p>=13))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Fe</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $fe; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($fe>=0.01 && $fe<=0.09)
		{  echo "Low"; }
		 else if(($fe>=0.10 && $fe<=0.12))
		{ echo "Adequate";}
		else if(($fe>=0.13))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">PH</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $ph; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($ph>=1 && $ph<=6)
		{  echo "Low"; }
		 else if(($ph==7))
		{ echo "Adequate";}
		else if(($ph>=8 ))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        </table>
        <div align="center"><h2 style="font-style:italic;">The System Recomends Following </h2></div>
        <?php if($row->n>=100 && $row->n<=499)
		{ 
		?>
		 <div align="center">
         <strong>Nitrogen in Low Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/urea.jpg" width="270"  />
         </div>
         <?php } 
		 else if(($row->n>=500 && $row->n<=799))
		{ 
		?>
		<div align="center">
        <strong>Nitrogen in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/urea.jpg" width="270"  /></div>
        
        <?php }

		///////////////////////////ca///////////////////////
		if($ca>=1 && $ca<=800)
		{ 
		?>
		 <div align="center">
         <strong>CA in Low Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div> 
         <?php
         }
		 else if(($ca>=900 && $ca<=1100))
		{ ?>
        <div align="center">
        <strong>CA in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div> 
        <?php
        }
		
		//////////////////////////P/////////////////////////
		if($p>=1 && $p<=10)
		{ ?>
        <div align="center">
        <strong>P in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php }
		 else if(($p>=11 && $p<=12))
		{ ?>
        <div align="center">
        <strong>P in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div>
        <?php }
		
		//////////////////////////fe////////////////////////
		if($fe>=0.01 && $fe<=0.09)
		{ ?>
        <div align="center">
        <strong>Fe in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/dap.jpg" width="270"  /></div>
        <?php }
		 else if(($fe>=0.10 && $fe<=0.12))
		{ ?>
        <div align="center">
        <strong>Fe in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/dap.jpg" width="270"  /></div>
        <?php }
		
		////////////////////////////k///////////////////////
	 if($row->k>=100 && $row->k<=150)
		{
			?>
			<div align="center">
            <strong>K in Low Quantity</strong>
         <br />
            <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div>
             <?php 
               } else if(($row->k>=151 && $row->k<=170))
		{ 
		?>
		<div align="center">
        <strong>K in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div>
        <?php
        }
		
		///////////////////////////////mg////////////////////////////////////////
		if($row->mg>=100 && $row->mg<=150)
		{  ?> 
		<div align="center">
        <strong>MG in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div>
		<?php }
		 else if(($row->mg>=151 && $row->mg<=170))
		{ ?>
         <div align="center">
         <strong>MG in Adequate Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div> 
		 <?php }
	
		///////////////////////////////////////s/////////////////////////////////
		if($row->s>=1 && $row->s<=4)
		{ 
		?><div align="center">
        <strong>S in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php
		 }
		 else if(($row->s>=5 && $row->s<=7))
		{ ?> <div align="center">
        <strong>S in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php
		}
		/////////////////////////////////mn/////////////////////////////////
		if($row->mn>=1 && $row->mn<=4)
		{  ?>
        <div align="center">
        <strong>Mn in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/WellRicher.jpg" width="270"  /></div>
        <?php }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ ?>
        <div align="center">
        <strong>Mn in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/WellRicher.jpg" width="270"  /></div>
        <?php }
		////////////////////////////////////zn/////////////////////////////////
		if($row->zn>=0.01 && $row->zn<=0.04)
		{ ?>
        <div align="center">
        <strong>Zn in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zingro.jpg" width="270"  /></div>
        <?php
         }
		 else if(($row->zn>=0.05 && $row->zn<=0.07))
		{ ?>
        
        <div align="center">
        <strong>Zn in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zingro.jpg" width="270"  /></div>
        <?php }
		 ?>
        <?php } 
		else if($c_name=='rice')
		{
			?>
            
		
          <table align="center" width="700" cellpadding="2" cellspacing="2">
        <tr><td><label style="font-size:16px;">Crop Name</label></td><td ><label style="font-size:14px"><?php echo $c_name; ?></label></td></tr>
        <tr><td><label style="font-size:16px;">Date</label></td><td><label style="font-size:14px"><?php echo date('Y-M-d'); ?></label></td></tr>
        </table>
        <table align="center" width="700" cellpadding="2" cellspacing="2" border="1" style="margin-top:25px; border-radius:5px;">
        
        
        <tr style="background: #999;">
        <th >Elements</th>
        <th >Test Results</th>
        <th >Interpretations</th>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">N</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->n; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->n>=100 && $row->n<=499)
		{  echo "Low"; } else if(($row->n>=500 && $row->n<=799))
		{ echo "Adequate";}
		else if(($row->n>=800 && $row->n<=1000))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">K</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->k; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->k>=100 && $row->k<=150)
		{  echo "Low"; } else if(($row->k>=151 && $row->k<=170))
		{ echo "Adequate";}
		else if(($row->k>=171 && $row->k<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Mg</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mg; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mg>=100 && $row->mg<=150)
		{  echo "Low"; }
		 else if(($row->mg>=151 && $row->mg<=170))
		{ echo "Adequate";}
		else if(($row->mg>=171 && $row->mg<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">S</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->s; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->s>=1 && $row->s<=4)
		{  echo "Low"; }
		 else if(($row->s>=5 && $row->s<=7))
		{ echo "Adequate";}
		else if(($row->s>=8 && $row->s<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Mn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mn>=1 && $row->mn<=4)
		{  echo "Low"; }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ echo "Adequate";}
		else if(($row->mn>=8 && $row->mn<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Zn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->zn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->zn>=0.01 && $row->zn<=0.04)
		{  echo "Low"; }
		 else if(($row->zn>=0.05 && $row->zn<=0.07))
		{ echo "Adequate";}
		else if(($row->zn>=0.08 && $row->zn<=0.10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
                <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Ca</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $ca; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($ca>=1 && $ca<=800)
		{  echo "Low"; }
		 else if(($ca>=900 && $ca<=1100))
		{ echo "Adequate";}
		else if(($ca>=1200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">P</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $p; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($p>=1 && $p<=10)
		{  echo "Low"; }
		 else if(($p>=11 && $p<=12))
		{ echo "Adequate";}
		else if(($p>=13))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Fe</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $fe; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($fe>=0.01 && $fe<=0.09)
		{  echo "Low"; }
		 else if(($fe>=0.10 && $fe<=0.12))
		{ echo "Adequate";}
		else if(($fe>=0.13))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">PH</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $ph; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($ph>=1 && $ph<=6)
		{  echo "Low"; }
		 else if(($ph==7))
		{ echo "Adequate";}
		else if(($ph>=8 ))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        </table>
            <div align="center"><h2 style="font-style:italic;">The System Recomends Following </h2></div>
        <?php if($row->n>=100 && $row->n<=499)
		{ 
		?>
		 <div align="center">
         <strong>Nitrogen in Low Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/urea.jpg" width="270"  />
         </div>
         <?php } 
		 else if(($row->n>=500 && $row->n<=799))
		{ 
		?>
		<div align="center">
        <strong>Nitrogen in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/urea.jpg" width="270"  /></div>
        
        <?php }

		///////////////////////////ca///////////////////////
		if($ca>=1 && $ca<=800)
		{ 
		?>
		 <div align="center">
         <strong>CA in Low Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div> 
         <?php
         }
		 else if(($ca>=900 && $ca<=1100))
		{ ?>
        <div align="center">
        <strong>CA in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div> 
        <?php
        }
		
		//////////////////////////P/////////////////////////
		if($p>=1 && $p<=10)
		{ ?>
        <div align="center">
        <strong>P in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php }
		 else if(($p>=11 && $p<=12))
		{ ?>
        <div align="center">
        <strong>P in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/SuperKissan.jpg" width="270"  /></div>
        <?php }
		
		//////////////////////////fe////////////////////////
		if($fe>=0.01 && $fe<=0.09)
		{ ?>
        <div align="center">
        <strong>Fe in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Energizer.jpg" width="270"  /></div>
        <?php }
		 else if(($fe>=0.10 && $fe<=0.12))
		{ ?>
        <div align="center">
        <strong>Fe in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Energizer.jpg" width="270"  /></div>
        <?php }
		
		////////////////////////////k///////////////////////
	 if($row->k>=100 && $row->k<=150)
		{
			?>
			<div align="center">
            <strong>K in Low Quantity</strong>
         <br />
            <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div>
             <?php 
               } else if(($row->k>=151 && $row->k<=170))
		{ 
		?>
		<div align="center">
        <strong>K in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div>
        <?php
        }
		
		///////////////////////////////mg////////////////////////////////////////
		if($row->mg>=100 && $row->mg<=150)
		{  ?> 
		<div align="center">
        <strong>MG in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Cheeta-SOP.jpg" width="270"  /></div>
		<?php }
		 else if(($row->mg>=151 && $row->mg<=170))
		{ ?>
         <div align="center">
         <strong>MG in Adequate Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Cheeta-SOP.jpg" width="270"  /></div> 
		 <?php }
	
		///////////////////////////////////////s/////////////////////////////////
		if($row->s>=1 && $row->s<=4)
		{ 
		?><div align="center">
        <strong>S in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php
		 }
		 else if(($row->s>=5 && $row->s<=7))
		{ ?> <div align="center">
        <strong>S in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php
		}
		/////////////////////////////////mn/////////////////////////////////
		if($row->mn>=1 && $row->mn<=4)
		{  ?>
        <div align="center">
        <strong>Mn in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>4 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Cheeta-MOP.jpg" width="270"  /></div>
        <?php }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ ?>
        <div align="center">
        <strong>Mn in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Cheeta-MOP.jpg" width="270"  /></div>
        <?php }
		////////////////////////////////////zn/////////////////////////////////
		if($row->zn>=0.01 && $row->zn<=0.04)
		{ ?>
        <div align="center">
        <strong>Zn in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zingro.jpg" width="270"  /></div>
        <?php
         }
		 else if(($row->zn>=0.05 && $row->zn<=0.07))
		{ ?>
        
        <div align="center">
        <strong>Zn in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zingro.jpg" width="270"  /></div>
        <?php }
		 ?>
        <?php 
			
			}
			else 
			{
		?>
        
		 
          <table align="center" width="700" cellpadding="2" cellspacing="2">
        <tr><td><label style="font-size:16px;">Crop Name</label></td><td ><label style="font-size:14px"><?php echo $c_name; ?></label></td></tr>
        <tr><td><label style="font-size:16px;">Date</label></td><td><label style="font-size:14px"><?php echo date('Y-M-d'); ?></label></td></tr>
        </table>
        <table align="center" width="700" cellpadding="2" cellspacing="2" border="1" style="margin-top:25px; border-radius:5px;">
        
        
        <tr style="background: #999;">
        <th >Elements</th>
        <th >Test Results</th>
        <th >Interpretations</th>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">N</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->n; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->n>=100 && $row->n<=499)
		{  echo "Low"; } else if(($row->n>=500 && $row->n<=799))
		{ echo "Adequate";}
		else if(($row->n>=800 && $row->n<=1000))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">K</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->k; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->k>=100 && $row->k<=150)
		{  echo "Low"; } else if(($row->k>=151 && $row->k<=170))
		{ echo "Adequate";}
		else if(($row->k>=171 && $row->k<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Mg</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mg; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mg>=100 && $row->mg<=150)
		{  echo "Low"; }
		 else if(($row->mg>=151 && $row->mg<=170))
		{ echo "Adequate";}
		else if(($row->mg>=171 && $row->mg<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">S</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->s; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->s>=1 && $row->s<=4)
		{  echo "Low"; }
		 else if(($row->s>=5 && $row->s<=7))
		{ echo "Adequate";}
		else if(($row->s>=8 && $row->s<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Mn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mn>=1 && $row->mn<=4)
		{  echo "Low"; }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ echo "Adequate";}
		else if(($row->mn>=8 && $row->mn<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Zn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->zn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->zn>=0.01 && $row->zn<=0.04)
		{  echo "Low"; }
		 else if(($row->zn>=0.05 && $row->zn<=0.07))
		{ echo "Adequate";}
		else if(($row->zn>=0.08 && $row->zn<=0.10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
                <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Ca</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $ca; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($ca>=1 && $ca<=800)
		{  echo "Low"; }
		 else if(($ca>=900 && $ca<=1100))
		{ echo "Adequate";}
		else if(($ca>=1200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">P</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $p; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($p>=1 && $p<=10)
		{  echo "Low"; }
		 else if(($p>=11 && $p<=12))
		{ echo "Adequate";}
		else if(($p>=13))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Fe</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $fe; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($fe>=0.01 && $fe<=0.09)
		{  echo "Low"; }
		 else if(($fe>=0.10 && $fe<=0.12))
		{ echo "Adequate";}
		else if(($fe>=0.13))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">PH</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $ph; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($ph>=1 && $ph<=6)
		{  echo "Low"; }
		 else if(($ph==7))
		{ echo "Adequate";}
		else if(($ph>=8 ))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        </table>
            <div align="center"><h2 style="font-style:italic;">The System Recomends Following </h2></div>
        <?php if($row->n>=100 && $row->n<=499)
		{ 
		?>
		 <div align="center">
         <strong>Nitrogen in Low Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/urea.jpg" width="270"  />
         </div>
         <?php } 
		 else if(($row->n>=500 && $row->n<=799))
		{ 
		?>
		<div align="center">
        <strong>Nitrogen in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/urea.jpg" width="270"  /></div>
        
        <?php }

		///////////////////////////ca///////////////////////
		if($ca>=1 && $ca<=800)
		{ 
		?>
		 <div align="center">
         <strong>CA in Low Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>2.5 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div> 
         <?php
         }
		 else if(($ca>=900 && $ca<=1100))
		{ ?>
        <div align="center">
        <strong>CA in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div> 
        <?php
        }
		
		//////////////////////////P/////////////////////////
		if($p>=1 && $p<=10)
		{ ?>
        <div align="center">
        <strong>P in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Cheeta-MAP.jpg" width="270"  /></div> 
        <?php }
		 else if(($p>=11 && $p<=12))
		{ ?>
        <div align="center">
        <strong>P in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Cheeta-MAP.jpg" width="270"  /></div>
        <?php }
		
		//////////////////////////fe////////////////////////
		if($fe>=0.01 && $fe<=0.09)
		{ ?>
        <div align="center">
        <strong>Fe in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/dap.jpg" width="270"  /></div>
        <?php }
		 else if(($fe>=0.10 && $fe<=0.12))
		{ ?>
        <div align="center">
        <strong>Fe in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1.5 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/dap.jpg" width="270"  /></div>
        <?php }
		
		////////////////////////////k///////////////////////
	 if($row->k>=100 && $row->k<=150)
		{
			?>
			<div align="center">
            <strong>K in Low Quantity</strong>
         <br />
            <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div>
             <?php 
               } else if(($row->k>=151 && $row->k<=170))
		{ 
		?>
		<div align="center">
        <strong>K in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/amonium.jpg" width="270"  /></div>
        <?php
        }
		
		///////////////////////////////mg////////////////////////////////////////
		if($row->mg>=100 && $row->mg<=150)
		{  ?> 
		<div align="center">
        <strong>MG in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Biostar.jpg" width="270"  /></div>
		<?php }
		 else if(($row->mg>=151 && $row->mg<=170))
		{ ?>
         <div align="center">
         <strong>MG in Adequate Quantity</strong>
         <br />
         <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/Biostar.jpg" width="270"  /></div> 
		 <?php }
	
		///////////////////////////////////////s/////////////////////////////////
		if($row->s>=1 && $row->s<=4)
		{ 
		?><div align="center">
        <strong>S in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>2.5 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php
		 }
		 else if(($row->s>=5 && $row->s<=7))
		{ ?> <div align="center">
        <strong>S in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zorawar.jpg" width="270"  /></div> 
        <?php
		}
		/////////////////////////////////mn/////////////////////////////////
		if($row->mn>=1 && $row->mn<=4)
		{  ?>
        <div align="center">
        <strong>Mn in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/AgroPower.jpg" width="270"  /></div>
        <?php }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ ?>
        <div align="center">
        <strong>Mn in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1.5 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/AgroPower.jpg" width="270"  /></div>
        <?php }
		////////////////////////////////////zn/////////////////////////////////
		if($row->zn>=0.01 && $row->zn<=0.04)
		{ ?>
        <div align="center">
        <strong>Zn in Low Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>3 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zingro.jpg" width="270"  /></div>
        <?php
         }
		 else if(($row->zn>=0.05 && $row->zn<=0.07))
		{ ?>
        
        <div align="center">
        <strong>Zn in Adequate Quantity</strong>
         <br />
        <b>Dosage/Acre:</b>1 Bags</p>
<br />
<img src="http://Localhost/agriculture/upload/zingro.jpg" width="270"  /></div>
        <?php }
		 ?>
        
        <?php } ?>
       <!-- <div style="margin-top:15px;"><label style="font-size: 18px;">Description:</label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <?php if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
     
     
        <?php } 
		else if($row->n>=100 && $row->n<=499 && $row->k>=150 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php } 
		else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php } 
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   The elements in the soil is in Low quantity.it produces the crop on Low level .</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
	  <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">    This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in Good quantity.The Production level of soil is Good.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>

        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
     
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in Good quantity.The Production level of soil is Good.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in Good quantity.The Production level of soil is Good.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in Good quantity.The Production level of soil is on its Good level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in Good quantity.The Production level of soil is on its Good level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in Good quantity.The Production level of soil is on its Good level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=149 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in Good quantity.The Production level of soil is on its Good level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
	 &nbsp;
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
		 &nbsp;
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good level.</p>
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Peak  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Excessive quantity.The Production level of soil is Peak  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Excessive quantity.The Production level of soil is Peak  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=149 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=150 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 
        
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
     &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP:1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=150 && $row->k<=170 && $row->mg>=150 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=150 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>&nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.01){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
        
        <?php }
			else if($row->n>=500 && $row->n<=699 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
        &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=150 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=150 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=149 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=149 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
     <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=151 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
        
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
        <?php }
		  else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
         <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>

	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 
	&nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in peak quantity.The Production level of soil is peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in peak quantity.The Production level of soil is peak  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 
	&nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 
	&nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 1.50 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 2 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 3 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 5 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>
	<p> Sarsabz Nitrophos (NP) 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=23"> <img src="http://localhost/agriculture/upload/nitro.jpg" style="width:   200px; height:200; " /></a>
	 
	 
        <?php }
		 else { ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px;  font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 &nbsp;
		 <h2 style="color:#0CF"> The System Recomends The Following Fertilizer. </h2>
	 &nbsp;
     <p>DAP: 2 bags/Acre</p>
    <a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=26"> <img src="http://Localhost/agriculture/upload/dap.jpg" style="width:200px; height:200px; " /></a>
	 <p>Urea: 3 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=25"> <img src="http://Localhost/agriculture/upload/urea.jpg" style="width:200px; height:200px; " /></a>
	  <p>Zingro: 4 bages/Acre</p>
	<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=27"> <img src="http://Localhost/agriculture/upload/zingro.jpg" style="width:200px; height:200px; " /></a>

	 
	 
        <?php }
		  ?>
        </div>-->
        <?php endforeach; ?>
        </div>
         <div align="center"><img 
src="http://Localhost/agriculture/images/pdf.jpg" style="width:193px; height:30px;" onClick=" return downloads();" /></div>
   <!-- </div>
    
    </div>
    <div><INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);"></div>
</div>
</div>
</article></div>-->
         
            <?php //include('footer.php'); ?>
			<script type="text/javascript">
function downloads()
{
							var DocumentContainer = document.getElementById('soil');
		                var WindowObject = window.open('', "PrintWindow",              "width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
	              	 WindowObject.document.writeln(DocumentContainer.innerHTML);
		             WindowObject.document.close();
		             WindowObject.focus();
		             WindowObject.print();
		             WindowObject.close();
	}
	
	</script>