

                
                        <div class="art-layout-cell art-sidebar1 clearfix" style="width:21%; float:left"><div class="art-vmenublock clearfix">
        <!--<div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="<?php echo base_url()?>index.php/home/home_v" <?php if($url=='http://localhost/agriculture/index.php/home/home_v'){ ?> class="active" <?php } ?> >Home</a></li><li><a href="<?php echo base_url() ?>index.php/product"<?php if($url=='http://localhost/agriculture/index.php/product'){ ?> class="active" <?php } ?>>Products</a></li><li><a href="<?php echo base_url() ?>index.php/recomender" <?php if($url=='http://localhost/agriculture/index.php/recomender'){ ?>class="active"<?php } ?>>Recomender</a></li><li><a href="<?php echo base_url() ?>index.php/s_recomender" <?php if($url=='http://localhost/agriculture/index.php/s_recomender'){ ?>class="active"<?php } ?>>Soil Recomender</a></li><li><a href="<?php echo base_url(); ?>index.php/about_us" <?php if($url=='http://localhost/agriculture/index.php/about_us'){ ?>class="active"<?php } ?>>About Us</a></li><li><a href="<?php echo base_url(); ?>index.php/about_us/contact" <?php if($url=='http://localhost/agriculture/index.php/about_us/contact'){ ?>class="active"<?php } ?>>Contacts</a></li></ul>
                
        </div>-->
<div class="header"><h3>User Area</h3></div>


        <div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="<?php echo base_url()?>index.php/customer" <?php if($url=='http://localhost/agriculture/index.php/customer' || $url=='http://localhost/agriculture/index.php/customer/login'){ ?>class="active"<?php } ?>>Customer Section</a></li>
<li><a href="<?php echo base_url(); ?>index.php/employee" <?php if($url=='http://localhost/agriculture/index.php/employee' || $url=='http://localhost/agriculture/index.php/employee/login'){ ?>class="active"<?php } ?>>Employee Section</a></li>
<li><a href="<?php echo base_url(); ?>index.php/dealer" <?php if($url=='http://localhost/agriculture/index.php/dealer' || $url=='http://localhost/agriculture/index.php/dealer/login'){ ?>class="active"<?php } ?>>Dealer Section</a></li>
</ul>
                
 </div>       
</div> 

<div style="width:96%; float:left; margin-left:4px;"><h3 align="center">Weather Update</h3><a href="<?php echo base_url()?>index.php/home/weather"><img src="http://localhost/agriculture/images/weather-widget.jpg" style="width:100%; opacity:0.9" /></a></div>
</div>

