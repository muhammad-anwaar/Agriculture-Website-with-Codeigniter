<?php //include('header.php'); ?>
<?php //include('left_section.php'); ?>
<!--<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Pestiside Recomender</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">-->
    
    <div id="dw" class="art-layout-cell layout-item-0" style=" position:absolute; margin-left:-72px;">
    <div align="right" style=" font-size:20px; font-style:italic; position:absolute; margin-top:-40px;">Rehan Agro Chemicals(pvt)Limited</div>
    <h2 style="font-size:18px; font-family:Georgia, 'Times New Roman', Times, serif;">Disease Image</h2>
    <div>

<?php

 foreach($result as $s):
 
 foreach($s as $re):

  ?>
  <p style="font-size: 18px;
font-family: Georgia,"Times New Roman",Times,serif;
 "><?php echo $re->disease; ?></p>
<p>

<img src="<?php echo base_url()."upload/".$re->disease_img; ?>" style="width:300px; height:100px;" />
</p>
<?php endforeach; ?>
<?php endforeach; ?>

   <div>
   
   </div>   
    </div>
<p></p>
<h1 style="font-size: 18px;
font-family: Georgia,"Times New Roman",Times,serif;
color: #0C3;">System Recomends u Folowing Chemical</h1>
 <p></p>       
<div>
<?php if(!empty($res) || !empty($res_1) || !empty($img_2) || !empty($img_3) || !empty($img_4)){ ?>
<table align="center" cellpadding="2" cellspacing="2" border="0" width="700px;" >
<?php if(!empty($res)){ ?>
 <tr><td><img src="<?php echo base_url()."upload/".$res; ?>" style="width: 200px;" /> </td>
<td> </td>
</tr>  
<tr><td style="font-size:14px; font-family:Georgia, 'Times New Roman', Times, serif; margin-left:208px; ">Product Name:</td>
<td style=" font-family:'Times New Roman', Times, serif; font-size:16px; margin-left:208px;"><?php echo $res_2; ?> </td>
</tr>
<tr><td style="font-size:14px; font-family:Georgia, 'Times New Roman', Times, serif; margin-left:208px;">Formulation:</td>
<td style=" font-family:'Times New Roman', Times, serif; font-size:16px; margin-left:208px;"><?php echo $res_3; ?> </td>
</tr>
<tr><td style="font-size:14px; font-family:Georgia, 'Times New Roman', Times, serif; margin-left:208px;">Dosage/Acre:</td>
<td style=" font-family:'Times New Roman', Times, serif; font-size:16px; margin-left:208px;"><?php echo $res_4; ?> </td>
</tr>
<?php } else if(!empty($res_1)){  ?>
<tr><td><img src="<?php echo base_url()."upload/".$res_1; ?>" style="width: 200px;" /></td>
<td>  </td>
</tr>
<?php } else if(!empty($img_2)){  ?>
<tr><td><img src="<?php echo base_url()."upload/".$img_2; ?>" style="width: 200px;" /> </td>
<td> </td>
</tr>
<?php } else if(!empty($img_3)){  ?>
<tr><td><img src="<?php echo base_url()."upload/".$img_3; ?>" style="width: 200px;" /></td>
<td>  </td>
</tr>
<?php } else if(!empty($img_4)){  ?>
<tr><td><img src="<?php echo base_url()."upload/".$img_4; ?>" style="width: 200px;" /></td>
<td>  </td>
</tr>
<?php }  ?> 
<tr><td></td>
<td> </td>
</tr>

  
   <!--<tr><td colspan="2"><?php if($w_condition=='cloudy')
{
	echo "<h3>The Weather Condition is Cloudy. In cloudy condition, it is not feasible to spray. The most suitable time for spraying is 7am-10am in normal weather condition. Spraying will not be effective in cloudy condition because of more chances of rain.</h3>";
	
	}
	else if($w_condition=='rainy')
{
	echo "<h3>The Weather Condition is Rainy. In rainy condition, it is not feasible to spray. The most suitable time for spraying is 7am-10am in normal weather condition. Spraying will not be effective in rainy condition.</h3>";
	
	}
	else if($w_condition=='hot')
{
	echo "<h3>The Weather is Hot. In hot condition, it is feasible to spray. The most suitable time for spraying is 7am-10am. Spraying will be effective in hot weather condition.</h3>";
	
	}
	else if($w_condition=='normal')
{
	echo "<h3>The Weather is Normal. It is the most suitable weather condition for spraying. The most preferable time for spraying in this condition is 7am-10am. Spraying will the most effective in this condition.</h3>";
	
	}
	?>
	</td></tr>-->
</table>


   
   
   </td>

<tr></tr>
<tr>
<td>   <?php
   
}
   else
   {
	   
	    echo '<span style="font-family:Georgia, Times New Roman, Times, serif;font-size:16px;">  Sorry there is no product relates to these disease .try with different one.</span>'; 
	   }
   
   
    ?></td>
</tr>
</tr>
<tr></tr>
<tr><td></td></tr>
</table>
</div>
<!--<a href="<?php echo base_url(); ?>index.php/recomender/rec"><input type="button" value="Back" style="width:100px; height:35px; border-radius:6px; border-style: groove;" /></a>-->
    </div>
    <div align="center"><img 
src="http://Localhost/agriculture/images/pdf.jpg" style="width: 193px;
    height: 30px; position:absolute; margin-top:450px;

}" onClick=" return downloads();" /></div>
<!--</div>
</div>
</article></div>
                    </div>
                
            </div> -->              
           
            <?php //include('footer.php'); ?>
					<script type="text/javascript">
function downloads()
{
							var DocumentContainer = document.getElementById('dw');
		                var WindowObject = window.open('', "PrintWindow",              "width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
	              	 WindowObject.document.writeln(DocumentContainer.innerHTML);
		             WindowObject.document.close();
		             WindowObject.focus();
		             WindowObject.print();
		             WindowObject.close();
	}
	
	</script>