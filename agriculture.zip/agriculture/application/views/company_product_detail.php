<?php include('header.php'); ?>
<?php include('left_section.php'); ?>
<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon"> Products Detail</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">



<table align="center" cellpadding="2" cellspacing="2" style="margin:10px 5px 2px 10px; background:#CCC;">
<tr></tr>
<?php foreach($row as $r): ?>
<tr><td></td><td><img src="<?php echo base_url()."upload/".$r->product_imag; ?>" width="400" /> </td></tr>

<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label`>Product Name:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><a><?php echo $r->product_name; ?></a></td></tr>
<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label>Common Name:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $r->common_name; ?></td></tr>
<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label>Formulation:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $r->formulation; ?></td></tr>
<?php if(!empty($r->crop)){ ?>
<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label>Crop:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $r->crop; ?></td></tr>
<?php } else { ?>
<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label>Properties:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $r->properties; ?></td></tr>
<?php } ?>
<?php if(!empty($r->pests)){ ?>
<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label>Pests:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $r->pests; ?></td></tr>
<?php } else { ?>
<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label>Description:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $r->description; ?></td></tr>
<?php } ?>
<?php if(!empty($r->dosage)){ ?>
<tr><td style="font-family:'Times New Roman', Times, serif; font-size:14px;"><label>Dosage/Acre:</label></td>&nbsp;&nbsp;
<td style=" font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $r->dosage; ?></td></tr>
<?php } ?>
<?php endforeach ?>

<tr></tr>
</table>
<div><INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);"></div>
</div>


</div>
</article>
</div>

<?php include('footer.php'); ?>