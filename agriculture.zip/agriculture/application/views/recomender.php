<?php include('header.php'); ?>
<?php include('left_section.php'); ?>
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Pestiside Recommender</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
<p></p>
<h2>How to Use Pestiside Recommender</h2>
 <p></p>       
 <strong><p style="font-family:Georgia, 'Times New Roman', Times, serif;">
 <ol start="1">
 <li>Select The Start</li>
 <li>Select the Province</li>
 <li>Select the Region</li>
 <li>Select Crop Name</li>
 <li>Select Crop Variety</li>
 <li>Select the disease or pests</li>
  <li>You can select two or three pests or disease of same crop at one time.</li>
 <li>Select Disease Condition</li>
 <li>Select the Soil Type</li>
 <li>Select the Humadity Level</li>
 <li>Select the Temprature</li>
 <li>System recommends the Pesticides for the diseases or pests.</li>
 <li>System recommends the dosage of this checmical,formulation.</li>
 </ol>
 </p></strong>
   
 <div style=" margin:50px 0px 0px -80px;">
   <center><a href="<?php echo base_url(); ?>index.php/recomender/rec"><img src="<?php echo base_url(); ?>images/start.png" /></a></center> 
   </div>    
    </div>
    </div>
</div>
</div>
</article></div>
           
            <?php include('footer.php'); ?>