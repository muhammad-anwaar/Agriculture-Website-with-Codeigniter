<?php include('header.php'); ?>
<?php include('left_emp.php'); ?>
<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon"> Daily Report</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">



<?php // echo form_open('dealer/add_product'); ?>
<form name="gform" id="gform" action="<?php echo base_url(); ?>index.php/employee/add_report" method="post" >
<?php  $emp_id=$this->session->userdata('emp_id'); ?>
<table background="http://Localhost/agriculture/images/bg-body.png" style="margin:5px -130px;;" cellpadding="2" cellspacing="2" align="center">
<tr></tr>
<tr><td colspan="2"><center><h2 style="color:#0CF;">Daily Report</h2></center></td></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr><?php
if(!empty($msg))
{	?><td colspan="2" align="center">

<?php echo $msg; ?>	
	
</td><?php } ?></tr>
<tr></tr>

<tr><td align="right"><label style="font-family:Arial, Helvetica, sans-serif; font-size:20px;">Report Title:<span style="color:red;">*</span></label></td>
<td><input name="report_title" id="report_title" value="" style="border-radius:4px;" required autofocus />

</td></tr>
<tr><td align="right"><label style="font-family:Arial, Helvetica, sans-serif; font-size:20px;">Farmer Name:<span style="color:red;">*</span></label></td>
<td><input name="farmer_name" id="farmer_name" value="" style="border-radius:4px;" required autofocus />

</td></tr>
<tr></tr>
<tr><td align="right"><label style="font-family:Arial, Helvetica, sans-serif; font-size:20px;">Dealer Reference Name:<span style="color:red;">*</span></label></td><td><!--<input name="dealer_rf_name" id=" dealer_rf_name" value="" style="border-radius:4px;" required autofocus />-->
<select name="dealer_rf_name" id=" dealer_rf_name" required autofocus style="width:203px; border-radius:4px;">
<option>Select Dealer</option>
<?php foreach($result as $row): ?>
<option value="<?php echo $row->dealer_name; ?>"><?php echo $row->dealer_name; ?></option>
<?php endforeach; ?>
</select>
</td></tr>
<tr></tr>
<tr><td align="right"><label style="font-family:Arial, Helvetica, sans-serif; font-size:20px;">Date:<span style="color:red;">*</span></label></td><td><input name="c_date" id="date" value="" style="border-radius:4px;" required autofocus /></td></tr>
<tr></tr>
<tr><td align="right"><label style="font-family:Arial, Helvetica, sans-serif; font-size:20px;">Visited Area:<span style="color:red;">*</span></label></td><td><input name="v_address" id="address" value="" style="border-radius:4px;" required autofocus /></td></tr>
<tr></tr>
<tr><td align="right"><label style="font-family:Arial, Helvetica, sans-serif; font-size:16px;" >City:<span style="color:red;">*</span></label></td><td> <select required autofocus title="Select City" name="v_city" id="City" style="width:203px; border-radius:4px;" >

        <option value="">Select City</option>
        <option value="Islamabad">Islamabad</option>
        <option value="Rawalpindi">Rawalpindi</option>
        <option value="Lahore">Lahore</option>
        <option value="Faisalabad">Faisalabad</option>
        <option value="Narowal">Narowal</option>
        <option value="Bahawalpur">Bahawalpur</option>
        <option value="Multan">Multan</option>
        <option value="Gujranwala">Gujranwala</option>
        <option value="Sargodha">Sargodha</option>
        <option value="Sialkot">Sialkot</option>
        <option value="Seiikhupura">Seiikhupura</option>
        <option value="D.G Khan">D.G Khan</option>
        <option value="Karachi">Karachi</option>
        <option value="Hyderabad">Hyderabad</option>
        <option value="Sukkar">Sukkar</option>
        <option value="Larkana">Larkana</option>
        <option value="Nawabshah">Nawabshah</option>
        <option value="Mirpur Khas">Mirpur Khas</option>
        <option value="Jacobabad">Jacobabad</option>
        <option value="Shikarpur">Shikarpur</option>
        <option value="Dadu">Dadu</option>
        <option value="Peshawar">Peshawar</option>
        <option value="Mardan">Mardan</option>
        <option value="Mengora">Mengora</option>
        <option value="Kohat">Kohat</option>
        <option value="Abottabad">Abottabad</option>
        <option value="Swabi">Swabi</option>
        <option value="D.I Khan">D.I Khan</option>
        <option value="Charsadda">Charsadda</option>
        <option value="Nowshera">Nowshera</option>
        <option value="Mansehra">Mansehra</option>
        <option value="Quetta">Quetta</option>
        <option value="Khuzdar">Khuzdar</option>
        <option value="Turbat">Turbat</option>
        <option value="Sibi">Sibi</option>
        <option value="Lasbela">Lasbela</option>
        <option value="Zhob">Zhob</option>
        <option value="Nasirabad">Nasirabad</option>
        <option value="Jaffarabad">Jaffarabad</option>
        <option value="Gwadar">Gwadar</option>
      </select></td></tr>
      <tr></tr>
      <tr></tr><tr></tr><tr></tr>

              
      <tr></tr><tr></tr><tr></tr>

        <tr>
        <td align="right"><label style="font-family:Arial, Helvetica, sans-serif; font-size:16px;">Description<span style="color:red;">*</span></label></td>
        <td>
        <textarea name="description" id="description" cols="40" rows="5"></textarea>
        <input type="hidden" name="emp_id" id="emp_id" value="<?php echo $emp_id; ?>" />
        </td>
        </tr>
     
      <tr></tr><tr></tr><tr></tr>
      <tr><td colspan="2" align="center"> <input type="submit" name="submit" value="Submit" style=" background:#0F3;border-radius:24px; border-color:#0F9;" /></td></tr>
</table>
</form>
<table cellpadding="2" cellspacing="2">
<tr></tr>
<tr><td><div><a href="<?php echo base_url(); ?>index.php/employee/mng"><INPUT TYPE="button" VALUE="Back"  style="margin-left:40px;"></a></div></td>
</tr>
</table>
</div>

</div>
</article>
</div>

<?php include('footer.php'); ?>