<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.0.0.58475 -->
    <meta charset="utf-8">
    <title>Home</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
         <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/css/style.css" media="screen" />
        
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.responsive.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style1.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/default.css" />
<link rel="stylesheet" href="<?php echo base_url();?>css/flexslider.css" type="text/css" media="screen" />

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>javascript/jquery.js"></script>
    <script src="<?php echo base_url(); ?>javascript/script.js"></script>
    <script src="<?php echo base_url(); ?>javascript/jquery.flexslider.js"></script>
    <script src="<?php echo base_url(); ?>javascript/script.responsive.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>javascript/zebra_datepicker.js"></script>
    <script >
    $(document).ready(function() {

    // assuming the controls you want to attach the plugin to 
    // have the "datepicker" class set
    $('#date').Zebra_DatePicker();

 });
    $(document).ready(function() {

    // assuming the controls you want to attach the plugin to 
    // have the "datepicker" class set
    $('#date1').Zebra_DatePicker();

 });
    </script>
    
    <script type="text/javascript">
    $(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
      $('.flexslider').flexslider({
        animation: "slide",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });
  </script>

    
<style>.art-content .art-postcontent-0 .layout-item-0 { margin-top: 10px;margin-bottom: 10px;  }
.art-content .art-postcontent-0 .layout-item-1 { border-spacing: 10px 0px; border-collapse: separate;  }
.art-content .art-postcontent-0 .layout-item-2 { padding: 0px;  }
.art-content .art-postcontent-0 .layout-item-3 { margin-bottom: 10px;  }
.art-content .art-postcontent-0 .layout-item-4 { color: #737373; background: #2F89B6; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-5 { color: #737373; background: #A04661; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-6 { color: #737373; background: #5B9121; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-7 { color: #737373; background: #EB9500; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-8 { padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-9 { color: #273E0E; background: ; padding-right: 10px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-10 { margin-top: 0px;margin-right: 10px;margin-bottom: 0px;margin-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-11 {  border-collapse: separate;  }
.ie7 .post .layout-cell {border:none !important; padding:0 !important; }
.ie6 .post .layout-cell {border:none !important; padding:0 !important; }

</style></head>
<body>

<div id="header">
<div class="container">
<img src="http://localhost/agriculture/images/logo.png" id="logo">
<nav class="art-nav clearfix">
<?php  $url=current_url(); ?>
    <ul class="art-hmenu"><li><a href="<?php echo base_url()?>index.php/home/home_v" <?php if($url=='http://localhost/agriculture/index.php/home/home_v' || $url=='http://localhost/agriculture/index.php/' || $url=='http://localhost/agriculture/'){ ?> class="active" <?php } ?> >Home</a></li>
   <li><a href="<?php echo base_url() ?>index.php/product"<?php if($url=='http://localhost/agriculture/index.php/product' || $url=='http://localhost/agriculture/index.php/product/fertilizer' || $url=='http://localhost/agriculture/index.php/product/show_detail' || $url=='http://localhost/agriculture/index.php/product/index1' || $url=='http://localhost/agriculture/index.php/product/show_detail'){ ?> class="active" <?php } ?>>Products</a></li>
   <li><a href="<?php echo base_url() ?>index.php/recomender" <?php if($url=='http://localhost/agriculture/index.php/recomender' || $url=='http://localhost/agriculture/index.php/recomender/rec' || $url=='http://localhost/agriculture/index.php/recomender/record' || $url=='http://localhost/agriculture/index.php/recomender/get_des'){ ?>class="active"<?php } ?>>Pestiside Recommender</a></li>
   <li><a href="<?php echo base_url() ?>index.php/s_recomender" <?php if($url=='http://localhost/agriculture/index.php/s_recomender' || $url=='http://localhost/agriculture/index.php/s_recomender/index1' || $url=='http://localhost/agriculture/index.php/s_recomender/recomends'){ ?>class="active"<?php } ?>>Fertilizer Recommender</a></li>
   <li><a href="<?php echo base_url(); ?>index.php/about_us" <?php if($url=='http://localhost/agriculture/index.php/about_us'){ ?>class="active"<?php } ?>>About Us</a></li>
   <li><a href="<?php echo base_url(); ?>index.php/about_us/contact" <?php if($url=='http://localhost/agriculture/index.php/about_us/contact'){ ?>class="active"<?php } ?>>Contacts Us</a></li></ul> 
    </nav>
</div>
</div>

<div id="art-main">
    <div class="art-sheet clearfix">

    
<header class="art-header clearfix">

<div class="art-slider art-slidecontainerheader">
<!--<img src="http://Localhost/agriculture//images/slideheader1.jpg" width="1090" height="200">-->


<div class="flexslider">
          <ul class="slides">
            <li>
  	    	    <img src="http://localhost/agriculture/images/slide_01.jpg" />
  	    		</li>
  	    		<li>
  	    	    <img src="http://localhost/agriculture/images/slide_02.jpg" />
  	    		</li>
  	    		<li>
  	    	    <img src="http://localhost/agriculture/images/slide_03.jpg" />
  	    		</li>
  	    		<li>
  	    	    <img src="http://localhost/agriculture/images/slide_04.jpg" />
  	    		</li>
          </ul>
        </div>

    </div>     
                    
</header>
