 <?php include('header.php'); ?>
 <?php include('left_section.php'); ?>
  <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">About Us</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <p><strong>Our company was originated in 2012. Since then, it is providing its services.
Our company is one of the emerging company in agriculture field in Pakistan. We deal with its customers in a pleasant way and we offer our services free of cost. The products quality is also good as we provide verified products. Farmer’s satisfaction is one of the major concern of our company and we always go forward towards its achievement. We are always willing to provide best services because quality of products and customer’s satisfaction is our main concern. 
</p>
        
        <p>The other prominent services we provide are Online Fertilizer and Pesticide Recommendation. It is a completely new idea and no one has ever worked on it yet. We, on the other hand, have worked over it and we have created a system which can help the farmer’s in getting free of cost recommendation of fertilizer and pesticide. They don’t need to go through an extensive process which wastes a lot of their time. This system will recommend them in no time. And the main thing which needs to be taken into consideration is that it also provides information along with recommended product.  In fact this system is an evolution in the market.</p>
        
        <p>Our company also provides online ordering to its customers as well as dealers. They can order their products online which is also a handy thing.</p>
        
        <p>Employees of the company are also involved in the system as they have to upload their daily field reports for company records.
In fact our company is a single portal providing multiple facilities to its users.
</p></strong>

    </div>
    </div>
</div>
</div>
</article></div>
                   
         
            <?php include('footer.php'); ?>