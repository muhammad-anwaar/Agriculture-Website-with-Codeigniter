<?php include('header.php'); ?>
 <?php include('left_section.php'); ?>  

                        <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                           
                              
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 25%" >
        <img width="208" height="208" alt="" src="http://localhost/agriculture/images/cotton-Austrailia.jpg">
    </div><div class="art-layout-cell layout-item-2" style="width: 25%" >
       <img width="208" height="208" alt="" src="http://localhost/agriculture/images/gm-wheat1.jpg" class="">
    </div><div class="art-layout-cell layout-item-2" style="width: 25%" >
    <img width="208" height="208" alt="" src="http://localhost/agriculture/images/golden-rice.jpg" class="">
    </div>
    </div>
</div>
</div>
<div class="art-content-layout-wrapper layout-item-3">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-4" style="width: 25%" >
           <h4>Cotton</h4>
    </div><div class="art-layout-cell layout-item-5" style="width: 25%" >
        <h4>Rice</h4>
    </div><div class="art-layout-cell layout-item-6" style="width: 25%" >
        <h4>Wheat</h4>
    </div>
    </div>
</div>
</div>
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-8" style="width: 25%" >
        <p style="text-align: justify; min-height:70px"> <strong> Cotton is a soft, fluffy staple fiber that grows in a boll, or protective capsule, around the seeds of cotton plants of the genus Gossypium in the family of Malvaceae. The fiber is almost pure cellulose. Under natural conditions, the cotton bolls will tend to increase the dispersion of the seeds.</p> </strong>
        <p><a href="<?php echo base_url(); ?>index.php/home/cotton" class="art-button">Read more</a></p>
    </div><div class="art-layout-cell layout-item-8" style="width: 25%" >
        <p style=" min-height:70px; min-height:70px"> <strong> Rice is the seed of the monocot plants Oryza sativa (Asian rice) or Oryza glaberrima (African rice). As a cereal grain, it is the most widely consumed staple food for a large part of the world's human population, especially in Asia. It is the grain with the third-highest worldwide production, of FAOSTAT 2012.</p></strong>
        <p><a href="<?php echo base_url(); ?>index.php/home/rice" class="art-button" >Read more</a></p>
    </div><div class="art-layout-cell layout-item-8" style="width: 25%" > <strong>
        <p>Wheat is a cereal grain, originally from the Levant region of the Near East but now cultivated worldwide. In 2010, world production of wheat was 651 million tons, making it the third most-produced cereal after maize (844 million tons) and rice (672 million tons). Wheat was the second most-produced cereal in 2009.</p> </strong>
        <p><a href="<?php echo base_url(); ?>index.php/home/wheat" class="art-button">Read more</a></p>

    </div>
</div>
    <div style="float:left; width:303%; font-size:12px; margin-top:15px; border-top:1px dotted #ccc; padding-bottom:40px" >
    <p><span style="text-align: justify;"></span></p><strong>
        <h1>Agricuture</h1>
        
                <p>Agriculture is the backbone of Pakistan's economy. Keeping in view the ever increasing demand for quality agricultural inputs, the company was established in 1993. Initially, the core business of the company was manufacturing and marketing of agrochemicals.
        The objective of the group evolves from the collective determination of our people to excel in providing continuous customer satisfaction through our quality products at the right price With more than 12 years of experience in pesticides industry and over 20 years of experience in fertilizers industry we have established a strong customer base in Punjab.</p>
 
<p> Agriculture being major the industry in Pakistan, the potential for growth in the industry are exceptional. Our customers and suppliers are major contributor toward our success. Therefore we do value our customers and believe in establishing a strong relationship with suppliers in order to exploit the opportunities this market presents.
 
We are ready to grow and strengthen our relationship with our customers and our suppliers through our excellence and commitment.
Today our customers and suppliers know us for our exceptional track record  and commitment to excellence. We are proud of this and take this as an opportunity to improve our products and services.<!--<a href="#" title="Read More">[...]</a>--></p><strong>
        

        
        
 
    </div>
</div>
</article>
</div>
                    
                    
                  
              
      <?php include('footer.php'); ?>          
      </div>