<?php include('header.php'); ?>
<?php include('left_section.php'); ?>




<center>  <h2>Enter Your Login and Password</h2></center>
  
  <form  id="admin_login"action="<?php echo base_url()?>index.php/recomender/login" method="post" style="margin: 20px 0px 0px 240px; width:300px;">

      <label>Login<span style="color:red">* </label>
      <?php if(!empty($error_msg)){?>
						<p><?php echo $error_msg?></p>
                        
						<?php }?>
      <div class="cleaner_h40"><p>
      <input type="text" name="username" size="30" required="required" autofocus="autofocus" title="Must Required"/>
      </p>
      <p>
      <label>Password<span style="color:red">*<br />
      <input type="password" name="password" size="30" required="required" autofocus="autofocus" title="Must Required" />
      </label>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
      <button type="submit" value="submit">Login</button></form>
      
      <a href="<?php echo base_url(); ?>index.php/recomender/create">Sign UP</a>
     </div>
  
 

  <div class="fepro">
  </div>
  </div>

<?php include('footer.php'); ?>