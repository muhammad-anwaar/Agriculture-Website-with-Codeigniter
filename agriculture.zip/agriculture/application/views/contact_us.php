<?php include('header.php'); ?>
<?php include('left_section.php'); ?>
                   
            <div class="art-layout-cell art-content clearfix">
            <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Contact Us</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
                                 <div class="art-content-layout-row">
                                                          
                

<p style="font-size:14px; padding:20px 0"><strong>Email Address for  Questions:</strong><br/>
agriculture@gmail.com<br/>
<br/>
<strong>Contact & Telephone Information:</strong><br/>
Phone:051-243566<br/>
Fax:1-440-526-6637
<br/>
<br/>
<strong>Mailing Address:</strong><br/>
i-8 Markz<br/>
 Islamabad,Pakistan     
 
 <h3
 style="font-size:24px; font-weight:normal">Feedback Form</h3>

<hr color="#660000" width="80%" style="float:left"/>
<br><br>


<p style="margin-top: 1em; margin-bottom: 1em; margin:20px 0px 0px 3px;"><strong>Please fill in the form below.This will enable us to contact you regarding your specific enquiry.</strong></p>
 
            <div class="wpcf7" id="wpcf7-f61-p12-o1" style="margin:0px 0px 0px -175px;"><form name="gform" action="<?php echo base_url() ?>index.php/about_us/f_back" method="post" enctype="multipart/form-data" class="wpcf7-form"><div class="form-row" style="margin-top: 20px; "><label for="your-name" style="font-weight: bold; margin-bottom: 10px; ">YOUR NAME (required)</label><br><input type="text" name="c_name" value="<?php echo set_value('c_name'); ?>" autofocus required size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input-text" id="your-name" aria-required="true" style="font-family: proxima-nova, 'Lucida Grande', Arial, Helvetica, sans-serif; font-size: 14px; vertical-align: baseline; line-height: 26px; color: rgb(130, 129, 140); padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; width: 450px; border-top-color: rgb(255, 255, 255); border-right-color: rgb(255, 255, 255); border-bottom-color: rgb(255, 255, 255); border-left-color: rgb(255, 255, 255); "></div><div class="form-row" style="margin-top: 20px; "><label for="your-email" style="font-weight: bold; margin-bottom: 10px; ">YOUR EMAIL (required)</label><br>
 
 <input type="email" name="c_email" required autofocus value="<?php echo set_value('c_email'); ?>" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email input-text" id="your-email" aria-required="true" style="font-family: proxima-nova, 'Lucida Grande', Arial, Helvetica, sans-serif; font-size: 14px; vertical-align: baseline; line-height: 26px; color: rgb(130, 129, 140); padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; width: 450px; border-top-color: rgb(255, 255, 255); border-right-color: rgb(255, 255, 255); border-bottom-color: rgb(255, 255, 255); border-left-color: rgb(255, 255, 255); ">
 </div>
 
 <div class="form-row" style="margin-top: 20px; "><label for="your-subject" style="font-weight: bold; margin-bottom: 10px; ">SUBJECT</label><br><input type="text" name="c_subject" value="<?php echo set_value('c_subject'); ?>" required autofocus size="40" class="wpcf7-form-control wpcf7-text input-text" id="your-subject" style="font-family: proxima-nova, 'Lucida Grande', Arial, Helvetica, sans-serif; font-size: 14px; vertical-align: baseline; line-height: 26px; color: rgb(130, 129, 140); padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; width: 450px; border-top-color: rgb(255, 255, 255); border-right-color: rgb(255, 255, 255); border-bottom-color: rgb(255, 255, 255); border-left-color: rgb(255, 255, 255); "></div>
 
 <div class="form-row" style="margin-top: 20px; "><label for="your-message" style="font-weight: bold; margin-bottom: 10px; ">YOUR MESSAGE</label><br><textarea name="c_message" required autofocus cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea input-textarea" id="your-message" style="font-family: proxima-nova, 'Lucida Grande', Arial, Helvetica, sans-serif; font-size: 14px; vertical-align: top; color: rgb(130, 129, 140); line-height: 26px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; width: 450px; border-top-color: rgb(255, 255, 255); border-right-color: rgb(255, 255, 255); border-bottom-color: rgb(255, 255, 255); border-left-color: rgb(255, 255, 255); height: 165px; "></textarea></div>
 
 <div class="form-row-submit" style="margin-top: 30px; "><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit btn-submit" style="font-family: proxima-nova, 'Lucida Grande', Arial, Helvetica, sans-serif; font-size: 14px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; vertical-align: baseline; line-height: 1; color: rgb(255, 255, 255); font-weight: 600; background-color: rgb(95, 176, 188); padding-top: 7px; padding-right: 10px; padding-bottom: 5px; padding-left: 10px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; text-transform: uppercase; letter-spacing: 0.07em; -webkit-appearance: button; -webkit-transition-duration: 0.2s; -webkit-transition-timing-function: ease-in-out; ">
                </div>
                
                
  </form></div></article>
                
                
                
                </article>
                
               
                </div>
                
                 <?php include('footer.php'); ?> 
               
           