<?php include('header.php'); ?>
<?php include('left_section.php'); ?>
<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Reset Password</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">



<center>  <h2>Enter Your Email</h2></center>
  
  <form style="margin: 20px 0px 0px 240px; width:300px;"  id="admin_login"action="<?php echo base_url()?>index.php/customer/current_pass" method="post">
<span style="margin-bottom:15px; background:#F00;">  <?php if(!empty($msg)){?>
						<p><?php echo $msg?></p>
                        
						<?php }?></span>
      <label>Email<span style="color:red">* </label>
    
      <div class="cleaner_h40"><p>
     
      <input type="text" name="email" size="30" required autofocus title="Must Required"/>
      
      </p>
    
      <button style="margin-top:10px;" type="submit" value="submit">Submit</button></form>
      
     </form>
     </div>
  
  <a style="margin-left:40px;" href="<?php echo base_url(); ?>index.php/customer/index"><button>Back</button></a>

  <div class="fepro">
  </div>
  </div>
  
  
  </div>
</article>
</div>

<?php include('footer.php'); ?>