<?php include('header.php'); ?>
<?php include('left_section.php'); ?>
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Pestiside Recommender</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div  style="width: 100%" >
	<table align="left" cellpadding="2" cellspacing="2">
	<tr><td><table align="center" cellpadding="2" cellspacing="2" border="0" width="500px;" style="margin-top: 0px;
margin-left: 42px;
position: relative;" >
<tr><td><label><strong style="font-size:14px;">Province</strong></label></td>
<td><select name="state" id="state" style="width:226px; border-radius:4px; height:36px;">
<option value="punjab">Punjab</option>
<option value="sindh">Sindh</option>
<option value="balochistan">Balochistan</option>
<option value="khyber">Khyberpakhtunkhawan</option>
</select>
</td>
</tr>

<tr><td><label><strong style="font-size:14px;">Region</strong></label></td>
<td>
<div id="shw_1"></div>
</td>
</tr>

<tr><td><label><strong style="font-size:14px;">Crop Name</strong></label></td>
<td><select name="crop" id="crop" style="width:226px; border-radius:4px; height:36px;">
<option>Select Crop</option>
<?php foreach($ro as $r): ?>
<option value="<?php echo $r->crop; ?>">
<?php echo $r->crop; ?>
</option>
<?php endforeach ?>
</select>
</td>
</tr>
<tr><td><label><strong style="font-size:14px;">Crop Varity</strong></label></td>
<td>
<div id="shw_2"></div>
</td>
</tr>
</table></td><td><div id="shw1"></div></td></tr>
	<tr><td>
   
   <form name="fform" id="fform" action="<?php echo base_url(); ?>index.php/recomender/get_des" method="post" style="margin-left: 38px;
position: relative;
margin-top: -8px;">
<table align="center" cellpadding="2" cellspacing="2" border="0" width="500" style="margin-left:-34px;" >

<tr><td><label><strong style="font-size:14px;">Disease Name</strong></label></td>
<td>
<div id="shw"></div>
   </td>
</tr>
<tr><td><label><strong style="font-size:14px;">Disease Condition</strong></label></td>
<td>
<select name="dis_condition" id="dis_condition" style="width:226px; border-radius:4px; height:36px;">
<option >Select Disease Condition</option>
<option value="0">Low</option>
<option value="1">High</option>
</select>
   </td>
</tr>
<tr><td><label><strong style="font-size:14px;">Soil Type</strong></label></td>
<td>
<select name="s_type" id="s_type" style="width:226px; border-radius:4px; height:36px;">
<option >Select Soil Type</option>
<option value="5">Mild</option>
<option value="10">Sand</option>
<option value="15">Good</option>
</select>
   </td>
</tr>
<tr><td><label><strong style="font-size:14px;">Humadity Level</strong></label></td>
<td>
<select name="level" id="level" style="width:226px; border-radius:4px; height:36px;">
<option >Select Humidity Level</option>
<option value="5">5%</option>
<option value="10">10%</option>
<option value="15">15%</option>
<option value="20">20%</option>
<option value="25">25%</option>
<option value="30%">30%</option>
</select>
   </td>
</tr>
<tr><td><label><strong style="font-size:14px;">Temprature</strong></label></td>
<td>
<select name="w_condition" id="w_condition" style="width:226px; border-radius:4px; height:36px;">
<option >Select Temprature</option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
<option value="32">32</option>
<option value="33">33</option>
<option value="34">34</option>
<option value="35">35</option>
<option value="36">36</option>
<option value="37">37</option>
<option value="38">38</option>
<option value="39">39</option>
<option value="40">40</option>
</select>
   </td>
</tr>
<tr>
<td></td><td><input type="button" id="res" name="subm" value="Recommendation"  style=" margin-top:25px;"/></td>
</tr>

</table>
</form>
   </td><td></td></tr>
	</table>
	
<!--<p>



</p>-->
    

    </div>
    </div>


</div>
</div>
</article></div>
           
            <?php include('footer.php'); ?>
 <script type="text/javascript">
        
		
            var state=$("#state").val();
			
			 $("#shw_1").load("get_city",{"state":state});
                
			$('#state').change(function() {
                var state=$(this).val();
				$("#shw_1").load("get_city",{"state":state});
            });
			
			$('#crop').change(function(){
                var crop = $('#crop').val();
				var city=$("#city").val();
				
			$("#shw_2").load("varity",{"crop":crop,"city":city});
				
            });
			
			
			

        </script>	
        <script type="text/javascript">
		$("#res").click(function(e) {
           var val=$("#dise").val();
		    var crop = $('#crop').val();
			var varity=$('#varity').val();
		  var w_condition=$("#w_condition").val();
		  var dis_condition=$("#dis_condition").val();
		  var city=$("#city").val();
		var type=$("#s_type").val();
		var level=$("#level").val();
		
		  if(crop=='Select Crop')
		  {
			  alert("Select Crop");
			  return false;
			  }
		   if (varity=='undefined' || varity==null || varity=='Select Varity' )
		   {
			   alert("Please Select Crop Varity");
			   return false;
			   }
			   if(val=='' || val==null)
			   {
				   alert("Select Disease");
				   
				   return false;
				   
				   }
				    if(dis_condition=='Select Disease Condition')
				   {
					   alert("Select Disease Condition");
					   return false;
					   }
					   
					   if(type=='Select Soil Type')
			              {
				   alert("Select Soil Type");
				   return false;
				   }
				   if(level=='Select Humadity Level')
			        {
				   alert("Select Humadity Level");
				   return false;
				   }
			   if(w_condition=='Select Temprature')
			   {
				   alert("Select Temprature");
				   return false;
				   }
				   
				  
		   $("#shw1").load("get_des",{"dise":val,"w_condition":w_condition,"dis_condition":dis_condition,"city":city,"type":type,"level":level});
		   
        });
		</script>		
      