<?php include('header.php'); ?>
<?php include('left_section.php'); ?>


 <div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Employee Login</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">


<center>  <h2>Enter Your Login and Password</h2></center>
  
  <form style="margin: 20px 0px 0px 240px; width:300px;"  id="admin_login"action="<?php echo base_url()?>index.php/employee/login" method="post">

      <label style="font-size:14px; font-family:Georgia, 'Times New Roman', Times, serif;">Login<span style="color:red">* </label>
      <?php if(!empty($error_msg)){?>
						<p><?php echo $error_msg?></p>
                        
						<?php }?>
      <div class="cleaner_h40"><p>
      <input type="text" name="username" size="30" required autofocus title="Must Required"/>
      </p>
      <p>
      <label style="font-size:14px; font-family:Georgia, 'Times New Roman', Times, serif;">Password<span style="color:red">*<br />
      <input type="password" name="pass" size="30" required autofocus title="Must Required" />
      </label>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
      <button style="margin-top: 11px;
    width: 90px;" type="submit" value="submit">Login</button>&nbsp;&nbsp;<a href="<?php echo base_url(); ?>index.php/customer/reset_password2">Forget Password</a></form>
      
      
     </div>
  
 

  <div class="fepro">
  </div>
  </div>

</div>
</article>
</div>
 <?php include('footer.php'); ?>