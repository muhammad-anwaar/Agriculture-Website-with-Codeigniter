 <?php include('header.php'); ?>
 <?php include('left_section.php'); ?>
  <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Wheat</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
        <p>Wheat is a worldwide cultivated grass from the Fertile Crescent region of the Near East. In 2007 world production of wheat was 607 million tons, making it the third most-produced cereal after maize (784 million tons) and rice (651 million tons). Wheat grain is a staple food used to make flour for leavened, flat and steamed breads, biscuits, cookies, cakes, breakfast cereal, pasta, noodles, or biofuel. Wheat is planted to a limited extent as a forage crop for livestock, and the straw can be used as fodder for livestock or as a construction material for roofing thatch. 

</p>
        
        <p>This grain is grown on more land area than any other commercial food. World trade in wheat is greater than for all other crops combined. Globally, wheat is the leading source of vegetable protein in human food, having a higher protein content than other major cereals, maize (corn) or rice. In terms of total production tonnages used for food, it is currently second to rice as the main human food crop and ahead of maize, after allowing for maize's more extensive use in animal feeds.
 
</p>
        
        <p>Wheat was a key factor enabling the emergence of city-based societies at the start of civilization because it was one of the first crops that could be easily cultivated on a large scale, and had the additional advantage of yielding a harvest that provides long-term storage of food. Wheat contributed to the emergence of city-states in the Fertile Crescent, including the Babylonian and Assyrian empires. Wheat grain is a staple food used to make flour for leavened, flat and steamed breads, biscuits, cookies, cakes, breakfast cereal, pasta, noodles, couscous and for fermentation to make beer, other alcoholic beverages,  or biofuel. 
</p>
<p>
There are six wheat classifications: 1) hard red winter, 2) hard red spring, 3) soft red winter, 4) durum (hard), 5) Hard white, 6) soft white wheat. The hard wheats have the most amount of gluten and are used for making bread, rolls and all-purpose flour. The soft wheats are used for making flat bread, cakes, pastries, crackers, muffins, and biscuits.
</p>
        
        <p>Wheat is planted to a limited extent as a forage crop for livestock, although the straw cannot be used as feed. Its straw can be used as a construction material for roofing thatch. The whole grain can be milled to leave just the endosperm for white flour. The by-products of this are bran and germ. The whole grain is a concentrated source of vitamins, minerals, and protein, while the refined grain is mostly starch.


</p>

    </div>
    </div>
</div>
</div>
</article></div>
<div style="margin-left:15px;"><INPUT TYPE="button" VALUE="&laquo;Back" onClick="history.go(-1);" style="font-size:14px"></div>

</div>
                   
         
            <?php include('footer.php'); ?>