<?php include('header.php'); ?>
<?php include('left_section.php'); ?>


<div class="art-layout-cell art-content clearfix">
<article class="art-post art-article">


<?php foreach($row as $r): ?>
<div style=" margin:20px 2px 5px 2px; width:100%;">

<img style="width:550px; margin-left:100px;" src="<?php echo base_url()."upload/".$r->product_imag; ?>" />
<a href="<?php echo base_url(); ?>index.php/product/show_detail?v1=<?php echo $r->cp_id; ?>" style="width:30%; color:#fff; font-size:16px">
<p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:16px; background:#2E9206; width:537px; margin-left:100px; padding:8px">
<?php echo $r->product_name; ?>

</p>
</a>
</div>
<?php endforeach ?>
</article>


<div style="float:left; width:534px; margin-left:110px; height:auto; padding:10px; border:1px solid #ccc;">
<span style="font-size:14px;"><?php echo $links; ?></span>
</div>

</div>

<?php include('footer.php'); ?>