<?php include('header.php'); ?>
<?php include('left_section.php'); ?>
<div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Fertilizer Recommender</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%" >
<p></p>
<h2>How to Use Fertilizer Recommender</h2>
 <p></p>       
 <p></p><strong>       
<strong> <p style="font-family:Georgia, 'Times New Roman', Times, serif;">
 <ol start="1">
 <li>Enter the all Elements of Soil Test Report</li>
 <li>Select the Elements From Drop Down.</li>
 <li>System tell the quantity type and gives the description of soil.</li>
 </ol>
 </p></strong>
   
 <div style=" margin:50px 0px 0px -80px;">
   <center><a href="<?php echo base_url(); ?>index.php/s_recomender/index1"><img src="<?php echo base_url(); ?>images/start.png" /></a></center> 
   </div>    
    </div>
    </div>
</div>
</div>
</article></div>
                   
            <?php include('footer.php'); ?>