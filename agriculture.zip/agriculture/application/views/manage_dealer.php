<?php include('header.php'); ?>
<?php include('left_emp.php'); ?>



<div class="art-layout-cell art-content clearfix">
 <article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Manage Dealers</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">



<table align="center"  cellpadding="2" cellspacing="2" width="850" border="1" style=" border-radius:8px; margin:50px 0px 0px -3px;">
<tr>
<th>User Name</th>
<th>Email</th>
<th>Full Name</th>
<th>Address</th>
<th>Gender</th>
<th>Phone</th>
<th>Area</th>
<th>Edit</th>
<th>Delete</th>
</tr>
<?php  foreach($row as $r):  ?>
<tr>
<td><?php echo $r->dealer_name; ?></td>
<td><?php echo $r->email; ?></td>
<td><?php echo $r->first_name.' '.$r->last_name; ?></td>
<td><?php echo $r->address.','.$r->city.','.$r->country; ?></td>
<td><?php echo $r->gender; ?></td>
<td><?php echo $r->phone; ?></td>
<td><?php echo $r->dealer_area; ?></td>
<td><a href="<?php echo base_url(); ?>index.php/dealer/edit/<?php echo $r->dealer_id; ?>"><img src="<?php echo base_url(); ?>images/edit.jpg" width="20"  /></a></td>
<td><a href="<?php echo base_url(); ?>index.php/dealer/delete/<?php echo $r->dealer_id; ?>"><img src="<?php echo base_url(); ?>images/delete.jpg"
width="20" /></a></td>
</tr>
<?php endforeach; ?>
</table>
<div style="margin-top:10px"><a href="<?php echo base_url(); ?>index.php/dealer/dealer_back"><button>Back</button></a></div>
</div>


</div>
</article>
</div>

<?php include('footer.php'); ?>