<?php include('header.php'); ?>
 <?php include('left_section.php'); ?>  

                        <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                           
                              
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 25%" >
        <img width="208" height="208" alt="" src="http://localhost/agriculture/images/cotton-Austrailia.jpg">
    </div><div class="art-layout-cell layout-item-2" style="width: 25%" >
    <img width="208" height="208" alt="" src="http://localhost/agriculture/images/golden-rice.jpg" class="">
        
    </div><div class="art-layout-cell layout-item-2" style="width: 25%" >
        <img width="208" height="208" alt="" src="http://localhost/agriculture/images/gm-wheat1.jpg" class="">
    </div>
    </div>
</div>
</div>
<div class="art-content-layout-wrapper layout-item-3">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-4" style="width: 25%" >
        <h4>Cotton</h4>
    </div><div class="art-layout-cell layout-item-5" style="width: 25%" >
        <h4>Rice</h4>
    </div><div class="art-layout-cell layout-item-6" style="width: 25%" >
        <h4>Wheat</h4>
    </div>
    </div>
</div>
</div>
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-8" style="width: 25%" >
        <p style="text-align: justify; min-height:70px">Cotton is a soft, fluffy staple fiber that grows in a boll, or protective capsule, around the seeds of cotton plants of the genus Gossypium in the family of Malvaceae. The fiber is almost pure cellulose. Under natural conditions, the cotton bolls will tend to increase the dispersion of the seeds.</p>
        <p><a href="<?php echo base_url(); ?>index.php/home/cotton" class="art-button">Read more</a></p>
    </div><div class="art-layout-cell layout-item-8" style="width: 25%" >
        <p style=" min-height:70px; min-height:70px">Rice is the seed of the monocot plants Oryza sativa (Asian rice) or Oryza glaberrima (African rice). As a cereal grain, it is the most widely consumed staple food for a large part of the world's human population, especially in Asia. It is the grain with the third-highest worldwide production, after sugarcane and maize, according to data of FAOSTAT 2012.</p>
        <p><a href="<?php echo base_url(); ?>index.php/home/rice" class="art-button">Read more</a></p>
    </div><div class="art-layout-cell layout-item-8" style="width: 25%" >
        <p>Wheat is a cereal grain, originally from the Levant region of the Near East but now cultivated worldwide. In 2010, world production of wheat was 651 million tons, making it the third most-produced cereal after maize (844 million tons) and rice (672 million tons). Wheat was the second most-produced cereal in 2009; world production in that year was 682 million tons, after maize (817 million tons), and with rice as a close third (679 million tons). </p>
        <p><a href="<?php echo base_url(); ?>index.php/home/wheat" class="art-button">Read more</a></p>

    </div>
</div>
    <div style="float:left; width:303%; font-size:12px; margin-top:15px; border-top:1px dotted #ccc; padding-bottom:40px" >
    <p><span style="text-align: justify;"></span></p>
        <h1>Agricuture</h1>
        
                <p>Agriculture is the backbone of Pakistan's economy. Keeping in view the ever increasing demand for quality agricultural inputs, the company was established in 1993. Initially, the core business of the company was manufacturing and marketing of agrochemicals.</p>
        <p>The objective of the group evolves from the collective determination of our people to excel in providing continuous customer satisfaction through our quality products at the right price.<!--<a href="#" title="Read More">[...]</a>--></p>
        

        
        
 
    </div>
</div>
</article>
</div>
                    
                    
                  
              
      <?php include('footer.php'); ?>          
      </div>