

                
                        <div class="art-layout-cell art-sidebar1 clearfix" style="width:21%; float:left"><div class="art-vmenublock clearfix">
<div class="header"><h3>Employee Area</h3></div>


        <div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="<?php echo base_url(); ?>index.php/employee/create1">Add Dealer</a></li>
<li><a href="<?php echo base_url(); ?>index.php/dealer/show?var1=<?php echo $this->session->userdata('city'); ?>"> Manage Dealers </a></li>
<li><a href="<?php echo base_url(); ?>index.php/product/order?c1=<?php echo $this->session->userdata('city'); ?>"> Manage Orders </a></li>

<li><a href="<?php echo base_url(); ?>index.php/product/daily_rpt?cs=<?php echo $this->session->userdata('city'); ?>">Daily Report</a></li>
<li><a href="<?php echo base_url(); ?>index.php/employee/manage_report?rpt=<?php echo $this->session->userdata('emp_id'); ?>">Manage Report

</a></li>

<li><a href="<?php echo base_url(); ?>index.php/employee/logout"><img src="http://localhost/agriculture/images/logout.png" /></a></li>
</ul>
                
 </div>       
</div> 

<div style="width:96%; float:left; margin-left:4px;"><a href="#"><img src="http://localhost/agriculture/images/weather-widget.jpg" style="width:100%; opacity:0.9" /></a></div>
</div>

