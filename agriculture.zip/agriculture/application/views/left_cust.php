

                
                        <div class="art-layout-cell art-sidebar1 clearfix" style="width:21%;"><div class="art-vmenublock clearfix">
   
<div class="header"><h3>Customer Area</h3></div>


        <div class="art-vmenublockcontent">
<ul class="art-vmenu"><li><a href="<?php echo base_url()?>index.php/customer/c_ord" >New Order</a></li>
<li><a href="<?php echo base_url(); ?>index.php/customer/order?c_id=<?php echo $this->session->userdata('customer_id'); ?>">Your Orders</a></li>
<li><a href="<?php echo base_url(); ?>index.php/customer/logout"><img src="http://localhost/agriculture/images/logout.png" /></a></li>
</ul>
                
 </div>       
</div> 

<div style="width:96%; float:left; margin-left:4px;"><a href="#"><img src="http://localhost/agriculture/images/weather-widget.jpg" style="width:100%; opacity:0.9" /></a></div>
</div>

