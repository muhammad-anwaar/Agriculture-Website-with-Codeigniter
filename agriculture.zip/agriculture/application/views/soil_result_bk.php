<?php // include('header.php'); ?>
<?php //include('left_section.php'); ?>
<!--  <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                <div class="art-postmetadataheader">
                                        <h2 class="art-postheader"><span class="art-postheadericon">Soil Recomender</span></h2>
                                                            
                                    </div>
                                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">-->
    <!--<div class="art-layout-cell layout-item-0" style="width: 100%" >-->
        <!--<h2>Enter The Following Information</h2>-->
        <div id="soil">
        <?php foreach($result as $row):
		$c_name=$row->crop;
		if($c_name==' '){
		 ?>
          <table align="center" width="700" cellpadding="2" cellspacing="2">
        <tr><td><label style="font-size:16px;">Crop Name</label></td><td ><label style="font-size:14px"><?php echo $c_name; ?></label></td></tr>
        <tr><td><label style="font-size:16px;">Date</label></td><td><label style="font-size:14px"><?php echo date('Y-M-d'); ?></label></td></tr>
        </table>
        <table align="center" width="700" cellpadding="2" cellspacing="2" border="1" style="margin-top:25px; border-radius:5px;">
        
        
        <tr style="background: #999;">
        <th >Elements</th>
        <th >Test Results</th>
        <th >Interpretations</th>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">N</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->n; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->n>=100 && $row->n<=499)
		{  echo "Low"; } else if(($row->n>=500 && $row->n<=799))
		{ echo "Adequate";}
		else if(($row->n>=800 && $row->n<=1000))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">K</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->k; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->k>=100 && $row->k<=150)
		{  echo "Low"; } else if(($row->k>=151 && $row->k<=170))
		{ echo "Adequate";}
		else if(($row->k>=171 && $row->k<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">Mg</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mg; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mg>=100 && $row->mg<=150)
		{  echo "Low"; }
		 else if(($row->mg>=151 && $row->mg<=170))
		{ echo "Adequate";}
		else if(($row->mg>=171 && $row->mg<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">S</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->s; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->s>=1 && $row->s<=4)
		{  echo "Low"; }
		 else if(($row->s>=5 && $row->s<=7))
		{ echo "Adequate";}
		else if(($row->s>=8 && $row->s<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">Mn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mn>=1 && $row->mn<=4)
		{  echo "Low"; }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ echo "Adequate";}
		else if(($row->mn>=8 && $row->mn<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">Zn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->zn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->zn>=0.01 && $row->zn<=0.04)
		{  echo "Low"; }
		 else if(($row->zn>=0.05 && $row->zn<=0.07))
		{ echo "Adequate";}
		else if(($row->zn>=0.08 && $row->zn<=0.10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        </table>
        
        <?php } 
		else if($c_name=='rice')
		{
			?>
            
		
          <table align="center" width="700" cellpadding="2" cellspacing="2">
        <tr><td><label style="font-size:16px;">Crop Name</label></td><td ><label style="font-size:14px"><?php echo $c_name; ?></label></td></tr>
        <tr><td><label style="font-size:16px;">Date</label></td><td><label style="font-size:14px"><?php echo date('Y-M-d'); ?></label></td></tr>
        </table>
        <table align="center" width="700" cellpadding="2" cellspacing="2" border="1" style="margin-top:25px; border-radius:5px;">
        
        
        <tr style="background: #999;">
        <th >Elements</th>
        <th >Test Results</th>
        <th >Interpretations</th>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">N</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->n; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->n>=100 && $row->n<=400)
		{  echo "Low"; } else if(($row->n>=401 && $row->n<=650))
		{ echo "Adequate";}
		else if(($row->n>=651 && $row->n<=1000))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">K</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->k; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->k>=100 && $row->k<=130)
		{  echo "Low"; } else if(($row->k>=131 && $row->k<=165))
		{ echo "Adequate";}
		else if(($row->k>=166 && $row->k<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">Mg</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mg; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mg>=100 && $row->mg<=125)
		{  echo "Low"; }
		 else if(($row->mg>=126 && $row->mg<=160))
		{ echo "Adequate";}
		else if(($row->mg>=161 && $row->mg<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">S</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->s; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->s>=1 && $row->s<=3)
		{  echo "Low"; }
		 else if(($row->s>=4 && $row->s<=7))
		{ echo "Adequate";}
		else if(($row->s>=7 && $row->s<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">Mn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mn>=1 && $row->mn<=4)
		{  echo "Low"; }
		 else if(($row->mn>=5 && $row->mn<=8))
		{ echo "Adequate";}
		else if(($row->mn>8 && $row->mn<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; position:absolute; margin-left:84px;">Zn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->zn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->zn>=0.01 && $row->zn<=0.03)
		{  echo "Low"; }
		 else if(($row->zn>=0.04 && $row->zn<=0.07))
		{ echo "Adequate";}
		else if(($row->zn>=0.08 && $row->zn<=0.10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        </table>
        
        <?php 
			
			}
			else 
			{
		?>
        
		 
          <table align="center" width="700" cellpadding="2" cellspacing="2">
        <tr><td><label style="font-size:16px;">Crop Name</label></td><td ><label style="font-size:14px"><?php echo $c_name; ?></label></td></tr>
        <tr><td><label style="font-size:16px;">Date</label></td><td><label style="font-size:14px"><?php echo date('Y-M-d'); ?></label></td></tr>
        </table>
        <table align="center" width="700" cellpadding="2" cellspacing="2" border="1" style="margin-top:25px; border-radius:5px;">
        
        
        <tr style="background: #999;">
        <th >Elements</th>
        <th >Test Results</th>
        <th >Interpretations</th>
        </tr>
        <tr>
        <td align="center"><label style="font-size:14px; margin-left:84px;">N</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->n; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->n>=100 && $row->n<=300)
		{  echo "Low"; } else if(($row->n>=301 && $row->n<=799))
		{ echo "Adequate";}
		else if(($row->n>=800 && $row->n<=1000))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">K</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->k; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->k>=100 && $row->k<=141)
		{  echo "Low"; } else if(($row->k>=142 && $row->k<=160))
		{ echo "Adequate";}
		else if(($row->k>=161 && $row->k<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; margin-left:84px;">Mg</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mg; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mg>=100 && $row->mg<=150)
		{  echo "Low"; }
		 else if(($row->mg>=151 && $row->mg<=180))
		{ echo "Adequate";}
		else if(($row->mg>=181 && $row->mg<=200))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; margin-left:84px;">S</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->s; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->s>=1 && $row->s<=3)
		{  echo "Low"; }
		 else if(($row->s>=4 && $row->s<=7))
		{ echo "Adequate";}
		else if(($row->s>=8 && $row->s<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px;  margin-left:84px;">Mn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->mn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->mn>=1 && $row->mn<=4)
		{  echo "Low"; }
		 else if(($row->mn>=5 && $row->mn<=7))
		{ echo "Adequate";}
		else if(($row->mn>=8 && $row->mn<=10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        
        <tr>
        <td align="center"><label style="font-size:14px; margin-left:84px;">Zn</label></td>
        <td align="center"><label style="font-size:14px;  margin-left:98px;"><?php echo $row->zn; ?></label></td>
        <td align="center"><label style="font-size:14px; margin-left:150px;"><?php if($row->zn>=0.01 && $row->zn<=0.03)
		{  echo "Low"; }
		 else if(($row->zn>=0.04 && $row->zn<=0.06))
		{ echo "Adequate";}
		else if(($row->zn>=0.07 && $row->zn<=0.10))
		{ echo "Excessive";}
		 ?></label></td>
        </tr>
        </table>
        
        
        <?php } ?>
        <div style="margin-top:15px;"><label style="font-size: 18px;">Description:</label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <?php if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   
      This Soil is not Suitable for the Crop. All the Elements are in Low quantity.</p>
     <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
     <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
        <?php } 
		else if($row->n>=100 && $row->n<=499 && $row->k>=150 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
     <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
     <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
        
        <?php } 
		else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
     <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
     <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
     <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php } 
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
          <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     
        
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
          <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
          <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 4 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>

        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
     <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 3 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>       
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop . All the Elements are not in suitable quantity.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=140 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for this Crop  . All the Elements are not in suitable quantity.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the this crop  . All the Elements are not in suitable quantity.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for this crop  . All the Elements are not in suitable quantity.</p>
          <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   This Soil is not Suitable for the Crop  . All the Elements are not in suitable quantity.</p>
          <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">   The elements in the soil is in medium quantity.it produces the crop on medium level .</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; ">  This Soil is not Suitable for the Crop   . All the Elements are not in suitable quantity.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in good quantity.The Production level of soil is good.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>

        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil is not Suitable for the Crop  . All the Elements are not in suitable quantity.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in good quantity.The Production level of soil is good.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in good quantity.The Production level of soil is good.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in good quantity.The Production level of soil is on its peak level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in good quantity.The Production level of soil is on its peak level.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in good quantity.The Production level of soil is on its peak level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
     
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=149 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements in good quantity.The Production level of soil is on its peak level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>

        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in average quantity.The Production level of soil is average level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in low quantity.The Production level of soil is Low level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=150 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak level.</p>
     <p style="font-size:18px;">All Values is  at good level.There is  no need of fertilizer.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak level.</p>
     <p style="font-size:18px;">All Values  are at good level this soil does not need any fertilizer.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
             <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Excessive quantity.The Production level of soil is Peak  level.</p>
        <p style="font-size:18px;">No Need Any Fertilizer </p>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Excessive quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Excessive quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=149 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 4 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=150 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 4 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 5 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low level.</p>
                <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 4 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 3 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average level.</p>
         <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 3 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10 
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=150 && $row->k<=170 && $row->mg>=150 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=150 && $row->mg<=170 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7 
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=5 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Peak quantity.The Production level of soil is Peak  level.</p>
        
        <?php }
		
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.01 && $row->zn<=0.01){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
         <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
			else if($row->n>=500 && $row->n<=699 && $row->k>=100 && $row->k<=149 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
        
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=150 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
        
        <?php }
		else if($row->n>=800 && $row->n<=1000 && $row->k>=150 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
        
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=149 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
         <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=149 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
         <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
        <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
     <p style="font-size:18px; font-family:Georgia, 'Times New Roman', Times, serif">No need any fertilizer .All Elements are in good quantity.</p>
     <?php }
		else if($row->n>=100 && $row->n<=400 && $row->k>=151 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
        
        <?php }
		  else if($row->n>=100 && $row->n<=400 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<=4 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
         <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 3 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 4 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 3 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Zingro</b>: 3 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=100 && $row->k<=150 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 3 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>

      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
         <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=8 && $row->mn<=10 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
     <p style="font-size:18px; font-family:Georgia, 'Times New Roman', Times, serif;">All Elements are in good quantity.No need any Fertilizer.</p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
     <p style="font-size:18px; font-family:Georgia, 'Times New Roman', Times, serif">No Need any Fertilizer.All Elements are in good quantity.</p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
 <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 1 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<=7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
 	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
 <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 1 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
     
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	  <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Beat quantity.The Production level of soil is Best  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	 <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>

      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
      <?php }
		  else if($row->n>=800 && $row->n<=1000 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>

      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 4 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 3 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	  <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
  
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 1 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>

      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	   <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
    
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	 <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
     <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	   <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	   <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
	   <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=171 && $row->mg<=200 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>

      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=100 && $row->k<=150 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in peak quantity.The Production level of soil is peak  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in peak quantity.The Production level of soil is peak  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>

      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=1 && $row->s<=4
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=151 && $row->k<=170 && $row->mg>=171 && $row->mg<=200 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Best quantity.The Production level of soil is Best  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	  <?php }
		  else if($row->n>=500 && $row->n<=799 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=100 && $row->mg<=150 && $row->s>=5 && $row->s<=7
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 4 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 3 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=8 && $row->mn<= 10 && $row->zn>=0.08 && $row->zn<=0.10){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
 
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=171 && $row->k<=200 && $row->mg>=151 && $row->mg<=170 && $row->s>=8 && $row->s<=10
		&& $row->mn>=5 && $row->mn<= 7 && $row->zn>=0.05 && $row->zn<=0.07){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Good quantity.The Production level of soil is Good  level.</p>
 <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>

      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 <?php }
		  else if($row->n>=100 && $row->n<=499 && $row->k>=151 && $row->k<=170 && $row->mg>=151 && $row->mg<=170 && $row->s>=5 && $row->s<=7
		&& $row->mn>=1 && $row->mn<= 4 && $row->zn>=0.01 && $row->zn<=0.04){ ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px; "> This Soil Contains the Elements are in Low quantity.The Production level of soil is Low  level.</p>
      <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 4 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 2 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 3 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 2 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 
	 
        <?php }
		 else { ?>
        
     <p style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:14px;  font-size:14px; "> This Soil Contains the Elements are in Average quantity.The Production level of soil is Average  level.</p>
	  <p style="font-size:16px;">The System Recomends The Following Fertilizer.</p>
        <p><b>DAP</b>: 2 bags/Acre</p>
     <p><img src="../../upload/dap.jpg" width="250"  /></p>
      <p><b>Urea</b>: 3 bags/Acre</p>
     <p><img src="../../upload/urea.jpg" width="250"  /></p>
      <p><b>Zingro</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zingro.jpg" width="250"  /></p>
      <p><b>Zorawar</b>: 1 bags/Acre</p>
     <p><img src="../../upload/zorawar.jpg" width="250"  /></p>
	 
        <?php }
		  ?>
        </div>
        <?php endforeach; ?>
        </div>
        <div align="center"><img 
src="http://Localhost/agriculture/images/pdf.jpg" style="width:193px; height:30px;" onClick=" return downloads();" /></div>
   <!-- </div>-->
    
    <!--</div>
    <div><INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);"></div>
</div>
</div>
</article></div>-->
         
            <?php //include('footer.php'); ?>
			<script type="text/javascript">
function downloads()
{
							var DocumentContainer = document.getElementById('soil');
		                var WindowObject = window.open('', "PrintWindow",              "width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
	              	 WindowObject.document.writeln(DocumentContainer.innerHTML);
		             WindowObject.document.close();
		             WindowObject.focus();
		             WindowObject.print();
		             WindowObject.close();
	}
	
	</script>