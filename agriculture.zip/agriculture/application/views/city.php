<?php 
if($state=='punjab')
{
?>
<select name="city" id="city" style="width:226px; border-radius:4px; height:36px;">
<option value="multan">Multan</option>
<option value="dgkhan">DG Khan</option>
<!--<option value="rajanpur">Rajanpur</option>-->
<option value="bhawalpur">Bhawalpur</option>
<option value="lahore">Lahore</option>
<option value="gujranwala">Gujranwala</option>
<option value="sialkot">Sialkot</option>
</select>
<?php
	}
	else if($state=='sindh')
	{
?>
<select name="city" id="city" style="width:226px; border-radius:4px; height:36px;">
<option value="karachi">karachi</option>
<option value="jamshuru">jamshuru</option>
<option value="haidrabad">haidrabad</option>
</select>
<?php } else if($state=='balochistan'){ ?>
<select name="city" id="city" style="width:226px; border-radius:4px; height:36px;">
<option value="khusdar">khusdar</option>
<option value="quetta">quetta</option>
</select>
<?php }
else if($state=='khyber'){
 ?>
 <select name="city" id="city" style="width:226px; border-radius:4px; height:36px;">
<option value="peshawar">peshawar</option>
<option value="dikhan">DI khan</option>
</select>
 <?php } ?>
 
<script type="text/javascript">
                 var crop = $('#crop').val();
				var city=$("#city").val();
				
			$("#shw_2").load("varity",{"crop":crop,"city":city});
			
$('#city').change(function(){
                var crop = $('#crop').val();
				var city=$("#city").val();
				
			$("#shw_2").load("varity",{"crop":crop,"city":city});
				
            });	
</script>