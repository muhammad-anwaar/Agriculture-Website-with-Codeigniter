<?php 
if(!defined('BASEPATH')) exit('No Direct script access');

class Employee_model extends CI_Model{
   public function __construct()
    {
        parent::__construct();
    }
	    function login($username,$password){
        $this->db->where("emp_name",$username);
        $this->db->where("password",$password);

        $query=$this->db->get("agri_employee");
		
		
        if($query->num_rows()>0){
          foreach($query->result() as $rows){
			//echo  $rows->emp_name;
           //add all data to session
           $newdata = array(
             'emp_id'  => $rows->emp_id,
             'emp_name'  => $rows->emp_name,
			 'city'=>$rows->city,
             'logged_in'  => TRUE,
           );
         }
         $this->session->set_userdata($newdata);
         return true;
        }else{
            $this->session->set_flashdata('login_error','Invalid username or password');
            return false;
        }
  
      }
          
 public function record_count()
      {
        return $this->db->count_all("agri_employee");	
	
	
	}
  
  
  public function get_emp($limit, $start)
    {
	  $this->db->limit($limit, $start);
	  $this->db->select('*');
	  $this->db->from('agri_employee');
	  $query=$this->db->get();
	  return $query->result();
	  
	  }
	  
	public function get_emps($id)
	{
		$this->db->select('*');
		$this->db->where('emp_id',$id);
		$this->db->from('agri_employee');
		$query=$this->db->get();
		return $query->result();
		
		
		} 
		
		
		
	public function employee_update($id)
	{
		$data=array(
		'emp_name'=>$this->input->post('emp_name'),
		'email'=>$this->input->post('email'),
		'password'=>$this->input->post('password'),
		'address'=>$this->input->post('address'),
		'city'=>$this->input->post('city'),
		'state'=>$this->input->post('state'),
		'country'=>$this->input->post('country'),
		'db'=>$this->input->post('db'),
		'emp_area'=>$this->input->post('emp_area')
		
		);
		
		$this->db->where('emp_id',$id);
		$this->db->update('agri_employee',$data);
		}	
		
	public function add_employee()
	{
		$data=array(
		'emp_name'=>$this->input->post('emp_name'),
		'email'=>$this->input->post('email'),
		'password'=>md5($this->input->post('password')),
		'address'=>$this->input->post('address'),
		'city'=>$this->input->post('city'),
		'state'=>$this->input->post('state'),
		'country'=>$this->input->post('country'),
		'db'=>$this->input->post('db'),
		'emp_area'=>$this->input->post('emp_area')
		
		);
		$this->db->insert('agri_employee',$data);
		
		}	
		
	public function add_report()
	{
		
		$insert_data=array(
		'farmer_name'=>$this->input->post('farmer_name'),
		'dealer_rf_name'=>$this->input->post('dealer_rf_name'),
		'c_date'=>$this->input->post('c_date'),
		'visited_area'=>$this->input->post('v_address'),
		'city'=>$this->input->post('v_city'),
		'description'=>$this->input->post('description'),
		'emp_id'=>$this->input->post('emp_id'),
		'report_title'=>$this->input->post('report_title')
		);
		$this->db->insert('agri_daily_report',$insert_data);
		}	 
  
  public function manage_report($emp_id)
  {
	  $this->db->select('*');

      $this->db->where('emp_id',$emp_id);
      $this->db->from('agri_daily_report');
	  $query=$this->db->get();
	  return $query->result();
      
	  	  }
 public function d_report($r_id)
 {
	 $this->db->select('*');

      $this->db->where('report_id',$r_id);
      $this->db->from('agri_daily_report');
	  $query=$this->db->get();
	  return $query->result();
	 
	 }
	 
 public function admin_report()
 {
	 $this->db->select('*');

   // $this->db->where('c_date',date('Y-m-d'));	
	$this->db->from('agri_daily_report');
	$query=$this->db->get();
	return $query->result(); 
	 }
	 
 public function del_rpt($r_id)
 {
	 $this->db->where('report_id',$r_id);
	 $this->db->delete('agri_daily_report');
	 }	 
	 
public function emp_del($id)
{
	
	$this->db->where('emp_id', $id);
$this->db->delete('agri_employee'); 
	
	}	 
	 	 
	
	}


?>