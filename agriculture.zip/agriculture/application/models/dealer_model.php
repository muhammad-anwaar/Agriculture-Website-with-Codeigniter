<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dealer_model extends CI_Model {
    
    public function __construct()
    {
        parent::__construct();
    }
	    function login($username,$password){
			
        $this->db->where("dealer_name",$username);
        $this->db->where("password",$password);

        $query=$this->db->get("agri_dealer");
	
        if($query->num_rows()>0){
          foreach($query->result() as $rows){
           //add all data to session
           $newdata = array(
             'dealer_id'  => $rows->dealer_id,
             'dealer_name'  => $rows->dealer_name,
             'logged_in'  => TRUE,
           );
         }
         $this->session->set_userdata($newdata);
         return true;
        }else{
            $this->session->set_flashdata('login_error','Invalid username or password');
            return false;
        }
  }
	
public function add_dealer()
{
	$data=array(
	'dealer_name'=>$this->input->post('user_name'),
			'email'=>$this->input->post('email'),
			'password'=>md5($this->input->post('password')),
			'first_name'=>$this->input->post('first_name'),
			'last_name'=>$this->input->post('last_name'),
			'address'=>$this->input->post('address'),
			'city'=>$this->input->post('city'),
			'country'=>$this->input->post('country'),
			'phone'=>$this->input->post('phone'),
			'dj'=>$this->input->post('dj'),
			'dob'=>$this->input->post('dob'),
			'gender'=>$this->input->post('gender'),
			'dealer_area'=>$this->input->post('dealer_area ')
	
	);
	$this->db->insert('agri_dealer',$data);
	
	}
	
public function get_dealer($emp_city)
{ //echo $emp_city;
	$this->db->select('*');
	$this->db->from('agri_dealer');
	$this->db->where('city',$emp_city);
	$query=$this->db->get();
	
	return $query->result();
	
	}		
	
public function show_info($dealer_id)
{
	$this->db->select('*');
    $this->db->from('agri_dealer');
	$this->db->where('dealer_id',$dealer_id);
	$query=$this->db->get();
	return $query->result();
		
	}	
	
public function	edit_info($dealer_id)
	{
		$data=array(
		'dealer_name'=>$_POST['delear_name'],
		'email'=>$_POST['email'],
		'password'=>$_POST['password'],
		'first_name'=>$_POST['first_name'],
		'last_name'=>$_POST['last_name'],
		'address'=>$_POST['address'],
		'city'=>$_POST['city'],
		'country'=>$_POST['country'],
		'dj'=>$_POST['dj'],
		'dob'=>$_POST['dob'],
		'gender'=>$_POST['gender'],
		'phone'=>$_POST['phone'],
		'dealer_area'=>$_POST['dealer_area']
		
		);
		$this->db->where('dealer_id',$dealer_id);
		$this->db->update('agri_dealer',$data);
		
		return $data;
		}
		
		
public function delete($dealer_id)
{
	$this->db->where('dealer_id',$dealer_id);
	$this->db->delete('agri_dealer');
	
	}
	
	public function show_cus_order($id)
	{
		$this->db->select('*');
		$this->db->where('dealer_id',$id);
		$this->db->from('agri_order');
		$this->db->order_by('order_id','desc');
		$query=$this->db->get();
		
		return $query->result();
		
		}
	
			
}

