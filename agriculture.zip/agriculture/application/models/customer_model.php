<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Customer_model extends CI_Model {
    
    public function __construct()
    {
        parent::__construct();
    }
	public function login($username,$password){
		
        $this->db->where("customer_name",$username);
        $this->db->where("password",$password);
       $query=$this->db->get("agri_customer");
	  // $res=$query->result();
	  
   if($query->num_rows()>0){
          foreach($query->result() as $rows){
			//echo  $rows->customer_name;
           //add all data to session
           $newdata = array(
             'customer_id'  => $rows->customer_id,
             'customer_name'  => $rows->customer_name,
             'logged_in'  => TRUE,
           );
         }
         $this->session->set_userdata($newdata);
         return true;
        }else{
            $this->session->set_flashdata('login_error','Invalid username or password');
            return false;
        }
  }
  
 public function show_area()
 {
	 $this->db->select('*');
	 $this->db->from('agri_dealer');
	 $query=$this->db->get();
	 
	 return $query->result();
	 }  
	
public function add_customer()
{
	$data=array(
	'customer_name'=>$this->input->post('user_name'),
			'email'=>$this->input->post('email'),
			'password'=>md5($this->input->post('password')),
			'first_name'=>$this->input->post('first_name'),
			'last_name'=>$this->input->post('last_name'),
			'address'=>$this->input->post('address'),
			'city'=>$this->input->post('city'),
			'country'=>$this->input->post('country'),
			'phone'=>$this->input->post('phone'),
			'dj'=>$this->input->post('dj'),
			'dob'=>$this->input->post('dob'),
			'gender'=>$this->input->post('gender')
	
	);
	$this->db->insert('agri_customer',$data);
	
	}	
	
	public function show_cus_order($id)
	{
		$this->db->select('*');
		$this->db->where('customer_id',$id);
		$this->db->from('agri_order');
		$this->db->order_by('order_id',"desc");
		
		$query=$this->db->get();
		return $query->result();
		
		}
		
		 public function record_count()
      {
        return $this->db->count_all("agri_employee");	
	
	
	}
	
	
public function show_customers($limit,$start)
 {
	$this->db->limit($limit,$start);
	$this->db->select('*');
	$this->db->from('agri_customer');
	$query=$this->db->get();
	return $query->result();
	
	
	
	}	
	
	
	public function get_cust($id)
	{
		$this->db->select('*');
		$this->db->where('customer_id',$id);
		$this->db->from('agri_customer');
		$query=$this->db->get();
		return $query->result();
		
		}
		
		
	public function cust_upd($id)
	{
		
			$data=array(
	'customer_name'=>$this->input->post('user_name'),
			'email'=>$this->input->post('email'),
			'password'=>md5($this->input->post('password')),
			'first_name'=>$this->input->post('first_name'),
			'last_name'=>$this->input->post('last_name'),
			'address'=>$this->input->post('address'),
			'city'=>$this->input->post('city'),
			'country'=>$this->input->post('country'),
			'phone'=>$this->input->post('phone'),
			'dj'=>$this->input->post('dj'),
			'dob'=>$this->input->post('dob'),
			'gender'=>$this->input->post('gender')
	
	);
	
	$this->db->where('customer_id',$id);
	$this->db->update('agri_customer',$data);
		
		}	
		
		
	public function del_cust($id)
	{
		$this->db->where('customer_id',$id);
		$this->db->delete('agri_customer');
		
		}	
		
		public function all_product()
		{
			$this->db->select('*');
			$this->db->from('agri_company_product');
			$query_rec=$this->db->get();
			return $query_rec->result();
			}
			
			public function reset_password($email)
			{
				$this->db->select('*');
				$this->db->where('email',$email);
				$this->db->from('agri_customer');
				$query=$this->db->get();
				return $query->result();
				
				}
				
		public function reset_password1($email)
			{
				$this->db->select('*');
				$this->db->where('email',$email);
				$this->db->from('agri_dealer');
				$query=$this->db->get();
				return $query->result();
				
				}
				
		public function reset_password2($email)
			{
				$this->db->select('*');
				$this->db->where('email',$email);
				$this->db->from('agri_employee');
				$query=$this->db->get();
				return $query->result();
				
				}
	
	public function current_pass()
	{
		$email=$this->input->post('email');
		$pass=md5($this->input->post('password'));
		$data=array(
		'password'=>$pass
		);
		$this->db->where('email',$email);
		$this->db->update('agri_customer',$data);
				}
				
public function current_pass1()
	{
		$email=$this->input->post('email');
		$pass=md5($this->input->post('password'));
		$data=array(
		'password'=>$pass
		);
		$this->db->where('email',$email);
		$this->db->update('agri_dealer',$data);
				}
	
	public function current_pass2()
	{
		 $email=$this->input->post('email');
		 $pass=md5($this->input->post('password'));
		$data=array(
		'password'=>$pass
		);
		$this->db->where('email',$email);
		$this->db->update('agri_employee',$data);
				}
	
}