<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Order_model extends CI_Model {
    
    public function __construct()
    {
        parent::__construct();
    }
	
	public function add_order()
	{
		$cutomer=$this->input->post('customer_id');
		$dealer=$this->input->post('dealer_id');
		if(!empty($cutomer))
		{
			$this->db->select("*");
			$this->db->where("customer_id",$cutomer);
			$this->db->from("agri_customer");
			$q=$this->db->get();
			$res=$q->result();
			foreach($res as $r)
			{
				$c_name=$r->customer_name;
				}
			}
		else
		{
			$this->db->select("*");
			$this->db->where("dealer_id",$dealer);
			$this->db->from("agri_dealer");
			$q=$this->db->get();
			$res1=$q->result();
			foreach($res1 as $r)
			{
				$c_name=$r->dealer_name;
				}
			
			
			}
		
		$data=array(
		'order_product'=>$this->input->post('product_name'),
		'order_quantity'=>$this->input->post('order_quantity'),
		'order_date'=>$this->input->post('order_date'),
		'order_address'=>$this->input->post('order_address'),
		'order_city'=>$this->input->post('order_city'),
		'order_state'=>$this->input->post('order_state'),
		'order_country'=>$this->input->post('order_country'),
		'order_type'=>$this->input->post('order_type'),
		'customer_id'=>$this->input->post('customer_id'),
		'dealer_id'=>$this->input->post('dealer_id'),
		'c_d_name'=>$c_name,
		'order_status'=>$this->input->post('order_status'),
		'area'=>$this->input->post('area')
		
		);
		
		$this->db->insert('agri_order',$data);
		}
		
		
	public function show_order($city)
	{
		
		$this->db->select('*');
		$this->db->where('area',$city);
		$this->db->order_by('order_id','desc');
		$this->db->from('agri_order');
        $query=$this->db->get();
		return $query->result();		
		}
		
	public function add_order_company()
	{
		$data=array(
		'order_id'=>$this->input->post('order_id'),
		'product'=>$this->input->post('order_product'),
		'quantity'=>$this->input->post('order_quantity'),
		'date'=>$this->input->post('order_date'),
		'address'=>$this->input->post('order_address'),
		'city'=>$this->input->post('order_city'),
		'state'=>$this->input->post('order_state'),
		'country'=>$this->input->post('order_country'),
		'order_type'=>$this->input->post('order_type')
		);
		
	
	   $this->db->insert('agri_company_order',$data);
		}		
		
public function manage_order_company()
	{
		 $order_id=$this->input->post('order_id');
		$datas=array(
     'order_status'=>'1'
		);
        $this->db->where('order_id',$order_id);
	   $this->db->update('agri_order',$datas);
		}	
		
		public function emp_area()
		{
			$this->db->select('*');
			$this->db->from('agri_employee');
			$q_result=$this->db->get();
			
			return $q_result->result();
              
			  			}
	
	}
	
	
	
	?>