<?php
class Admin_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		
		
		}
		 public function admin_login($login,$password)
       {
		   
		   $sql='SELECT * FROM agri_admin where admin_name="'.$login.'" AND Pwd="'.$password.'" ';
       $query = $this->db->query($sql);
	   return $query->result();
	   }
	   
	   public function get_alluser($limit, $start)
	   {
		   $this->db->limit($limit, $start);
		   $this->db->select('*');
		   $this->db->from('jobs_users');
		   $query=$this->db->get();
		   return $query->result();
		   
		   }
         public function record_count() {
        return $this->db->count_all("jobs_users");	
	
	
	}
	
	
	public function get_feed($limit, $start)
	   {
		   $this->db->limit($limit, $start);
		   $this->db->select('*');
		   $this->db->from('jobs_contact_us');
		   $query=$this->db->get();
		   return $query->result();
		   
		   }
         public function record_count1() {
        return $this->db->count_all("jobs_contact_us");	
	
	
	}
	public function get_admin()
	{
		}
	
	}
	


 ?>