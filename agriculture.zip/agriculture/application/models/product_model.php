<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Product_model extends CI_Model {
    
    public function __construct()
    {
        parent::__construct();
    }
	
         public function record_count() {
			 
        return $this->db->count_all("agri_company_product");	
	
	
	}
	
public function show_product($limit, $start)
{
	$this->db->limit($limit, $start);
	$this->db->select('*');
	$this->db->where("chk","1");
	$this->db->from('agri_company_product');

	$query=$this->db->get();
	return $query->result();
	
	}
	
	public function test_dis()
	{
		$this->db->select('*');
	$this->db->where("chk","1");
	$this->db->from('agri_company_product');

	$query=$this->db->get();
	$res= $query->result();
	
		foreach($res as $row)
		{
			$data_inst=array(
		  "product_name"=>$row->product_name,
			"common_name"=>$row->common_name,
			"formulation"=>$row->formulation,
			"crop"=>$row->crop,
			"pests"=>$row->pests,
			"dosage"=>$row->dosage,
			"disease_img"=>$row->disease_img,
			"product_imag"=>$row->product_imag,
			"product_imag1"=>$row->product_imag1,
			"product_imag2"=>$row->product_imag2,
			"properties"=>$row->properties,
			"description"=>$row->description,
			"condition"=>"1",
			"chk"=>$row->chk
			);
			//$this->db->insert("agri_company_product",$data_inst);
			
   			}
		}	
	
public function	show_product1($id)
{
	
	$this->db->select('*');
	$this->db->where('cp_id',$id);
	$this->db->from('agri_company_product');
	$query=$this->db->get();
	return $query->result();	
	
	}
	
public function show_crop()
{
	
	$this->db->select('crop');
    $this->db->from('agri_recomender');
	$query=$this->db->get();
	return $query->result();
	
	}

	
public function get_d($crop_name)
{
	$this->db->select('*');
	$this->db->where('crop',$crop_name);
	$this->db->from('agri_crop_disease');
	$query=$this->db->get();
	return $query->result();
	
	
	}
 /*public function get_descrip($des,$dis_condition)
 {
	
	 	$this->db->select('*');
		$this->db->like('pests',$des);
		$this->db->where('condition',$dis_condition);
	$this->db->from('agri_company_product');
	$query=$this->db->get();
	
	return $query->result();
	
	 
	 }	*/
	 
	 public function get_descrip()
 {
	
	 	$this->db->select('*');
		//$this->db->where('chk','1');
	$this->db->from('agri_company_product');
	$query=$this->db->get();
	
	return $query->result();
	
	 
	 }	
	 
 public function get_disease_img($des )
 {
	 $dises=explode(',',$des);
	 foreach($dises as $rs)
	 {
		 $this->db->select('*');
		 $this->db->where('disease',$rs);
		 $this->db->from('agri_crop_disease');
		 $query=$this->db->get();
		$rsq[]= $query->result();
		 }
		 
		 return $rsq;
		 
	 }	 
	
  
  public function create($data)
  {
	  
	  $this->db->insert('agri_company_product',$data);
	  
	  }
	  
  public function create_1( $data,$data1)
  {
	  
	  
	   $crop=$this->input->post('crop');
	  $cr=array(
	  "crop"=>$crop
	  );
	  $this->db->insert('agri_recomender',$cr);
	 $this->db->insert('agri_company_product',$data);
	 $this->db->insert('agri_crop_disease',$data1);
	  
	  }	  	
	  
	   	
 public function p_update($id,$data)
 {
  
  $this->db->where('cp_id',$id);
  $this->db->update('agri_company_product',$data);
	 
	 
	 
	 }
	 
 public function p_delete($id)
 {
	 $this->db->where('cp_id',$id);
	 $this->db->delete('agri_company_product');
	 
	 }	
	 
 public function show_fertilizer()
 {
	 $this->db->select('*');
	 $this->db->where('common_name','fertilizer');
	 $this->db->from('agri_company_product');
	 $query=$this->db->get();
	  return $query->result();
	 
	 }	  

	public function comp($id)
	{
		$this->db->select('*');
	 $this->db->where('dealer_area',$id);
	 $this->db->from('agri_dealer');
	 $query=$this->db->get();
	  return $query->result();
		
		}
	
   }