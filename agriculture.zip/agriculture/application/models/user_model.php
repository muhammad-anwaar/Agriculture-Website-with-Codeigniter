<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User_model extends CI_Model {
    
    public function __construct()
    {
        parent::__construct();
    }
    function login($username,$password){
        $this->db->where("user_name",$username);
        $this->db->where("password",$password);

        $query=$this->db->get("agri_user");
		
        if($query->num_rows()>0){
          foreach($query->result() as $rows){
           //add all data to session
           $newdata = array(
             'user_id'  => $rows->user_id,
             'user_name'  => $rows->user_name,
             'logged_in'  => TRUE,
           );
         }
         $this->session->set_userdata($newdata);
         return true;
        }else{
            $this->session->set_flashdata('login_error','Invalid username or password');
            return false;
        }
  }
  

	
	
	public function add_user()
	{
		$data=array(
			'user_name'=>$this->input->post('user_name'),
			'email'=>$this->input->post('email'),
			'password'=>md5($this->input->post('password')),
			'first_name'=>$this->input->post('first_name'),
			'last_name'=>$this->input->post('last_name'),
			'address'=>$this->input->post('address'),
			'city'=>$this->input->post('city'),
			'country'=>$this->input->post('country'),
			'phone'=>$this->input->post('phone'),
			'dj'=>$this->input->post('dj'),
			'dob'=>$this->input->post('dob'),
			'gender'=>$this->input->post('gender')
			);
		$this->db->insert('agri_user',$data);
	}
	
  public function add_feed_back()
  {
	  $data=array(
	  
	  'c_name'=>$this->input->post('c_name'),
	  'c_email'=>$this->input->post('c_email'),
	  'c_subject'=>$this->input->post('c_subject'),
	  'c_message'=>$this->input->post('c_message')
	  
	  );
	  
	  $this->db->insert('agri_contact',$data);
	  
	  }	
	  
	public function get_feed()
	{
		$this->db->select('*');
		$this->db->from('agri_contact');
		$query=$this->db->get();
		return $query->result();
		
		
		}  
		
		public function recomend()
		{
			//print_r($_POST);
			/*$datas['k']=$this->input->post('k');
		$datas['mg']=$this->input->post('mg');
		$datas['s']=$this->input->post('s');
		$datas['mn']=$this->input->post('mn');
		$datas['zn']=$this->input->post('zn');*/
			extract($_POST);
			

			$datas=array(
			'k'=>$k,
			'mg'=>$mg,
			's'=>$s,
			'mn'=>$mn,
			'zn'=>$zn,
			'crop'=>$crop
			);
			
			$this->db->where('n',$nitrogen);
			$this->db->update('s_recomender',$datas);

			$this->db->select('*');
			$this->db->where('n',$nitrogen);
			$this->db->from('s_recomender');
			$querys=$this->db->get();
		
		 return $querys->result();
			
			}
			
			public function total_user()
			{
				$this->db->select('*');
				$this->db->from('agri_customer');
				$query=$this->db->get();
				return $query->result();
				
				
				}
				public function total_user1()
			{
				$this->db->select('*');
				$this->db->from('agri_dealer');
				$query=$this->db->get();
				return $query->result();
				
				
				}
			public function total_user2()
			{
				$this->db->select('*');
				$this->db->from('agri_employee');
				$query=$this->db->get();
				return $query->result();
				
				
				}
				
		public function total_user3()
			{
				$this->db->select('*');
				$this->db->from('agri_company_product');
				$query=$this->db->get();
				return $query->result();
				
				
				}
		public function total_user4()
			{ 
				$this->db->select('*');
				$this->db->from('agri_daily_report');
				$query=$this->db->get();
				return $query->result();
				
				
				}
				
	public function total_order()
	{
		$this->db->select("*");
		$this->db->from('agri_order');
		$query=$this->db->get();
		return $query->result();
		}
		
		public function total_order1()
	{
		$this->db->select("*");
		$this->db->from('agri_order');
		$this->db->where("order_status","3");
		$query=$this->db->get();
		return $query->result();
		}
		
		public function total_order2()
	{
		$this->db->select("*");
		$this->db->from('agri_order');
		
	$this->db->where("order_status","1");

		$query=$this->db->get();
		return $query->result();
		}	
		public function total_order3()
	{
		$this->db->select("*");
		$this->db->from('agri_order');
	
	$this->db->where("order_status","0");

		$query=$this->db->get();
		return $query->result();
		}	
				
		public function pro_detail()
		{
			$this->db->select('*');
			$this->db->from('agri_company_product');
			$this->db->order_by('cp_id','ASC');
			$this->db->limit('5');
			$query=$this->db->get();
			return $query->result();
			
			}		
	
	public function get_order()
	{
		$this->db->select('*');
		$this->db->where('order_status','1');
		$this->db->order_by('order_id','desc');
		
		$this->db->from('agri_order');
		$query=$this->db->get();
		
		return $query->result();
		
		}
	
	public function mng_order($order_id)
	{
			$datas=array(
			'order_status'=>'3'
			);
		$this->db->where('order_id',$order_id);
		$this->db->update('agri_order',$datas);
		}
		
		public function del_feed($id)
		{
			$this->db->where("c_id",$id);
			$this->db->delete('agri_contact');
			}
			
		public function crop_add()
		{
			$crop=$this->input->post('crop');
			$in_data=array(
			"crop"=>$crop
			);
			
			$this->db->insert("agri_recomender",$in_data);
			
			}	
		
		
}
?>