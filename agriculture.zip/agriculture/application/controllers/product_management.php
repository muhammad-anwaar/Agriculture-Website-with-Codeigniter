<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_management extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('form','url');
		$this->load->model('product_model');
		$this->load->library("pagination");
		
		}
		
		
	public function index()
	{
		
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/product_manage');
		$this->load->view('admin/admin_footer');
		
		}	
		
	public function add_product()
	{
		
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/add_product');
		$this->load->view('admin/admin_footer');
		
		
		
		}	
		
		public function product_insert()
		{

            $config = array(
                'upload_path' => 'upload/',
                'allowed_types' => 'gif|jpeg|jpg|png',
                'size' => '5120' // 5MB
            );
			$this->load->library('upload', $config);
     
			$file_name =  $_FILES["product_imag"]["name"];
		 $data= move_uploaded_file($_FILES["product_imag"]["tmp_name"],"upload/" . $file_name);
                $data = array(
                    'product_name'=>$this->input->post('product_name'),
					'common_name'=>$this->input->post('common_name'),
					'formulation'=>$this->input->post('formulation'),
					'crop'=>$this->input->post('crop'),
					'pests'=>$this->input->post('pests'),
					'dosage'=>$this->input->post('dosage'),  
                    'product_imag' =>$file_name,
				   
                );
				
				
			
			
			         $this->product_model->create( $data);
		   $data['msg']='<span style="color:#FF0000; font-size:12px; font-family:Arial, Helvetica, sans-serif">Product Inserted Add More!.</span>';
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/add_product',$data);
		$this->load->view('admin/admin_footer');
		
			
		}
		
	public function product_insert1()
		{

            $config = array(
                'upload_path' => 'upload/',
                'allowed_types' => 'gif|jpeg|jpg|png',
                'size' => '5120' // 5MB
            );
			$this->load->library('upload', $config);
     
			$file_name =  $_FILES["product_imag"]["name"];
		 $data= move_uploaded_file($_FILES["product_imag"]["tmp_name"],"upload/" . $file_name);
		 
		 $file_name1 =  $_FILES["dis_img"]["name"];
		 $data= move_uploaded_file($_FILES["dis_img"]["tmp_name"],"upload/" . $file_name1);
                $data = array(
				'product_name'=>$this->input->post('product_name'),
					'common_name'=>$this->input->post('common_name'),
					'formulation'=>$this->input->post('formulation'),
					'crop'=>$this->input->post('crop'),
					'pests'=>$this->input->post('pests'),
					'dosage'=>$this->input->post('dosage'),  
                    'product_imag' =>$file_name,
					'disease_img' =>$file_name1,
				   
                );
				$data1=array(
				'crop'=>$this->input->post('crop'),
				'crop_varity'=>$this->input->post('v_name'),
				'disease'=>$this->input->post('pests'),
				'disease_img' =>$file_name1,
				);
			
			         $this->product_model->create_1( $data,$data1);
		   $data['msg']='<span style="color:#FF0000; font-size:12px; font-family:Arial, Helvetica, sans-serif">Recomender Updated Add More!.</span>';
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/manage_reomender',$data);
		$this->load->view('admin/admin_footer');
		
			
		}
	
	public function manage_product()
	{
					  $config = array();
        $config["base_url"] = base_url() . "index.php/product_management/manage_product";
		$config["total_rows"] = $this->product_model->record_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;
		
		$this->pagination->initialize($config);
		
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["row"] = $this->product_model->
             show_product($config["per_page"], $page);
			 // $data['row1']=$this->admin_model->get_alluser();
			 $data["links"] = $this->pagination->create_links();
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/manage_product',$data);
		$this->load->view('admin/admin_footer');
		
		}
		
	public function upd()
	{
		 $id=$this->input->get('var1');
		$data['row']=$this->product_model->show_product1($id);
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/edit_product',$data);
		$this->load->view('admin/admin_footer');
		
		
		}
	public function product_update()
	{
		
		$id=$this->input->post('id');
			$file_name =  $_FILES["product_imag"]["name"];
		 $data= move_uploaded_file($_FILES["product_imag"]["tmp_name"],"upload/" . $file_name);
                $data = array(
                    'product_name'=>$this->input->post('product_name'),
					'common_name'=>$this->input->post('common_name'),
					'formulation'=>$this->input->post('formulation'),
					'crop'=>$this->input->post('crop'),
					'pests'=>$this->input->post('pests'),
					'dosage'=>$this->input->post('dosage'),  
                    'product_imag' =>$file_name,
				   
                );
		$this->product_model->p_update($id,$data);
		$data['msg']='<span style=" color:#665533; font-size:12px; font-family:Arial, Helvetica, sans-serif">Product Updated.</span>';
							  $config = array();
        $config["base_url"] = base_url() . "index.php/product_management/manage_product";
		$config["total_rows"] = $this->product_model->record_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;
		
		$this->pagination->initialize($config);
		
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["row"] = $this->product_model->
             show_product($config["per_page"], $page);
			 // $data['row1']=$this->admin_model->get_alluser();
			 $data["links"] = $this->pagination->create_links();
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/manage_product',$data);
		$this->load->view('admin/admin_footer');
		
		}	
		
		
	public function delete()
	{
		
		 $id=$this->input->get('var1');
		$this->product_model->p_delete($id);
				$data['msg']='<span style=" color:#665533; font-size:12px; font-family:Arial, Helvetica, sans-serif">Product Deleted Succesfully.</span>';
							  $config = array();
        $config["base_url"] = base_url() . "index.php/product_management/manage_product";
		$config["total_rows"] = $this->product_model->record_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;
		
		$this->pagination->initialize($config);
		
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["row"] = $this->product_model->
             show_product($config["per_page"], $page);
			 // $data['row1']=$this->admin_model->get_alluser();
			 $data["links"] = $this->pagination->create_links();
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/manage_product',$data);
		$this->load->view('admin/admin_footer');
		
		}			
		
		
}
?>