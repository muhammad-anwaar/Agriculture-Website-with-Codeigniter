<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('form','url');
		$this->load->library("pagination");
		$this->load->model('user_model');
		}
	
	public function index()
	{//$this->load->view('admin/admin_menu');
		$this->load->view('admin/admin_header');
		
		$this->load->view('admin/admin_login');
		//$this->load->view('admin/admin_home');
		$this->load->view('admin/admin_footer');
		}
	
		public function admin_login()
	{
		$this->load->library('form_validation');
		$this->load->model('admin_model');
		$this->form_validation->set_rules('login', 'User Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		
		$data = $this->admin_model->admin_login($_POST['login'],$_POST['password']);
		if(count($data)>0)
		  {
		   $this->session->set_userdata('logged_in', 'true');
		  $this->session->set_userdata('admin_name',$data[0]->admin_name);
		   redirect('admin/home');
		  }
	    else 
	      {
	       $this->session->set_userdata('logged_in', 'false');
		    
				$data['error_msg'] ='<span style="color:#FF0000; font-size:12px; font-family:Arial, Helvetica, sans-serif">Username / password invalid.</span>';
	       $this->load->view('admin/admin_header');
		   $this->load->view('admin/admin_login',$data);
		   $this->load->view('admin/admin_footer');
	       
		  } }
		   
		  
		  public function home()
		  {

			 $data['datas']=$this->user_model->total_user();
			 $data['datas1']=$this->user_model->total_user1();
			 $data['datas2']=$this->user_model->total_user2();
			 $data['datas3']=$this->user_model->total_user3();
			  $data['datas4']=$this->user_model->total_user4();
			  $data['row']=$this->user_model->pro_detail();
			  ///////////////////////////Reporting////////////////////////
			  $data['datas5']=$this->user_model->total_order();
			 $data['datas6']=$this->user_model->total_order1();
			 $data['datas7']=$this->user_model->total_order2();
			 $data['datas8']=$this->user_model->total_order3();
			  $this->load->view('admin/header_view');
		  $this->load->view('admin/admin_leftmenu');
		  $this->load->view('admin/admin_home',$data);
		  $this->load->view('admin/admin_footer');
	      
			  }
			  
		public function logout()
	      {
	    //$this->load->library('session');
	    $this->session->set_userdata('logged_in', 'false');
	    redirect("admin/index");
	    exit;
		
		}  
		  
	
	  public function feed_back()
		  {
			  $config = array();
        $config["base_url"] = base_url() . "index.php/admin/home";
		$config["total_rows"] = $this->admin_model->record_count1();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;
		
		$this->pagination->initialize($config);
		
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["row1"] = $this->admin_model->
            get_feed($config["per_page"], $page);
			 // $data['row1']=$this->admin_model->get_alluser();
			 $data["links"] = $this->pagination->create_links();
			  $this->load->view('admin/header_view');
		  $this->load->view('admin/admin_leftmenu');
		  $this->load->view('admin/feed_back',$data);
		  $this->load->view('admin/admin_footer');
	      
			  }
			  
			 public function get_order()
			 {
				$data['row']=$this->user_model->get_order();
				$this->load->view('admin/header_view');
				$this->load->view('admin/admin_leftmenu');
				$this->load->view('admin/order_manage',$data);
				 
$this->load->view('admin/admin_footer');				 } 



public function mng_order()
{
	$order_id=$this->input->get('var1');
	$this->user_model->mng_order($order_id);
	$this->get_order();
	
	}
	
	public function manage_recs()
	{
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
	$this->load->view('admin/rec_manage');
				 
$this->load->view('admin/admin_footer');
		}
			
			public function add_crop()
	{
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
	$this->load->view('admin/add_crop');
				 
$this->load->view('admin/admin_footer');
		}  
		
		public function add_varity()
	{
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
	$this->load->view('admin/add_varity');
				 
$this->load->view('admin/admin_footer');
		}  
		public function crop_add()
		{
			$this->user_model->crop_add();
			$this->manage_recs();
			}
			
		public function varity_add()
		{
			
			}		
			
	}

?>