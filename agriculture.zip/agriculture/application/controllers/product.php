<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Product extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form','url');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('order_model');
		$this->load->model('product_model');
		$this->load->library("pagination");
	}
	public function index()
	{
		$this->load->view('main_products.php');
		}
	
	public function index1()
	{    
			  $config = array();
        $config["base_url"] = base_url() . "index.php/product/index1";
		$config["total_rows"] = $this->product_model->record_count();
        $config["per_page"] = 5;
        $config["uri_segment"] = 3;
		
		$this->pagination->initialize($config);
		
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["row"] = $this->product_model->
             show_product($config["per_page"], $page);
			 // $data['row1']=$this->admin_model->get_alluser();
			 $data["links"] = $this->pagination->create_links();
             
			 $this->load->view('company_product.php',$data);
	}
	
	public function show_detail()
	{
		$id=$this->input->get('v1');
		$result=$this->product_model->show_product1($id);
			if($result)
	     {
		
				$data['row']=$result;
		$this->load->view('company_product_detail.php',$data);
		}
	else
	{
		echo "Some Thing Going Wrong!";
		
		}
		
		}
	
   public function add_product()
     {
		// field name, error message, validation rules
		$this->form_validation->set_rules('product_name', 'Product Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('order_quantity', 'Quantity', 'trim|required');
		$this->form_validation->set_rules('order_date', 'Order_date', 'trim|required');
		$this->form_validation->set_rules('order_address', 'Address Field', 'trim|require');
		$this->form_validation->set_rules('order_type', 'Order type', 'trim|require');
		$this->form_validation->set_rules('customer_id', 'Customer ID', 'trim|require');
		$this->form_validation->set_rules('order_status', 'Order Ststus', 'trim|require');
	   if($this->form_validation->run() == FALSE)
		{
			$this->load->view('customer.php');
		}
		else
		{
			//print_r($_POST);
			$this->order_model->add_order();
			$data['msg'] ='<span style="color:green; font-size:12px; font-family:Arial, Helvetica, sans-serif">Order inserted add More!!.</span>';
			$this->load->view('customer.php',$data);
		}
	
	}	
	
public function order()
{
$city=$this->input->get('c1');
$result=$this->order_model->show_order($city);
$data['row']=$result;
$this->load->view('manage_order',$data);
	}	
public function add_order()
{
	
		$this->form_validation->set_rules('order_product', 'Product Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('order_quantity', 'Quantity', 'trim|required');
		$this->form_validation->set_rules('order_date', 'Order_date', 'trim|required');
		$this->form_validation->set_rules('order_address', 'Address Field', 'trim|require');
		$this->form_validation->set_rules('order_type', 'Order type', 'trim|require');	
	
	   if($this->form_validation->run() == FALSE)
		{
			$this->load->view('manage_order.php');
		}
		else
		{
		
			$this->order_model->add_order_company();
			$this->load->view('employee.php');
		}
	}

public function manage_order()
{
	
		$this->form_validation->set_rules('order_product', 'Product Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('order_quantity', 'Quantity', 'trim|required');
		$this->form_validation->set_rules('order_date', 'Order_date', 'trim|required');
		$this->form_validation->set_rules('order_address', 'Address Field', 'trim|require');
		$this->form_validation->set_rules('order_type', 'Order type', 'trim|require');	
	
	   if($this->form_validation->run() == FALSE)
		{
			$this->load->view('manage_order.php');
		}
		else
		{
		
			$this->order_model->manage_order_company();
			$this->load->view('employee.php');
		}
	}
	
	public function fertilizer()
	{
	
	$data['fert']=$this->product_model->show_fertilizer();
	$this->load->view('fertilzer.php',$data);
	
		}
		
		public function daily_rpt()
		{
			$id=$this->input->get('cs');
			$data['result']=$this->product_model->comp($id);
			$this->load->view('daily_report',$data);
			}

}
?>