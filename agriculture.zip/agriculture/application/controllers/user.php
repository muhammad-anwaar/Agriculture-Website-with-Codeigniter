<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
	}
	public function index()
	{    $this->load->helper('form','url');
		 $this->load->helper('captcha');
  $vals = array(
    'word'	 => substr(md5(time()),3,6),
    'img_path'	 => './captcha/',
    'img_url'	 => 'http://localhost/ci_user/captcha/',
    'font_path'	 => './path/to/fonts/texb.ttf',
    'img_width'	 => '150',
    'img_height' => 30,
    'expiration' => 7200
    );

$cap = create_captcha($vals);
  $data = array(
     'captcha_time' => $cap['time'],
     'ip_address' => $this->input->ip_address(),
     'word' => $cap['word']
     );
  $this->session->set_userdata($data);
  $data['cap_img']=$cap['image'];
  //$this->load->view('form_view',$data);*/
		if(($this->session->userdata('username')!=""))
		{
			$this->thank();
		}
		else{
			$data['title']= 'index';
			//$this->load->view("registration_view.php", $data);
			$this->load->view('main_content.php');
		}
	}
	
	
	
	
	
	
}
?>