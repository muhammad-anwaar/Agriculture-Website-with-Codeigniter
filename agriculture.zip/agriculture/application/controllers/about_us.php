<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class About_us extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		 $this->load->helper('form','url');
		 $this->load->library('session');
		 $this->load->model('user_model');
	}
	public function index()
	{   
	$this->load->view('about-us.php');
	}
	
	public function contact()
	{
		
	$this->load->view('contact_us.php');	
		}
		
	public function f_back()
	{
		$this->load->library('form_validation');
		// field name, error message, validation rules
		$this->form_validation->set_rules('c_name', 'Your Name', 'trim|required|min_length[4]|xss_clean');
		$this->form_validation->set_rules('c_email', 'Your Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('c_subject', 'Subject', 'trim|required|min_length[4]|max_length[32]');

		if($this->form_validation->run() == FALSE)
		{
			$this->contact();
		}
		else
		{
			$this->user_model->add_feed_back();
			redirect('home/home_v');
		}
		
		
		}
			
	public function check_feed()
	{
		
		 $data['row']=$this->user_model->get_feed();
		 $this->load->view('admin/header_view');
		 $this->load->view('admin/admin_leftmenu');
		 $this->load->view('admin/admin_contact',$data);
		 $this->load->view('admin/admin_footer');
		 
		
		}
		public function del_fed()
	{
		$id=$this->input->get('var1');
		$this->user_model->del_feed($id);
		$this->check_feed();
		
		}
	
}
?>