<?php

class Upload extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->model('user_model');
	}

	function index()
	{
		$this->load->view('welcome_view', array('error' => ' ' ));
	}

	function do_upload()
	{
		
			if(isset($_POST['bt_sbmt'])){
				
				
				$msg  =  $this->upload_file($_FILES);
				if($msg[1]==0){
					$data['filename'] = $msg[0];
					$this->load->view('upload_success',$data);
					// insert in db
				}else{
					// display error message
					$error = $msg[0];
				}
				
			}else{
				$this->load->view('welcome_view');
			}
		}
		/*else{
			redirect('/');
		}
		*/
	
	
	
	private function upload_file(){
		
		if($_FILES['userfile']['error'] == 0){
		
		//upload and update the file
			$this->load->library('upload');
			if (file_exists("upload/" . $_FILES["userfile"]["name"])){
			  $msg[0] = $_FILES["userfile"]["name"] . " already exists. ";
			  $msg[1] = -1;
			}else{
			  $file_name =  uniqid().$_FILES["userfile"]["name"];
		 $data= move_uploaded_file($_FILES["userfile"]["tmp_name"],"upload/" . $file_name);

			/*
					$this->load->library('image_lib');
					
			 		//Image Resizing 50 x 50
			
					$config_thumb['source_image'] = "upload/" . $file_name;
			
					$config_thumb['maintain_ratio'] = FALSE;
					
					$config_thumb['new_image'] = "upload/" ."thumb_".$file_name;
			
					$config_thumb['width'] = 150;
			
					$config_thumb['height'] = 150;
					
					$config_thumb['create_thumb'] = FALSE;
			
					$this->image_lib->initialize($config_thumb);
			
					if ( ! $this->image_lib->resize()){
			
					   $msg[0] = $this->image_lib->display_errors(); 
					   $msg[1] = -1;
					   return $msg;
					   
					}
					
			  $this->image_lib->clear();
			  $msg[0] = $file_name;
			  $msg[1] = 0 ;
			}
		}else{
			$msg[0] = "Error occured while uploading file";
			$msg[1] = -1;
		}
		return $msg;*/}}
	
	}
	function create() {

        if ($_POST) {

            $config = array(
                'upload_path' => 'upload/',
                'allowed_types' => 'gif|jpeg|jpg|png',
                'size' => '5120' // 5MB
            );

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if ($this->upload->do_upload()) {
                $data = array(
                    'upload_data' => $this->upload->data()
                );
                
                $file_name = $data['upload_data']['file_name'];
				
               $d=realpath('upload/'.$file_name);
			 //  echo $file_name;
			//   echo $d;
                $data = array(
                   'img_path' =>$file_name,
				   'template'=>$this->input->post('template'),
				   'style_no'=>$this->input->post('style_no')
                );
            }
			    


           
           $this->user_model->create( $data);
		   $data['msg']='<span style="color:#FF0000; font-size:12px; font-family:Arial, Helvetica, sans-serif">Template Uploaded.</span>';
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/resumes_management',$data);
		$this->load->view('admin/admin_footer');
		   
			
        }
		}
	public function show()
	{
		     $data1['row']= $this->user_model->create1();
	         $this->load->view('upload_success', $data1);
		}	
}
?>