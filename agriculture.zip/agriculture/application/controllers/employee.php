<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Employee extends CI_Controller{
	 
	 public function __construct()
	 {
		 parent::__construct();
		 $this->load->helper('form','url');
		 $this->load->library('form_validation');
		 $this->load->model('employee_model');
		 $this->load->model('dealer_model');
		 $this->load->model('order_model');
		 $this->load->library('pagination');
		 $this->load->model('customer_model');
		 $this->load->helper('file','HTML');
		 }
	
	public function index()
	{
		$emp_session=$this->session->userdata('emp_name');
		if(!empty($emp_session))
		{
			$this->load->view('employee.php');
			}
		else 
		{
		$this->load->view('e_sign_in.php ');
		}
		}
		
public function create()
{
		 $this->load->helper('captcha');
 $vals = array(
    'word'	 => substr(md5(time()),3,6),
    'img_path'	 => './captcha/',
    'img_url'	 => 'http://localhost/agriculture/captcha/',
    'font_path'	 => './path/to/fonts/texb.ttf',
    'img_width'	 => '150',
    'img_height' => 30,
    'expiration' => 7200
    );

$cap = create_captcha($vals);
  $data = array(
     'captcha_time' => $cap['time'],
     'ip_address' => $this->input->ip_address(),
     'word' => $cap['word']
     );
  $this->session->set_userdata($data);
  $data['cap_img']=$cap['image'];
	$data['user_id'] = $this->input->post('user_id');
	if(($this->session->userdata('username')!=""))
		{
			$this->thank();
		}
		else{
			$data['title']= 'index';
			$this->load->view("d_registration.php", $data);
			
		}
}

public function create1()
{
	
		 $this->load->helper('captcha');
 $vals = array(
    'word'	 => substr(md5(time()),3,6),
    'img_path'	 => './captcha/',
    'img_url'	 => 'http://localhost/agriculture/captcha/',
    'font_path'	 => './path/to/fonts/texb.ttf',
    'img_width'	 => '150',
    'img_height' => 30,
    'expiration' => 7200
    );

$cap = create_captcha($vals);
  $data = array(
     'captcha_time' => $cap['time'],
     'ip_address' => $this->input->ip_address(),
     'word' => $cap['word']
     );
  $this->session->set_userdata($data);
  $data['cap_img']=$cap['image'];
	$data['user_id'] = $this->input->post('user_id');
	if(($this->session->userdata('username')!=""))
		{
			$this->thank();
		}
		else{
			$data['title']= 'index';
			$data['area']=$this->order_model->emp_area();
			$this->load->view("e_d_registration.php", $data);
			
		}

	}

	 public function check_captcha()
 {
 $expiration = time()-3600; // Two hour limit
  $cap=$this->input->post('captcha');
  if($this->session->userdata('word')== $cap 
   AND $this->session->userdata('ip_address')== $this->input->ip_address()
   AND $this->session->userdata('captcha_time')> $expiration)
  {
   return true;
  }
  else{
   $this->form_validation->set_message('check_captcha', 'Security number does not match.');
   return false;
  }
 }
public function welcome()
	{
		if( $this->session->userdata('logged_in')== TRUE){
			$data['title']= 'Welcome';
			$this->load->view('header',$data);
			$this->load->view('welcome_view.php', $data);
			$this->load->view('footer',$data);
		}else{
			redirect('registration_view');
		}
	}
	
	
public function login(){
	
  $username=$this->input->post('username');
  $password=md5($this->input->post('pass'));
 
 // echo $username;
 // echo $password;
  $result = $this->employee_model->login($username,$password);
  if($result){
	//$this->create1();  
  $this->load->view('employee.php');
  }
  else
  {
	  $data['error_msg'] ='<span style="color:#FF0000; font-size:12px; font-family:Arial, Helvetica, sans-serif">User Name/Password Invalid.</span>';
	  
	  $this->load->view('e_sign_in.php',$data);
	  
	  }
  }
  


  public function thank()
	{
		$data['title']= 'Thank';
		$this->load->view('header_view',$data);
		$this->load->view('thank_view.php', $data);
		$this->load->view('footer_view',$data);
	}
		public function registration()
	{
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|min_length[4]|xss_clean');
		$this->form_validation->set_rules('email', 'Your Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
		$this->form_validation->set_rules('con_password', 'Password Confirmation', 'trim|required|matches[password]');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[4]|max_length[80]');
		$this->form_validation->set_rules('city', 'City', 'trim|required|min_length[2]|max_length[15]');
		$this->form_validation->set_rules('country', 'Country', 'trim|required|max_length[15]');
		$this->form_validation->set_rules('phone', 'Phone Number', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('dj', 'Date Of Joining', 'trim|required');
		$this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|required');
		$this->form_validation->set_rules('captcha', 'Security Code', 'trim|required|callback_check_captcha');

		if($this->form_validation->run() == FALSE)
		{
			$this->create();
		}
		else
		{
			$this->dealer_model->add_dealer();
			$this->load->view('d_sign_in.php');
		}
	}
	


public function logout(){
  $this->session->userdata = array();
  $this->session->sess_destroy();
  session_destroy();
  $this->load->view('e_sign_in');
 
}

public function add_product()
{
		// field name, error message, validation rules
		$this->form_validation->set_rules('product_name', 'Product Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('order_quantity', 'Quantity', 'trim|required');
		$this->form_validation->set_rules('order_date', 'Order_date', 'trim|required');
		$this->form_validation->set_rules('order_address', 'Address Field', 'trim|require');
		$this->form_validation->set_rules('order_type', 'Order Type', 'trim|require');
	   if($this->form_validation->run() == FALSE)
		{
			$this->load->view('customer.php');
		}
		else
		{
			$this->order_model->add_order();
			$data['msg'] ='<span style="color:green; font-size:12px; font-family:Arial, Helvetica, sans-serif">Order inserted add More!!.</span>';
			$this->load->view('dealer.php',$data);
		}
	
	}	
	
 
 public function emp_manage()
 {
	  $config = array();
        $config["base_url"] = base_url() . "index.php/employee/emp_manage";
		$config["total_rows"] = $this->employee_model->record_count();
        $config["per_page"] = 5;
        $config["uri_segment"] = 3;
		
		$this->pagination->initialize($config);
		
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["row"] = $this->employee_model->
             get_emp($config["per_page"], $page);
			 // $data['row1']=$this->admin_model->get_alluser();
			 $data["links"] = $this->pagination->create_links();
	 
	 $this->load->view('admin/header_view');
	 $this->load->view('admin/admin_leftmenu');
	 $this->load->view('admin/employee_manage',$data);
	 $this->load->view('admin/admin_footer');
	 
	 }	
	 
	public function emp_search()
	{
		 $id=$this->input->get('var1');
		$data['row']=$this->employee_model->get_emps($id);
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/edit_employee',$data);
		$this->load->view('admin/admin_footer');
		
		} 
 
    public function emp_update()
	{
		 $id=$this->input->post('emp_id');
		$this->employee_model->employee_update($id);
		redirect('employee/emp_manage');
		
		}
	
	public function insert()
	{
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/add_employee');
		$this->load->view('admin/admin_footer');
		
		}	
		
	public function add_emp()
	{
		$this->form_validation->set_rules('emp_name', 'Employee Name', 'trim|required|min_length[4]|xss_clean');
		$this->form_validation->set_rules('email', 'Your Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
		

		if($this->form_validation->run() == FALSE)
		{
			$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
			$this->load->view('admin/add_employee');
			$this->load->view('admin/admin_footer');
		}
		else
		{
			$this->employee_model->add_employee();
			redirect('employee/emp_manage');
		}
		}	
		
		
	public function add_report()
	{
		$data['result']=$this->employee_model->add_report();
		//$this->load->view('employee');
		$this->create1();
		}
		
	public function manage_report()
	{
		 $emp_id=$this->input->get('rpt');
		$data['rpt']=$this->employee_model->manage_report($emp_id);
		$this->load->view('manage_report',$data);
		
		}	
		
		
	public function download()
	{
		
		$r_id=$this->input->get('rpt');
		
		$rs=$this->employee_model->d_report($r_id);
		$data['result']=$rs;
	
		$html =$this->load->view('download', $data);
		 
	 //  create_pdf($html);
	    
		}
		
			public function download1()
	{
		
		$r_id=$this->input->get('rpt');
		
		$rs=$this->employee_model->d_report($r_id);
		$data['result']=$rs;
	
		 
	 $data['row']=$this->employee_model->admin_report();
			 $this->load->view('admin/header_view');
	 $this->load->view('admin/admin_leftmenu');
	 $this->load->view('admin/admin_download',$data);
	 $this->load->view('admin/admin_footer');
	    
		}	
		
		public function mng()
		{
			$this->load->view('employee.php');
			}
			
		public function admin_rpt()
		{
			$data['row']=$this->employee_model->admin_report();
			 $this->load->view('admin/header_view');
	 $this->load->view('admin/admin_leftmenu');
	 $this->load->view('admin/admin_report',$data);
	 $this->load->view('admin/admin_footer');
			
			
			}
			
		public function del_rpt()
		{
			 $r_id=$this->input->get('rpt');
			$this->employee_model->del_rpt($r_id);
			$this->admin_rpt();
			}		
 
public function emp_delete()
{
	$id=$this->input->get('var1');

	$this->employee_model->emp_del($id);
	$this->emp_manage();
	} 
 
}
?>