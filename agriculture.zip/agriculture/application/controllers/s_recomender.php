 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class S_recomender extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->helper('form','url');
		 $this->load->library('session');
		 $this->load->model('customer_model');
		 $this->load->library('pagination');
	}
	
	public function index()
	{    
	$this->load->view('soil_recomender.php');
	}
	
	public function index1()
	{
		$this->load->view('testimonials.php');
		}
	
	public function recomends()
	{
	    $data['p']=$this->input->post("p");
		$data['ca']=$this->input->post("ca");
		$data['fe']=$this->input->post("fe");
		$data['ph']=$this->input->post("ph");
		$data['result']=$this->user_model->recomend();
		
		 $this->load->view('soil_result.php',$data);
		
		
		}
	
	
}
?>