<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dealer extends CI_Controller{
	 
	 public function __construct()
	 {
		 parent::__construct();
		 $this->load->helper('form','url');
		 $this->load->library('form_validation');
		 $this->load->library('session');
		 $this->load->model('dealer_model');
		 $this->load->model('order_model');
		 $this->load->model('customer_model');
		 }
	
	public function index()
	{
		$dealer_session=$this->session->userdata('dealer_name');
		if(!empty($dealer_session))
		{
			$data['pro_data']=$this->customer_model->all_product();
			$data['area']=$this->order_model->emp_area();
                  $this->load->view('dealer.php',$data);
			}
		else 
		{
		$this->load->view('d_sign_in.php ');
		}
		}
		
public function create()
{
		 $this->load->helper('captcha');
 $vals = array(
    'word'	 => substr(md5(time()),3,6),
    'img_path'	 => './captcha/',
    'img_url'	 => 'http://localhost/agriculture/captcha/',
    'font_path'	 => './path/to/fonts/texb.ttf',
    'img_width'	 => '150',
    'img_height' => 30,
    'expiration' => 7200
    );

$cap = create_captcha($vals);
  $data = array(
     'captcha_time' => $cap['time'],
     'ip_address' => $this->input->ip_address(),
     'word' => $cap['word']
     );
  $this->session->set_userdata($data);
  $data['cap_img']=$cap['image'];
	$data['user_id'] = $this->input->post('user_id');
	if(($this->session->userdata('username')!=""))
		{
			$this->thank();
		}
		else{
			$data['title']= 'index';
			$data['area']=$this->order_model->emp_area();
			$this->load->view("d_registration.php", $data);
			
		}
}



	 public function check_captcha()
 {
 $expiration = time()-3600; // Two hour limit
  $cap=$this->input->post('captcha');
  if($this->session->userdata('word')== $cap 
   AND $this->session->userdata('ip_address')== $this->input->ip_address()
   AND $this->session->userdata('captcha_time')> $expiration)
  {
   return true;
  }
  else{
   $this->form_validation->set_message('check_captcha', 'Security number does not match.');
   return false;
  }
 }
public function welcome()
	{
		if( $this->session->userdata('logged_in')== TRUE){
			$data['title']= 'Welcome';
			$this->load->view('header',$data);
			$this->load->view('welcome_view.php', $data);
			$this->load->view('footer',$data);
		}else{
			redirect('registration_view');
		}
	}
public function login(){
	
  $username=$this->input->post('username');
  $password=md5($this->input->post('password'));

  $result = $this->dealer_model->login($username,$password);
  if($result)
		  {
			// echo $this->session->userdata('dealer_id');
			$data['pro_data']=$this->customer_model->all_product();
			$data['area']=$this->order_model->emp_area();
                  $this->load->view('dealer.php',$data);
		  }
	    else 
	      {
	       $this->session->set_userdata('logged_in', 'false');
		   
				$data['error_msg'] ='<span style="color:#FF0000; font-size:12px; font-family:Arial, Helvetica, sans-serif">Username / password invalid.</span>';

 $this->load->view('d_sign_in.php',$data);
	       
		  }

 
  }
  
public function dealer_back()
{
	
                  $this->load->view('employee.php');
	}

  public function thank()
	{
		$data['title']= 'Thank';
		$this->load->view('header_view',$data);
		$this->load->view('thank_view.php', $data);
		$this->load->view('footer_view',$data);
	}
		public function registration()
	{
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|min_length[4]|xss_clean');
		$this->form_validation->set_rules('email', 'Your Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
		$this->form_validation->set_rules('con_password', 'Password Confirmation', 'trim|required|matches[password]');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[4]|max_length[80]');
		$this->form_validation->set_rules('city', 'City', 'trim|required|min_length[2]|max_length[15]');
		
		$this->form_validation->set_rules('phone', 'Phone Number', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('dj', 'Date Of Joining', 'trim|required');
		$this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|required');
		$this->form_validation->set_rules('dealer_area', 'Dealer Area', 'trim|required');
		$this->form_validation->set_rules('captcha', 'Security Code', 'trim|required|callback_check_captcha');

		if($this->form_validation->run() == FALSE)
		{
			$this->create();
		}
		else
		{
			$this->dealer_model->add_dealer();
			$data['msg']="<span style=color: green;>Dealer Added!!</span>";
			$this->load->view('d_sign_in.php',$data);
		}
	}
	


public function logout(){
  $this->session->userdata = array();
  $this->session->sess_destroy();
  session_destroy();
  
  $this->load->view('d_sign_in');
 
}

public function add_product()
{
		// field name, error message, validation rules
		$this->form_validation->set_rules('product_name', 'Product Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('order_quantity', 'Quantity', 'trim|required');
		$this->form_validation->set_rules('order_date', 'Order_date', 'trim|required');
		$this->form_validation->set_rules('order_address', 'Address Field', 'trim|require');
		$this->form_validation->set_rules('order_type', 'Order Type', 'trim|require');
		$this->form_validation->set_rules('dealer_id', 'Dealer Id', 'trim|require');
		$this->form_validation->set_rules('order_status', 'Order Status', 'trim|require');

	   if($this->form_validation->run() == FALSE)
		{
			$this->load->view('dealer.php');
		}
		else
		{
			$this->order_model->add_order();
			$data['msg'] ='<span style="color:green; font-size:12px; font-family:Arial, Helvetica, sans-serif">Order inserted add More!!.</span>             ';
			$data['pro_data']=$this->customer_model->all_product();
			
			$data['area']=$this->order_model->emp_area();
			$this->load->view('dealer.php',$data);
		}
	
	}	
	
	
public function show()
{
	
	$emp_city=$this->input->get('var1');
	$result=$this->dealer_model->get_dealer($emp_city);
	$data['row']=$result;
	
	$this->load->view('manage_dealer',$data);
	
	}
	
 public function orders()
 {
	 $id=$this->input->get('d_id');
	 
	 $data['row']=$this->dealer_model->show_cus_order($id);
	 
	$this->load->view('dealer_order',$data);
	 
	 }		
	
public function edit($dealer_id)
{
	$result=$this->dealer_model->show_info($dealer_id);
	$data['row']=$result;
	$this->load->view('edit_dealer',$data);
	
	}
	public function info_update()
	{
		$dealer_id=$this->input->post('dealer_id');
		$result=$this->dealer_model->edit_info($dealer_id);
		if($result)
		{
			$this->load->view('employee.php');
			}
			else
			{
				echo "Something Going Wrong!";
				
				}
		
		}
		
		public function d_mns()
		{
			$data['pro_data']=$this->customer_model->all_product();
			$data['area']=$this->order_model->emp_area();
                  $this->load->view('dealer.php',$data);
			}
		
	public function delete($dealer_id)
	{
		
		$this->dealer_model->delete($dealer_id);
		
		
			$this->load->view('employee.php');
			
		}	
}
?>