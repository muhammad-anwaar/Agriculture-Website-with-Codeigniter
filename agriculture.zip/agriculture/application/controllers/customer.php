<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Customer extends CI_Controller{
	 
	 public function __construct()
	 {
		 parent::__construct();
		 $this->load->helper('form','url');
		 $this->load->library('session');
		 $this->load->model('customer_model');
		 $this->load->library('pagination');
		 }
	
	public function index()
	{
		$cus_session=$this->session->userdata('customer_name');
		if(!empty($cus_session))
		{
			$data['cus_data']=$this->customer_model->all_product();
			  //print_r($data['cus_data']);
                 $this->load->view('customer.php',$data);
			}
			else 
			{
		$this->load->view('c_sign_in.php ');
		
			}
		}
		
public function create()
{
		 $this->load->helper('captcha');
 $vals = array(
    'word'	 => substr(md5(time()),3,6),
    'img_path'	 => './captcha/',
    'img_url'	 => 'http://localhost/agriculture/captcha/',
    'font_path'	 => './path/to/fonts/texb.ttf',
    'img_width'	 => '150',
    'img_height' => 30,
    'expiration' => 7200
    );

$cap = create_captcha($vals);
  $data = array(
     'captcha_time' => $cap['time'],
     'ip_address' => $this->input->ip_address(),
     'word' => $cap['word']
     );
  $this->session->set_userdata($data);
  $data['cap_img']=$cap['image'];
	$data['user_id'] = $this->input->post('user_id');
	if(($this->session->userdata('username')!=""))
		{
			$this->thank();
		}
		else{
			$data['title']= 'index';
			$this->load->view("c_registration.php", $data);
			
		}
}
	 public function check_captcha()
 {
 $expiration = time()-3600; // Two hour limit
  $cap=$this->input->post('captcha');
  if($this->session->userdata('word')== $cap 
   AND $this->session->userdata('ip_address')== $this->input->ip_address()
   AND $this->session->userdata('captcha_time')> $expiration)
  {
   return true;
  }
  else{
   $this->form_validation->set_message('check_captcha', 'Security number does not match.');
   return false;
  }
 }
public function welcome()
	{
		if( $this->session->userdata('logged_in')== TRUE){
			$data['title']= 'Welcome';
			$this->load->view('header',$data);
			$this->load->view('welcome_view.php', $data);
			$this->load->view('footer',$data);
		}else{
			redirect('registration_view');
		}
	}
public function login(){
	
	
  $username=$this->input->post('username');
  $password=md5($this->input->post('password'));

  $result = $this->customer_model->login($username,$password);
	
		if($result)
		  {
			  $data['c_name']=$this->session->userdata('customer_name');
			  $data['cus_data']=$this->customer_model->all_product();
			  //print_r($data['cus_data']);
                 $this->load->view('customer.php',$data);
		  }
	    else 
	      {
	     //  $this->session->set_userdata('logged_in', 'false');
		   
				$data['error_msg'] ='<span style="color:#FF0000; font-size:12px; font-family:Arial, Helvetica, sans-serif">Username / password invalid.</span>';

 $this->load->view('c_sign_in.php',$data);
 }
		  
  

 
 
  }
  


  public function thank()
	{
		$data['title']= 'Thank';
		$this->load->view('header_view',$data);
		$this->load->view('thank_view.php', $data);
		$this->load->view('footer_view',$data);
	}
		public function registration()
	{
		$this->load->library('form_validation');
		// field name, error message, validation rules
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|min_length[4]|xss_clean');
		$this->form_validation->set_rules('email', 'Your Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
		$this->form_validation->set_rules('con_password', 'Password Confirmation', 'trim|required|matches[password]');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[4]|max_length[80]');
		$this->form_validation->set_rules('city', 'City', 'trim|required|min_length[2]|max_length[15]');
		$this->form_validation->set_rules('phone', 'Phone Number', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('dj', 'Date Of Joining', 'trim|required');
		$this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|required');
		$this->form_validation->set_rules('captcha', 'Security Code', 'trim|required|callback_check_captcha');

		if($this->form_validation->run() == FALSE)
		{
			$this->create();
		}
		else
		{
			$this->customer_model->add_customer();
			$this->load->view('c_sign_in.php');
		}
	}
	

public function order()
{
	 $id=$this->input->get('c_id');
	 
	 $data['row']=$this->customer_model->show_cus_order($id);
	 
	$this->load->view('customer_order',$data);
	
	}

 public function cust_in()
 {
	 
			  $config = array();
        $config["base_url"] = base_url() . "index.php/customer/cust_in";
		$config["total_rows"] = $this->customer_model->record_count();
        $config["per_page"] = 5;
        $config["uri_segment"] = 3;
		
		$this->pagination->initialize($config);
		
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["row"] = $this->customer_model->
             show_customers($config["per_page"], $page);
			$data["links"] = $this->pagination->create_links();
			
	 $this->load->view('admin/header_view');
	 $this->load->view('admin/admin_leftmenu');
	 $this->load->view('admin/manage_customer',$data);
	 $this->load->view('admin/admin_footer');
	 
	 
	 }
	 
	
   public function customer_search()
   {
	   $id=$this->input->get('var1');
	  $data['row']= $this->customer_model->get_cust($id);
	  
	  $this->load->view('admin/header_view');
	  $this->load->view('admin/admin_leftmenu');
	  $this->load->view('admin/user_edit',$data);
	  $this->load->view('admin/admin_footer');
	   
	   
	   
	   }
	   
	 public function edit_rec()
	 {
		 $id=$this->input->post('customer_id');
		 $this->customer_model->cust_upd($id);
		 redirect('customer/cust_in');
		 
		 } 
		 
	public function customer_ad()
	{
		$this->load->view('admin/header_view');
		$this->load->view('admin/admin_leftmenu');
		$this->load->view('admin/user');
		$this->load->view('admin/admin_footer');
		
		}	  	 


   public function add_cust()
   {
	   $this->customer_model->add_customer();
	   redirect('customer/cust_in');
	   
	   }
 public function delete()
 {
	 $id=$this->input->get('var1');
	 $this->customer_model->del_cust($id);
	 redirect('customer/cust_in');
	 
	 }
	 
	 public function reset_password()
	 {
		 $this->load->view('reset_pass.php');
		 }
		 
		 public function reset_password1()
	 {
		// echo "in";
		 $this->load->view('reser_pass1.php');
		 }
		 
		  public function reset_password2()
	 {
		// echo "in";
		 $this->load->view('reser_pass2.php');
		 }
		 
 public function current_pass()
		 {
			 $email=$this->input->post('email');
			 $data['res_gal']=$this->customer_model->reset_password($email);
			if($data['res_gal']){
			 $this->load->view('password.php',$data);
			}
			else 
			{
				$data['msg']='<span style=" font-style:italic">Email Address Does Not exit.</span>';
				 $this->load->view('reset_pass.php',$data);
				}
			 }
			 
			  public function current_pass1()
		 {
			 $email=$this->input->post('email');
			 $data['res_gal1']=$this->customer_model->reset_password1($email);
			if($data['res_gal1']){
			 $this->load->view('password1.php',$data);
			}
			else 
			{
				$data['msg']='<span style=" font-style:italic">Email Address Does Not exit.</span>';
				 $this->load->view('reser_pass1.php',$data);
				}
			 }
			 
		public function current_pass2()
		 {
			 $email=$this->input->post('email');
			 $data['res_gal1']=$this->customer_model->reset_password2($email);
			if($data['res_gal1']){
			 $this->load->view('password2.php',$data);
			}
			else 
			{
				$data['msg']='<span style=" font-style:italic">Email Address Does Not exit.</span>';
				 $this->load->view('reser_pass2.php',$data);
				}
			 } 	  
			 
	public function current_pass_val()
	{
		$this->customer_model->current_pass();
		$this->load->view('c_sign_in.php ');
		}
		
 public function current_pass_val1()
	{
		$this->customer_model->current_pass1();
		$this->load->view('d_sign_in.php ');
		}
		
 public function current_pass_val2()
	{
		$this->customer_model->current_pass2();
		$this->load->view('e_sign_in.php ');
		}
		
	public function c_ord()
	{
		 $data['cus_data']=$this->customer_model->all_product();
			  //print_r($data['cus_data']);
                 $this->load->view('customer.php',$data);
		 
		}			  
		  

public function logout(){
  $this->session->userdata = array();
  $this->session->sess_destroy();
  session_destroy();
  $this->load->view('c_sign_in');
 
}
	}