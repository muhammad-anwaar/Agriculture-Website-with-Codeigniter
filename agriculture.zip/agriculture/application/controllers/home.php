<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Home extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form','url');
	}
	public function home_v()
	{    
	$this->load->view('home.php');
	}
	
	public function cotton()
	{
		$this->load->view('cotton.php');
		}
		
	public function rice()
	{
		$this->load->view('rice.php');
		}	
		
	public function wheat()
	{
		$this->load->view('wheat.php');
		}	
	
	
}
?>