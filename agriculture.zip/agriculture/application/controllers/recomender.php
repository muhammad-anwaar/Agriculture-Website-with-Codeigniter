<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Recomender extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form','url');
		$this->load->model('product_model');
		$this->load->library('javascript');
	}
	
	
	public function index()
	{    
	$this->load->view('recomender.php');
	}
	
	
  
  public function rec()
  {
	  $data['ro']=$this->product_model->show_crop();
	  
	  $this->load->view('p_recomender.php',$data);
	  
	  }
	  
	  public function get_city()
	  { $state=$this->input->post('state');
	    $data['state']=$state;
	    $this->load->view('city.php',$data);		  
		  }
		  
	public function varity()
	{
		$crop=$this->input->post('crop');
		$city=$this->input->post('city');
		$data['row']=$crop.",".$city;
		$this->load->view('varity.php',$data);
		}	  
	  
 public function record()
{
	$varity=$this->input->post('varity');
	 $crop_name=$this->input->post('crop');
	$data['ro']=$varity;
	$data['rows']=$this->product_model->get_d($crop_name);
	$this->load->view('show.php',$data);
	
	}
	
 public function get_des()
{
 	$r=$this->input->post('dise');
	 $des=implode(',',$r);

	$temp=$this->input->post('w_condition');
	$data['city']=$this->input->post('city');
	$dis_condition=$this->input->post('dis_condition');
	  $s_type=$this->input->post('type');
	 
	 $level=$this->input->post('level');
	$result=$this->product_model->get_descrip();
	$results = array();
    array_push( $results, $result );
foreach($results as $rs){
	foreach($rs as $row)
	{
		
		 $pest=$row->pests;
		 $pest1=$row->pests;
		$pest2=$row->pestss;
		$res='1';
		$res_1='1';
		$img_2='1';
		$img_3='1';
		$img_4='1';
		 if($pest==$des || $pest1==$des || $pest2==$des )
		 { 
			if($temp<15)
			{
			if($level<10)
			{
				if($row->condition==$dis_condition){
					
				if($s_type<6)
				{
					 $data['res']=$row->product_imag;
					 $data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					
					}
				else if($s_type<11)
				{
					$data['res_1']=$row->product_imag1;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					
					}
				else if($s_type<16)
				{
					$data['img_2']=$row->product_imag2;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
			
				}
			else if($level<20)
			{
			
				if($row->condition==$dis_condition){
				if($s_type<6)
				{
					 $data['img_4']=$row->product_imag4;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<11)
				{
					$data['img_3']=$row->product_imag3;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<16)
				{
					$data['img_2']=$row->product_imag2;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
					
				}
			else if($level<31)
			{
				
				if($row->condition==$dis_condition){
				if($s_type<6)
				{
					 $data['img_2']=$row->product_imag2;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<11)
				{
					$data['img_3']=$row->product_imag3;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<16)
				{
					$data['res_1']=$row->product_imag1;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
				}
				}
				else if($temp>15 && $temp<25)
				{
			if($level<10)
			{
				if($row->condition==$dis_condition){
					
				if($s_type<6)
				{
					 $data['img_4']=$row->product_imag4;
					 $data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					
					}
				else if($s_type<11)
				{
					$data['img_2']=$row->product_imag2;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					
					}
				else if($s_type<16)
				{
					$data['res']=$row->product_imag;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
			
				}
			else if($level<20)
			{
			
				if($row->condition==$dis_condition){
				if($s_type<6)
				{
					 $data['res_1']=$row->product_imag1;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<11)
				{
					$data['res']=$row->product_imag;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<16)
				{
					$data['img_3']=$row->product_imag3;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
					
				}
			else if($level<31)
			{
				
				if($row->condition==$dis_condition){
				if($s_type<6)
				{
					 $data['img_3']=$row->product_imag3;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<11)
				{
					$data['img_4']=$row->product_imag4;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<16)
				{
					$data['res_1']=$row->product_imag1;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
				}
				}
				else if($temp>25 && $temp<41)
				{
			if($level<10)
			{
				if($row->condition==$dis_condition){
					
				if($s_type<6)
				{
					 $data['res']=$row->product_imag;
					 $data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					
					}
				else if($s_type<11)
				{
					$data['img_4']=$row->product_imag4;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					
					}
				else if($s_type<16)
				{
					$data['img_2']=$row->product_imag2;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
			
				}
			else if($level<20)
			{
			
				if($row->condition==$dis_condition){
				if($s_type<6)
				{
					 $data['img_3']=$row->product_imag3;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<11)
				{
					$data['res']=$row->product_imag;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<16)
				{
					$data['img_4']=$row->product_imag4;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
					
				}
			else if($level<31)
			{
				
				if($row->condition==$dis_condition){
				if($s_type<6)
				{
					 $data['img_2']=$row->product_imag2;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<11)
				{
					$data['img_3']=$row->product_imag3;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				else if($s_type<16)
				{
					$data['res_1']=$row->product_imag1;
					$data['res_2']=$row->product_name;
					 $data['res_3']=$row->formulation;
					 $data['res_4']=$row->dosage;
					}
				}
				}
				}
}
			 
		
		}
}
	
	$data['result']=$this->product_model->get_disease_img($des);
	
	$this->load->view('recomends.php',$data);
	
	}
	
	public function mng_rec()
	{
		$this->load->view("admin/header_view");
	    $this->load->view("admin/admin_leftmenu");
		$this->load->view("admin/manage_reomender");
		$this->load->view("admin/admin_footer");
		
		}
	
	public function disease_ins()
	{
		
		$this->product_model->test_dis();
		}

	
}
?>