<?php

class Recomender_user extends CI_Controller {
	  var $data = array();

	function __construct()
	{
		parent::__construct();
			$this->load->helper('form','url');
		$this->load->helper('captcha');
                $this->load->library('session');
                
	}

	function index()
	{
	//	$this->load->view('create_resume.php');
	}
	public function reg()
	{
		$this->load->view("sign_in.php");
		
		}
public function create()
{
		// $this->load->helper('captcha');
 $vals = array(
    'word'	 => substr(md5(time()),3,6),
    'img_path'	 => './captcha/',
    'img_url'	 => 'http://localhost/agriculture/captcha/',
    'font_path'	 => './path/to/fonts/texb.ttf',
    'img_width'	 => '150',
    'img_height' => 30,
    'expiration' => 7200
    );

$cap = create_captcha($vals);
  $data = array(
     'captcha_time' => $cap['time'],
     'ip_address' => $this->input->ip_address(),
     'word' => $cap['word']
     );
  $this->session->set_userdata($data);
  $data['cap_img']=$cap['image'];
	//$data['user_id'] = $this->input->post('user_id');
	if(($this->session->userdata('username')!=""))
		{
			$this->thank();
		}
		else{
			$data['title']= 'index';
			$this->load->view("registration_view.php", $data);
			
		}
}
public function welcome()
	{
		if( $this->session->userdata('logged_in')== TRUE){
			$data['title']= 'Welcome';
			$this->load->view('header',$data);
			$this->load->view('welcome_view.php', $data);
			$this->load->view('footer',$data);
		}else{
			redirect('registration_view');
		}
	}
public function login(){
	
  $username=$this->input->post('username');
  $password=md5($this->input->post('pass'));
  
  $result = $this->user_model->login($username,$password);
   
   if($result){
        $this->load->view('sign_in.php');
   }
   else
   {
	   echo "Something wrong!";
	   
	   }
  }
  


  public function thank()
	{
		$data['title']= 'Thank';
		$this->load->view('header_view',$data);
		$this->load->view('thank_view.php', $data);
		$this->load->view('footer_view',$data);
	}
		public function registration()
	{
		$this->load->library('form_validation');
		// field name, error message, validation rules
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|min_length[4]|xss_clean');
		$this->form_validation->set_rules('email', 'Your Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
		$this->form_validation->set_rules('con_password', 'Password Confirmation', 'trim|required|matches[password]');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[2]|max_length[12]');
		$this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[4]|max_length[80]');
		$this->form_validation->set_rules('city', 'City', 'trim|required|min_length[2]|max_length[15]');
		$this->form_validation->set_rules('state', 'State', 'trim|required|max_length[15]');
		$this->form_validation->set_rules('country', 'Country', 'trim|required|max_length[15]');
		$this->form_validation->set_rules('phone', 'Phone Number', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('dj', 'Date Of Joining', 'trim|required');
		$this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|required');
		$this->form_validation->set_rules('captcha', 'Security Code', 'trim|required|callback_check_captcha');

		if($this->form_validation->run() == FALSE)
		{
			$this->create();
		}
		else
		{
			$this->user_model->add_user();
			$this->reg();
		}
	}
	 public function check_captcha()
 {
 $expiration = time()-3600; // Two hour limit
  $cap=$this->input->post('captcha');
  if($this->session->userdata('word')== $cap 
   AND $this->session->userdata('ip_address')== $this->input->ip_address()
   AND $this->session->userdata('captcha_time')> $expiration)
  {
   return true;
  }
  else{
   $this->form_validation->set_message('check_captcha', 'Security number does not match.');
   return false;
  }
 }
public function logout(){
  $this->session->userdata = array();
  $this->session->sess_destroy();
  session_destroy();
  redirect('','refresh');
}


		

}
?>